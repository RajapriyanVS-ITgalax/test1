import { PinNumberOnlyDirective } from './pin-number-only.directive';

describe('PinNumberOnlyDirective', () => {
  it('should create an instance', () => {
    const directive = new PinNumberOnlyDirective();
    expect(directive).toBeTruthy();
  });
});
