import { NoEmojiDirective } from './no-emoji.directive';

describe('NoEmojiDirective', () => {
  it('should create an instance', () => {
    const directive = new NoEmojiDirective();
    expect(directive).toBeTruthy();
  });
});
