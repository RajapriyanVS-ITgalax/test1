import { FilterAndSortPipe } from './filter-and-sort.pipe';

describe('FilterAndSortPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterAndSortPipe();
    expect(pipe).toBeTruthy();
  });
});
