import { FileTypePipe } from './file-type.pipe';

describe('FileTypePipe', () => {
  it('create an instance', () => {
    const pipe = new FileTypePipe();
    expect(pipe).toBeTruthy();
  });
});
