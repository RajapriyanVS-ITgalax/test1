import { AfterContentInit, AfterViewInit, CUSTOM_ELEMENTS_SCHEMA, Component, ContentChildren, Directive, EventEmitter, Input, OnInit, Output, QueryList, TemplateRef, ViewChild } from '@angular/core';
import { PaginationPipe } from './paginator/pagination.pipe';
import { PaginatorComponent } from './paginator/paginator.component';
import { CommonModule, NgTemplateOutlet } from '@angular/common';
import { NgClass } from '@angular/common';

@Directive({
  selector: '[cellDef]',
  standalone: true
})
export class CellDefDirective {
  @Input() cellDef!: string;
  constructor(public template: TemplateRef<any>) { }
}

@Directive({
  selector: '[cellHeaderDef]',
  standalone: true
})
export class CellHeaderDefDirective {
  @Input() cellHeaderDef!: string;
  constructor(public template: TemplateRef<any>) { }
}

@Component({
  selector: 'app-table',
  standalone: true,
  imports: [NgTemplateOutlet, PaginationPipe, CellDefDirective, PaginatorComponent,NgClass],
  templateUrl: './app-table.component.html',
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  styleUrl: './app-table.component.scss'
})
export class AppTableComponent implements OnInit, AfterViewInit, AfterContentInit {

  __columns: any = [];
  __columnsName: any = [];
  __columnID = "";
  __dataSource: any = [];
  __sort = false;
  selectedRow: any = '';


  __pagination = {
    pageNumber: 1,
    pageSize: 25,
    totalCount: 0
  };
  __hasPagination = false;
  __tableClass = "";
  __selectedData: any = {
    currentIndex: 0,
    array: []
  };
  __hideSelectAll = false;


  @Input() set tableClass(tableClass: string) { this.__tableClass = tableClass || ""; }
  get tableClass(): any { return this.__tableClass; }

  __panelClass = "";

  @Input() set panelClass(panelClass: string) { this.__panelClass = panelClass || ""; }
  get panelClass(): any { return this.__panelClass; }

  __tableHeader = ""

  @Input() set tableHeader(tableHeader: string) { this.__tableHeader = tableHeader || ""; }
  get tableHeader(): any { return this.__tableHeader; }

  @Input() set hasPagination(hasPagination: boolean) { this.__hasPagination = hasPagination || false; }
  get hasPagination(): any { return this.__hasPagination; }

  __showPaginator = true
  @Input() set showPaginator(showPaginator: boolean) { this.__showPaginator = showPaginator || false; }
  get showPaginator(): any { return this.__showPaginator; }

  __hasHeader = true
  @Input() set hasHeader(hasHeader: boolean) { this.__hasHeader = hasHeader || false; }
  get hasHeader(): any { return this.__hasHeader; }

  __hasIndex = false
  @Input() set hasIndex(hasIndex: boolean) { this.__hasIndex = hasIndex || false; }
  get hasIndex(): any { return this.__hasIndex; }

  @Input() set pagination(pagination: any) {
    this.__pagination = pagination || {
      pageNumber: 1,
      pageSize: 25,
      totalCount: 0
    };
  }
  get pagination(): any { return this.__pagination }

  @Input() set columns(column: any) { this.__columns = column || []; }
  get columns(): any { return this.__columns }

  @Input() set columnsName(columnsName: any) { this.__columnsName = columnsName || []; }
  get columnsName(): any { return this.__columnsName }

  @Input() set columnID(columnID: any) { this.__columnID = columnID || ""; }
  get columnID(): any { return this.__columnID }

  @Input() set dataSource(dataSource: any) {
    this.__dataSource = dataSource || [];
    if (this.__hasPagination) {
      this.__pagination = {
        pageNumber: 1,
        pageSize: 25,
        totalCount: this.__dataSource.length

      }

    }
    console.log(this.__dataSource, 'helo');

  }
  get dataSource(): any { return this.__dataSource }

  @Input() set sort(sort: boolean) { this.__sort = sort || false; }
  get sort(): boolean { return this.__sort }

  @Input() set hideSelectAll(hideSelectAll: boolean) { this.__hideSelectAll = hideSelectAll || false; }
  get hideSelectAll(): boolean { return this.__hideSelectAll }

  @ViewChild('tableData') tableData!: any;

  @ContentChildren(CellDefDirective)
  cellDefs!: QueryList<CellDefDirective>;

  @ContentChildren(CellHeaderDefDirective)
  cellHeaderDefs!: QueryList<CellHeaderDefDirective>;

  @ContentChildren('slotRight')
  slotRight!: QueryList<any>;

  @ContentChildren('slotMiddle')
  slotMiddle!: QueryList<any>;

  @ContentChildren('slotLeft')
  slotLeft!: QueryList<any>;

  cellTemplates: { [key: string]: TemplateRef<any> } = {};
  cellHeaderTemplates: { [key: string]: TemplateRef<any> } = {};

  slotRightTemplate!: TemplateRef<any>;
  slotMiddleTemplate!: TemplateRef<any>;
  slotLeftTemplate!: TemplateRef<any>;
  @Output('pageChanged') pageChanged: EventEmitter<any> = new EventEmitter();
  @Output('onSelect') onSelect: EventEmitter<any> = new EventEmitter();
  @Output('onActive') onActive: EventEmitter<any> = new EventEmitter();
  constructor() {

  }

  ngOnInit() {

  }

  ngAfterViewInit() {

  }

  ngAfterContentInit() {
    this.cellDefs.forEach((cellDef: CellDefDirective) => {
      this.cellTemplates[cellDef.cellDef] = cellDef.template;
    });
    this.cellHeaderDefs.forEach((cellHeaderDef: CellHeaderDefDirective) => {
      this.cellHeaderTemplates[cellHeaderDef.cellHeaderDef] = cellHeaderDef.template;
    });
    this.slotRight.forEach((slotRight: any) => {
      this.slotRightTemplate = slotRight;
    });
    this.slotLeft.forEach((slotLeft: any) => {
      this.slotLeftTemplate = slotLeft;
    });
    this.slotMiddle.forEach((slotMiddle: any) => {
      this.slotMiddleTemplate = slotMiddle;
    });
    if (this.__hasPagination) {
      this.__pagination = {
        pageNumber: 1,
        pageSize: 25,
        totalCount: this.__dataSource.length

      }

    }
  }

  onPageChanged(event: any) {
    this.__pagination.pageNumber = event.pageNumber;
    this.__pagination.pageSize = event.pageSize;
    this.pageChanged.emit(event);
    console.log(event);
  }

  selectedAllClicked(event: any) {
    this.__selectedData.array = [];
    if (event.target.checked) {
      this.__dataSource.forEach((element: any) => {
        this.__selectedData.array.push(element[this.columnID]);
      });
    }
    this.__selectedData.currentIndex = 0;
    this.onSelect.emit(this.__selectedData);
  }

  selectedSingleClicked(event: any, data: any) {
    if (event.target.checked) {
      this.__selectedData.array.push(data[this.columnID]);
    } else {
      let index = this.__selectedData.array.indexOf(data[this.columnID]);
      if (index > -1) {
        this.__selectedData.array.splice(index, 1);
      }
    }
    this.__selectedData.currentIndex = 0;
    this.onSelect.emit(this.__selectedData);
  }

  hasSelected(data: any) {
    let index = this.__selectedData.array.indexOf(data[this.columnID]);
    if (index > -1) {
      return true;
    } else {
      return false;
    }
  }

  setActiveRow(elem:any, index:any){
     this.selectedRow = index
     this.onActive.emit(elem);
  }

}
