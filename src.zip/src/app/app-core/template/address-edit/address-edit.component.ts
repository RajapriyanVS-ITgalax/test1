import { CUSTOM_ELEMENTS_SCHEMA, Component, EventEmitter, Input, Output, input } from '@angular/core';
import { entAddress } from '../../../common/api-services/application-api/application-api.classes';
import { ApplicationApiService } from '../../../common/api-services/application-api/application-api.service';
import { Row } from '../../core-component/core-component.component';
import { FormsModule } from '@angular/forms';
import { InitialDataService } from '../../../common/services/initial-data/initial-data.service';
import { InputControlComponent } from '../../form-input/input-control/input-control.component';

@Component({
  selector: 'app-address-edit',
  standalone: true,
  imports: [Row, FormsModule, InputControlComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './address-edit.component.html',
  styleUrl: './address-edit.component.scss'
})
export class AddressEditComponent {
  options = {
    hideFullSpinner: true
  }
  __ientAddress = new entAddress();
  islandDDL: any = [];
  villageDDL: any = [];
  @Output('onUpdate') onUpdate: EventEmitter<any> = new EventEmitter();
  @Input('type') type = '';
  @Input('view') view = false;


  __oldValue: any;
  @Input() set oldValue(oldValue: any) { this.__oldValue = oldValue; }
  get oldValue() {

    return this.__oldValue;
  }
  __oldValueDesription: any;
  @Input() set oldValueDesription(oldValueDesription: any) { this.__oldValueDesription = oldValueDesription; }
  get oldValueDesription() {

    return this.__oldValueDesription;
  }


  @Input()
  set ientAddress(ientAddress: any) {
    this.__ientAddress = ientAddress;


    if (this.__ientAddress.provinceValue !== '') {
      this.getIslandFromProvince(this.__ientAddress.provinceValue, this.__ientAddress.islandValue);
      this.getVillageFromIsland(this.__ientAddress.islandValue, this.__ientAddress.villageValue);
    }
  }

  get ientAddress() {
    return this.__ientAddress;
  }

  __btnClicked = false;
  @Input() set btnClicked(btnClicked: boolean) { this.__btnClicked = btnClicked || false; }
  get btnClicked() { return this.__btnClicked; }

  updateAddress() {
    
    if (!this.view) {
      this.onUpdate.emit(this.__ientAddress);

    }
  }


  __errorTrue = false;
  @Input() set errorTrue(errorTrue: boolean) { this.__errorTrue = errorTrue || false; }
  get errorTrue() { return this.__errorTrue; }
  constructor(private apiService: ApplicationApiService, public initialData: InitialDataService) { }



  getIslandFromProvince(val: any, islandValue?: any) {
    let index = this.initialData.DDLValues.DDLProvince.map((e: any) => e.constant).indexOf(val);

    if (index > -1) {
      this.__ientAddress.provinceDescription = this.initialData.DDLValues.DDLProvince[index].description;
    }
    const obj = {
      data: val
    }
    this.apiService.getProvinceBasedOnInslandDDL(obj, this.options).subscribe((success: any) => {
      this.islandDDL = success.value;
      if (islandValue) {
        this.__ientAddress.islandValue = islandValue;
      } else {
        this.__ientAddress.islandValue = "";
        this.__ientAddress.islandDescription = "";
        this.__ientAddress.villageValue = "";
        this.__ientAddress.villageDescription = "";
        if (this.islandDDL.length === 1) {
          this.__ientAddress.islandValue = this.islandDDL[0].constant;
          // this.onUpdate.emit(this.__ientAddress); 
          this.getVillageFromIsland(this.__ientAddress.islandValue);
        }
      }
    })
  }

  getVillageFromIsland(val: any, villageValue?: any) {
    
    let index = this.islandDDL.map((e: any) => e.constant).indexOf(val);
    if (index > -1) {
      this.__ientAddress.islandDescription = this.islandDDL[index].description;
    }
    const obj = {
      data: val
    }
    this.apiService.getIslandBasedOnVillageDDL(obj).subscribe((success: any) => {
      this.villageDDL = success.value;

      if (villageValue) {
        this.__ientAddress.villageValue = villageValue
      } else {
        this.__ientAddress.villageValue = "";
        this.__ientAddress.villageDescription = "";
        if (this.villageDDL.length === 1) {
          this.__ientAddress.villageValue = this.villageDDL[0].constant;
          this.__ientAddress.villageDescription = this.villageDDL[0].description;
        }
      }
    })
  }

  onVillageChange() {
    let index = this.villageDDL.map((e: any) => e.constant).indexOf(this.__ientAddress.villageValue);
    if (index > -1) {
      this.__ientAddress.villageDescription = this.villageDDL[index].description;
    }
  }

}
