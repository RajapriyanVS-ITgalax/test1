import { CUSTOM_ELEMENTS_SCHEMA, Component, Input, TemplateRef } from '@angular/core';
import { CoreService } from '../../service/core.service';

@Component({
  selector: 'app-search',
  standalone: true,
  imports: [],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './search.component.html',
  styleUrl: './search.component.scss'
})
export class SearchComponent {
  @Input() searchTemplate!: TemplateRef<any>;

  constructor(
    private coreService: CoreService,
  ) {

  }

  openDialog(): void {
    if (!this.searchTemplate) {
      return;
    }
    let options = {
      width: 'calc(100% - 118px)',
      maxWidth: '1248px',
      height: 'calc(100% - 90px)',
      maxHeight: '480px',
      minHeight: '200px',
      panelClass: 'search-pane'
    }
    this.coreService.openDialog(this.searchTemplate, options)
  }

  close() {
    this.coreService.closeDialog();
  }
}
