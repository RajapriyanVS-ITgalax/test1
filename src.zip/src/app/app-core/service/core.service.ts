import { Dialog } from '@angular/cdk/dialog';
import { Injectable } from '@angular/core';
import { ConfirmationAlertComponent, NotificationAlertComponent } from '../core-component/dialog-component.component';
import { AlertComponent } from '../../alert/alert.component';
import { BehaviorSubject, Observable } from 'rxjs';
import { DataService } from '../../common/services/data/data.service';


@Injectable({
  providedIn: 'root'
})
export class CoreService {
  dialogRef!: any;
  onDialogClosed = new BehaviorSubject<boolean>(false);
  constructor(
    private dialog: Dialog,



  ) { }

  watchOnDialogClosed(): Observable<boolean> {
    return this.onDialogClosed.asObservable();
  }

  openDialog(template: any, option: any) {

    return new Promise((resolve: any) => {
      this.dialogRef = this.dialog.open<string>(template, option);
      this.dialogRef.closed.subscribe((result: any) => {

        resolve(result);
      });
    })
  }
  closeDialog() {
    if (this.dialogRef) {
      this.onDialogClosed.next(true);
      this.dialogRef.close();

    }
  }
  closeAll() {
    this.dialog.closeAll()
  }


  notificationDialog(message: any) {
    return new Promise(async (resolve: any) => {
      let options = {
        minWidth: '360px',
        maxWidth: '600px',
        disableClose: true,
        panelClass: 'notification-pane',
        data: {
          msg: message,
        },
      }
      let response = await this.openDialog(NotificationAlertComponent, options);
      resolve(response);
    });

  }
  confirmDialog(message: any) {
    return new Promise(async (resolve: any) => {
      let options = {
        width: '360px',
        disableClose: true,
        panelClass: 'notification-pane',
        data: {
          msg: message,
        },
      }
      let response = await this.openDialog(ConfirmationAlertComponent, options);
      resolve(response);
    });

  }

  logout() {
    return new Promise(async (resolve: any) => {
      let options = {
        width: '360px',
        data: {
          type: 'logout'
        },
      }
      let response = await this.openDialog(AlertComponent, options);
      resolve(response);

    });
  }


  checkDelete(message: any) {
    return new Promise(async (resolve: any) => {
      let options = {
        width: '360px',
        data: {
          msg: message,
          type: 'delete'
        },
      }
      let response = await this.openDialog(AlertComponent, options);
      resolve(response);

    });
  }
}
