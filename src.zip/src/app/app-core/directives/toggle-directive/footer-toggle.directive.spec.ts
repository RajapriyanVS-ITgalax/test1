import { FooterToggleDirective } from './footer-toggle.directive';

describe('FooterToggleDirective', () => {
  it('should create an instance', () => {
    const directive = new FooterToggleDirective();
    expect(directive).toBeTruthy();
  });
});
