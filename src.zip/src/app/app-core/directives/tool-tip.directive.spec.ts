import { ToolTipDirective } from './tool-tip.directive';

describe('ToolTipDirective', () => {
  it('should create an instance', () => {
    const directive = new ToolTipDirective();
    expect(directive).toBeTruthy();
  });
});
