import { RoleAccessDirective } from './role-access.directive';

describe('RoleAccessDirective', () => {
  it('should create an instance', () => {
    const directive = new RoleAccessDirective();
    expect(directive).toBeTruthy();
  });
});
