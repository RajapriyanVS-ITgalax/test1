import { ButtonAccessDirective } from './button-access.directive';

describe('ButtonAccessDirective', () => {
  it('should create an instance', () => {
    const directive = new ButtonAccessDirective();
    expect(directive).toBeTruthy();
  });
});
