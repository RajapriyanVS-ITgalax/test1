import { TabAccessDirective } from './tab-access.directive';

describe('TabAccessDirective', () => {
  it('should create an instance', () => {
    const directive = new TabAccessDirective();
    expect(directive).toBeTruthy();
  });
});
