import { MenuAccessDirective } from './menu-access.directive';

// describe('MenuAccessDirective', () => {
//   it('should create an instance', () => {
//     const directive = new MenuAccessDirective();
//     expect(directive).toBeTruthy();
//   });
// });
