import { AppAccessPipe } from './app-access.pipe';

describe('AppAccessPipe', () => {
  it('create an instance', () => {
    const pipe = new AppAccessPipe();
    expect(pipe).toBeTruthy();
  });
});
