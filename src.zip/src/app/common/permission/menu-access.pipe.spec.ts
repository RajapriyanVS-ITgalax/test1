import { MenuAccessPipe } from './menu-access.pipe';

describe('MenuAccessPipe', () => {
  it('create an instance', () => {
    const pipe = new MenuAccessPipe();
    expect(pipe).toBeTruthy();
  });
});
