import { AppAccessDirective } from './app-access.directive';

// describe('AppAccessDirective', () => {
//   it('should create an instance', () => {
//     const directive = new AppAccessDirective();
//     expect(directive).toBeTruthy();
//   });
// });
