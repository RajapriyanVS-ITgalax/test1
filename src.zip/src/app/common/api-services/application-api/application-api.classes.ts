export class entAddress {
  addressId = 0;
         line1 = '';
         line2 = '';
         line3 = '';
         provinceId = 0;
         provinceValue = '';
         provinceDescription = '';
         islandId = 0;
         islandValue = '';
         islandDescription = '';
         villageId = 0;
         villageValue = '';
         villageDescription = '';
         poBoxNo = '';
         idoObjState = '';
         updateSeq = 0;
        
}

export class entBank {
  bankId = 0;
         bankName = '';
         bankCode = '';
         swiftCode = '';
         ifscCode = '';
         bankAddressId = 0;
         branchTypeId = 0;
         branchTypeValue = '';
         branchTypeDescription = '';
         headOfficeBankId = 0;
         ientAddress = new entAddress();
         idoObjState = '';
         updateSeq = 0;
         headOfficeBank = '';
        
}

export class entBankSearch {
  bankName = '';
         bankCode = '';
         swiftCode = '';
         ifscCode = '';
         branchTypeValue = '';
         headOfficeBankId = 0;
         pageSize = 0;
         pageNumber = 0;
         orderByColumnName = '';
         ascending = false;
         istrSortColumn = '';
         istrSortOrder = false;
        
}

export class entBankSearchResult {
  totalCount = 0;
         pageSize = 0;
         pageNumber = 0;
         result: any = [];
        
}

export class entBankSearchResultSet {
  bankId = 0;
         bankName = '';
         bankCode = '';
         swiftCode = '';
         ifscCode = '';
         headOfficeBankName = '';
         headOfficeBankId = 0;
         branchTypeDescription = '';
        
}

export class entByteData {
  byteData: any = [];
         msg = new entIEMessage();
         contentType = '';
         fileName = '';
        
}

export class entCommunicationTracking {
  communicationTrackingId = 0;
         fromEmailId = '';
         toEmailId = '';
         ccEmailIds = '';
         bccEmailIds = '';
         sentDate = '';
         sentStatusId = 0;
         sentStatusValue = '';
         mailContent = '';
         referenceId = 0;
         sentStatusDescription = '';
         modifiedBy = '';
         updateSeq = 0;
         idoObjState = '';
         msg = new entIEMessage();
        
}

export class entCredential {
  companyId = 0;
         password = '';
         token: any = [];
         clientcode = '';
         mPin = '';
         emailId = '';
         newPassword = '';
         confirmPassword = '';
         urlDate = '';
         confirmMPin = 0;
         userLoginId = '';
         userSerialId = 0;
         pin = '';
         isPinValidation = '';
         isPasswordValidation = '';
         languagePreference = '';
         screenName = '';
         oldPassword = '';
         msg = new entIEMessage();
         clinetName = '';
        
}

export class entCrmCustomerBank {
  customerBankId = 0;
         customerId = 0;
         accountNo = '';
         effectiveDate = '';
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         bankId = 0;
         ientBank = new entBank();
         lstentBank: any = [];
         idoObjState = '';
         updateSeq = 0;
         editableFlag = '';
         msg = new entIEMessage();
         headOfficeBank = '';
        
}

export class entCustomer {
  customerId = 0;
         customerRefNo = '';
         firstName = '';
         middleName = '';
         lastName = '';
         dateOfBirth = '';
         genderId = 0;
         genderValue = '';
         genderDescription = '';
         contactNo = '';
         alternateContactNo = '';
         emailId = '';
         permanentAddressId = 0;
         residentialAddressId = 0;
         fnpfNo = '';
         driverLicenseNo = '';
         voterId = '';
         nationalId = '';
         tin = '';
         passportNo = '';
         nationalityId = 0;
         nationalityValue = '';
         nationalityDescription = '';
         customerStatusId = 0;
         customerStatusValue = '';
         customerStatusDescription = '';
         facebookId = '';
         linkedinId = '';
         whatsappNumber = '';
         viberNumber = '';
         skypeId = '';
         fatherName = '';
         motherName = '';
         gaurdianName = '';
         dateOfDeath = '';
         ientCustomerDocument = new entCustomerDocument();
         ientCustomerPhoto = new entCustomerPhoto();
         ientCustomerNotes = new entCustomerNotes();
         ientLead = new entLead();
         lstentCustomerDocument: any = [];
         lstentCustomerNotes: any = [];
         lstentLead: any = [];
         lstentCustomerService: any = [];
         ientCustomerService = new entCustomerService();
         iPermanentaddress = new entAddress();
         iResidentialaddress = new entAddress();
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         previousStatusValue = '';
         ientCrmCustomerBank = new entCrmCustomerBank();
         entCrmCustomerBankList: any = [];
         customerServiceCount = 0;
         leadCount = 0;
         screenName = '';
         studentId = '';
         schoolName = '';
         employerName = '';
         employerAddressId = 0;
         netSalary = '';
         occupation = '';
         iEmployerAddress = new entAddress();
         ientCustomerType = new entCustomerType();
         lstentCustomerType: any = [];
         customerBankCount = 0;
         customerDocumentCount = 0;
         customerStatusCount = 0;
         customerNotesCount = 0;
         customerUpdateCount = 0;
         isCustomerEtit = '';
         trustAccountCount = 0;
         lstentPassingParam: any = [];
         isResidential = '';
         isAddInfoSaveOrUpdate = '';
         isCustomerUpdateNewFlge = '';
         trustCount = 0;
         willCount = 0;
         estateCount = 0;
         legalOrOtherServiceCount = 0;
         birthRegNo = '';
         customerName = '';
        
}

export class entCustomerBankList {
  entCrmCustomerBankList: any = [];
         ientCrmCustomerBank = new entCrmCustomerBank();
         msg = new entIEMessage();
        
}

export class entCustomerDocument {
  customerDocumentId = 0;
         customerId = 0;
         docTypeId = 0;
         docTypeValue = '';
         docTypeDescription = '';
         otherDocName = '';
         fileId = 0;
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         ientFile = new entFile();
         createdByFullname = '';
         createdDate = '';
         customerRefNo = '';
         enteredDate = '';
         enteredBy = '';
         isMandatory = '';
         docRefNo = '';
         sourceId = 0;
         sourceValue = '';
         sourceDescription = '';
        
}

export class entCustomerDocumentList {
  lstentCustomerDocument: any = [];
         msg = new entIEMessage();
         ientCustomerDocument = new entCustomerDocument();
        
}

export class entCustomerNotes {
  customerNotesId = 0;
         customerId = 0;
         notes = '';
         enteredBy = '';
         enteredDate = '';
         customerStatusId = 0;
         customerStatusValue = '';
         customerStatusDescription = '';
         ientDDL = new entDDL();
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         enteredByFullName = '';
        
}

export class entCustomerNotesList {
  lstentCustomerNotes: any = [];
         lentCustomerNotes = new entCustomerNotes();
         msg = new entIEMessage();
        
}

export class entCustomerPhoto {
  customerPhotoId = 0;
         customerId = 0;
         photoFileTypeId = 0;
         photoFileTypeValue = '';
         photoFileTypeDescription = '';
         fileSize = '';
         fileContent = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entCustomerSearch {
  customerRefNo = '';
         customerStatusValue = '';
         genderValue = '';
         firstName = '';
         lastName = '';
         middleName = '';
         dateOfBirth = '';
         dateOfBirthFrom = '';
         dateOfBirthTo = '';
         emailId = '';
         contactNo = '';
         pfNo = '';
         drivingLicenseNo = '';
         voterId = '';
         nationalId = '';
         tin = '';
         passportNo = '';
         pageSize = 0;
         pageNumber = 0;
         orderByColumnName = '';
         ascending = false;
         istrSortColumn = '';
         istrSortOrder = false;
         isAddInfoScreen = '';
        
}

export class entCustomerSearchResult {
  totalCount = 0;
         pageSize = 0;
         pageNumber = 0;
         result: any = [];
        
}

export class entCustomerSearchResultSet {
  customerId = 0;
         customerRefNo = '';
         genderDescription = '';
         dateOfBrith = '';
         emailId = '';
         contactNo = '';
         statusdescription = '';
         customerName = '';
         statusValue = '';
        
}

export class entCustomerService {
  customerServiceId = 0;
         customerId = 0;
         serviceRefNo = '';
         qmsTicketNo = '';
         serviceTypeId = 0;
         serviceTypeValue = '';
         serviceTypeDescription = '';
         contactModeId = 0;
         contactModeValue = '';
         contactModeDescription = '';
         branchId = 0;
         branchValue = '';
         branchDescription = '';
         serviceDatetime = '';
         servicedBy = '';
         serviceNote = '';
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         communicationTypeId = 0;
         communicationTypeValue = '';
         communicationTypeDescription = '';
         previousStatusValue = '';
         entCustomerServiceStatusHistoryList: any = [];
         lstentLead: any = [];
         ientLead = new entLead();
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         customerRefNo = '';
         customerName = '';
         customerContactNo = '';
         customerEmailId = '';
         customerDateOfBirth = '';
         customerGenderDescription = '';
         leadCount = 0;
         servicedByFullname = '';
         createdByFullname = '';
         createdDate = '';
         customerAlternateContactNo = '';
         customerNationality = '';
         customerFatherName = '';
         customerMotherName = '';
         customerGuardianName = '';
         customerStatus = '';
         screenName = '';
         notesFlag = '';
         createdBy = '';
         customerServiceEditFlag = '';
         ibranchddl = new entDDL();
         fnpfNo = '';
         voterId = '';
         passportNo = '';
         driverLicenseNo = '';
         nationalId = '';
         tin = '';
         ientCustomerServiceDocument = new entCustomerServiceDocument();
         lstentCustomerServiceDocument: any = [];
         ientCustomerServiceCommunicationHistory = new entCustomerServiceCommunicationHistory();
         lstentCustomerServiceCommunicationHistory: any = [];
         lstentCustomerService: any = [];
         birthRegNo = '';
         customerStatusValue = '';
        
}

export class entCustomerServiceCommunicationHistory {
  customerServiceCommunicationEmialHistoryId = 0;
         customerServiceId = 0;
         emialCommunicationId = 0;
         statusId = 0;
         statusValue = '';
         sendBy = '';
         sendDate = '';
         statusDescription = '';
         sendByFullname = '';
         ientCommunicationTracking = new entCommunicationTracking();
         msg = new entIEMessage();
         idoObjState = '';
         updateSeq = 0;
        
}

export class entCustomerServiceCommunicationHistoryList {
  entCustomerServiceCommunicationHistoryList: any = [];
         ientCustomerServiceCommunicationHistory = new entCustomerServiceCommunicationHistory();
         msg = new entIEMessage();
        
}

export class entCustomerServiceDocument {
  customerServiceDocumentId = 0;
         customerServiceId = 0;
         docTypeId = 0;
         docTypeValue = '';
         otherDocName = '';
         fileId = 0;
         enteredBy = '';
         enteredDate = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         ientFile = new entFile();
         createdByFullname = '';
         createdDate = '';
         isMandatory = '';
         docTypeDescription = '';
         customerServiceRefNo = '';
         docRefNo = '';
         sourceId = 0;
         sourceValue = '';
         sourceDescription = '';
        
}

export class entCustomerServiceDocumentList {
  lstentCustomerServiceDocument: any = [];
         msg = new entIEMessage();
         ientCustomerServiceDocument = new entCustomerServiceDocument();
        
}

export class entCustomerServiceLeadSearch {
  serviceRefNo = '';
         leadRefNo = '';
         customerRefNo = '';
         leadTypeValue = '';
         assignedDepartmentValue = '';
         productTypeValue = '';
         statusValue = '';
         createdBy = '';
         createdDateFrom = '';
         createdDateTo = '';
         pageSize = 0;
         pageNumber = 0;
         orderByColumnName = '';
         ascending = false;
         istrSortColumn = '';
         istrSortOrder = false;
        
}

export class entCustomerServiceLeadSearchResult {
  totalCount = 0;
         pageSize = 0;
         pageNumber = 0;
         result: any = [];
        
}

export class entCustomerServiceList {
  entCustomerServiceList: any = [];
         ientCustomerService = new entCustomerService();
         msg = new entIEMessage();
        
}

export class entCustomerServiceSearch {
  serviceRefNo = '';
         firstName = '';
         lastName = '';
         middleName = '';
         customerRefNo = '';
         serviceTypeValue = '';
         branchValue = '';
         statusValue = '';
         communicationTypeValue = '';
         servicedBy = '';
         serviceDate = '';
         serviceDateTo = '';
         serviceDateFrom = '';
         pageSize = 0;
         pageNumber = 0;
         orderByColumnName = '';
         ascending = false;
         istrSortColumn = '';
         istrSortOrder = false;
         customerId = 0;
        
}

export class entCustomerServiceSearchLeadResultSet {
  leadId = 0;
         leadRefNo = '';
         serviceRefNo = '';
         customerRefNo = '';
         customerName = '';
         leadTypeDescription = '';
         productTypeDescription = '';
         createdBy = '';
         createdDate = '';
         statusDescription = '';
         statusValue = '';
         description = '';
         duration = 0;
         trustApplRefNo = '';
         trustApplicationStatusValue = '';
         trustApplicationStatusDescription = '';
        
}

export class entCustomerServiceSearchResult {
  totalCount = 0;
         pageSize = 0;
         pageNumber = 0;
         result: any = [];
        
}

export class entCustomerServiceSearchResultSet {
  customerServiceId = 0;
         serviceRefNo = '';
         customerName = '';
         customerRefNo = '';
         serviceTypeDescription = '';
         branchDescription = '';
         serviceDate = '';
         serviceBy = '';
         statusDescription = '';
         statusValue = '';
         leadCount = 0;
         duration = 0;
         serviceNote = '';
        
}

export class entCustomerServiceStatusHistory {
  customerServiceStatusHistoryId = 0;
         customerServiceId = 0;
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         changedBy = '';
         changedDate = '';
         changedByFullname = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entCustomerServiceStatusHistoryList {
  listentCustomerServiceStatusHistory: any = [];
         msg = new entIEMessage();
        
}

export class entCustomerStatusHistory {
  customerStatusHistoryId = 0;
         customerId = 0;
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         changedBy = '';
         changedByFullname = '';
         changedDate = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entCustomerStatusHistoryList {
  listentCustomerStatusHistory: any = [];
         msg = new entIEMessage();
        
}

export class entCustomerType {
  crmCustomerTypeId = 0;
         crmCustomerId = 0;
         customerTypeId = 0;
         customerTypeValue = '';
         customerTypeDescription = '';
         msg = new entIEMessage();
         idoObjState = '';
         updateSeq = 0;
         isChecked = '';
        
}

export class entCustomerTypeList {
  lstentCustomerType: any = [];
         msg = new entIEMessage();
         ientCustomerType = new entCustomerType();
        
}

export class entCustomerUpdate {
  customerUpdateId = 0;
         customerId = '';
         firstName = '';
         middleName = '';
         lastName = '';
         dateOfBirth = '';
         genderId = 0;
         genderValue = '';
         genderDescription = '';
         contactNo = '';
         alternateContactNo = '';
         emailId = '';
         permanentAddressId = 0;
         residentialAddressId = 0;
         pfNo = '';
         driverLicenseNo = '';
         voterId = '';
         nationalId = '';
         tin = '';
         passportNo = '';
         nationalityId = 0;
         nationalityValue = '';
         nationalityDescription = '';
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         facebookId = '';
         linkedinId = '';
         whatsappNumber = '';
         viberNumber = '';
         skypeId = '';
         fatherName = '';
         motherName = '';
         gaurdianName = '';
         dateOfDeath = '';
         iPermanentaddress = new entAddress();
         iResidentialaddress = new entAddress();
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         previousStatusValue = '';
         ientCustomerUpdateDocument = new entCustomerUpdateDocument();
         ientCustomerUpdatePhoto = new entCustomerUpdatePhoto();
         ientCustomerUpdateNotes = new entCustomerUpdateNotes();
         lstentCustomerUpdateDocument: any = [];
         lstentCustomerUpdateNotes: any = [];
         ientCustomerUpdateBank = new entCustomerUpdateBank();
         entCustomerUpdateBankList: any = [];
         oldValue = '';
         customerUpdateRefNo = '';
         assignedOfficerFlag = '';
         reAssignFlag = '';
         selfAssignFlag = '';
         enteredBy = '';
         enteredByFullname = '';
         enteredDate = '';
         ientCustomerUpdateAssignedOfficerHistory = new entCustomerUpdateAssignedOfficerHistory();
         lstentCustomerUpdateAssignedOfficerHistory: any = [];
         screenName = '';
         customerStatus = '';
         customerNo = '';
         studentId = '';
         schoolName = '';
         employerName = '';
         employerAddressId = 0;
         netSalary = '';
         occupation = '';
         iEmployerAddress = new entAddress();
         customerUpdateBankCount = 0;
         customerUpdateDocumentCount = 0;
         customerUpdateStatusCount = 0;
         customerUpdateNotesCount = 0;
         customerUpdateAssignedOfficerCount = 0;
         customerUpdateEmailCount = 0;
         ientCustomerUpdateType = new entCustomerUpdateType();
         lstentCustomerUpdateType: any = [];
         isResidential = '';
         birthRegNo = '';
         customerServiceCount = 0;
         leadCount = 0;
         trustAccountCount = 0;
         trustCount = 0;
         willCount = 0;
         estateCount = 0;
         legalOrOtherServiceCount = 0;
         lstentPassingParam: any = [];
         customerStatusValue = '';
         workflowId = 0;
        
}

export class entCustomerUpdateAssignedOfficerHistory {
  customerUpdateAssignedOfficerHistoryId = 0;
         customerUpdateId = 0;
         assignedTo = '';
         assignedDate = '';
         assignedToFullname = '';
         assignedByFullname = '';
         assignedBy = '';
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entCustomerUpdateAssignedOfficerHistoryList {
  entCustomerUpdateAssignedOfficerList: any = [];
         ientCustomerUpdateAssignedOfficer = new entCustomerUpdateAssignedOfficerHistory();
        
}

export class entCustomerUpdateBank {
  customerUpdateBankId = 0;
         customerUpdateId = 0;
         accountNo = '';
         effectiveDate = '';
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         bankId = 0;
         ientBank = new entBank();
         lstentBank: any = [];
         idoObjState = '';
         updateSeq = 0;
         editableFlag = '';
         oldValue = '';
         customerBankId = 0;
         msg = new entIEMessage();
         headOfficeBank = '';
        
}

export class entCustomerUpdateBankList {
  entCustomerUpdateBankList: any = [];
         ientCustomerUpdateBank = new entCustomerUpdateBank();
         msg = new entIEMessage();
        
}

export class entCustomerUpdateDocument {
  customerUpdateDocumentId = 0;
         customerUpdateId = 0;
         docTypeId = 0;
         docTypeValue = '';
         docTypeDescription = '';
         otherDocName = '';
         fileId = 0;
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         ientFile = new entFile();
         customerDocumentId = 0;
         enteredDate = '';
         enteredBy = '';
         createdByFullname = '';
         customerUpdateRefNo = '';
         docRefNo = '';
         sourceId = 0;
         sourceValue = '';
         sourceDescription = '';
         isMandatory = '';
        
}

export class entCustomerUpdateDocumentList {
  lstentCustomerUpdateDocument: any = [];
         msg = new entIEMessage();
         ientCustomerUpdateDocument = new entCustomerUpdateDocument();
        
}

export class entCustomerUpdateEmailHistory {
  customerUpdateEmailHistoryId = 0;
         customerUpdateId = 0;
         emailCommunicationId = 0;
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         sendBy = '';
         sendByFullname = '';
         sendDate = '';
         ientCommunicationTracking = new entCommunicationTracking();
         msg = new entIEMessage();
         idoObjState = '';
         updateSeq = 0;
        
}

export class entCustomerUpdateEmailHistoryList {
  entCustomerUpdateEmailHistoryList: any = [];
         ientCustomerUpdateEmailHistory = new entCustomerUpdateEmailHistory();
         msg = new entIEMessage();
        
}

export class entCustomerUpdateList {
  entCustomerUpdateList: any = [];
         ientCustomerUpdate = new entCustomerUpdate();
         msg = new entIEMessage();
        
}

export class entCustomerUpdateNotes {
  customerUpdateNotesId = 0;
         customerUpdateId = 0;
         notes = '';
         enteredBy = '';
         enteredDate = '';
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         ientDDL = new entDDL();
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         enteredByFullname = '';
        
}

export class entCustomerUpdateNotesList {
  lstentCustomerUpdateNotes: any = [];
         lentCustomerUpdateNotes = new entCustomerUpdateNotes();
         msg = new entIEMessage();
        
}

export class entCustomerUpdatePhoto {
  customerUpdatePhotoId = 0;
         customerUpdateId = 0;
         photoFileTypeId = 0;
         photoFileTypeValue = '';
         photoFileTypeDescription = '';
         fileSize = '';
         fileContent = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         oldValue = '';
         crmCustomerPhotoId = 0;
        
}

export class entCustomerUpdateSearch {
  customerUpdateRefNo = '';
         statusValue = '';
         genderValue = '';
         firstName = '';
         lastName = '';
         middleName = '';
         dateOfBirth = '';
         dateOfDeathFrom = '';
         dateOfBirthTo = '';
         emailId = '';
         contactNo = '';
         pfNo = '';
         drivingLicenseNo = '';
         voterId = '';
         nationalId = '';
         tin = '';
         passportNo = '';
         pageSize = 0;
         pageNumber = 0;
         orderByColumnName = '';
         ascending = false;
         istrSortColumn = '';
         istrSortOrder = false;
         customerRefNo = '';
        
}

export class entCustomerUpdateSearchResult {
  totalCount = 0;
         pageSize = 0;
         pageNumber = 0;
         result: any = [];
        
}

export class entCustomerUpdateSearchResultSet {
  customerUpdateid = 0;
         customerUpdateRefno = '';
         genderDescription = '';
         dateOfBrith = '';
         emailId = '';
         contactNo = '';
         statusdescription = '';
         customerName = '';
         customerRefNo = '';
         createdByFullname = '';
         createdDate = '';
         statusValue = '';
        
}

export class entCustomerUpdateStatusHistory {
  customerUpdateStatusHistoryId = 0;
         customerUpdateId = 0;
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         changedBy = '';
         changedByFullname = '';
         changedDate = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entCustomerUpdateStatusHistoryList {
  listentCustomerUpdateStatusHistory: any = [];
         msg = new entIEMessage();
        
}

export class entCustomerUpdateType {
  crmCustomerUpdateId = 0;
         customerTypeValue = '';
         customerTypeId = 0;
         crmCustomerTypeId = 0;
         crmCustomerUpdateTypeId = 0;
         customerTypeDescription = '';
         msg = new entIEMessage();
         idoObjState = '';
         updateSeq = 0;
         oldValue = '';
         isChecked = '';
        
}

export class entCustomerUpdateTypeList {
  lstentCustomerUpdateType: any = [];
         msg = new entIEMessage();
         ientCustomerUpdateType = new entCustomerUpdateType();
        
}

export class entDDL {
  key = '';
         value: any = [];
         msg = new entIEMessage();
        
}

export class entDDLClass {
  id = 0;
         code = '';
         description = '';
         name = '';
         parentConstant = '';
         constant = '';
         fullName = '';
         vendorContactNo = '';
         vendorCode = '';
         vendorLegacyCode = '';
         stritemtype = '';
         ledgerId = 0;
         lstDDLClass: any = [];
         msg = new entIEMessage();
        
}

export class entDDLData {
  data: any = [];
         count1 = '';
         count2 = '';
         msg = new entIEMessage();
        
}

export class entDeathNotice {
  deathNoticeId = 0;
         deathNoticeRefNo = '';
         noticeDate = '';
         dateOfDeath = '';
         personName = '';
         willId = 0;
         paperId = 0;
         paperValue = '';
         probateRegistryRefNo = '';
         noticeDocId = 0;
         estateApplicationId = 0;
         enteredBy = '';
         enteredDate = '';
         statusId = 0;
         statusValue = '';
         paperDescription = '';
         statusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         ibranchddl = new entDDL();
         comments = '';
         causeOfDeath = '';
         willRefNo = '';
         estateApplicationRefNo = '';
         branchId = 0;
         branchValue = '';
         branchDescription = '';
         ientDeathNoticeStatusHistory = new entDeathNoticeStatusHistory();
         ilstentDeathNoticeStatusHistory: any = [];
         ientDeathNoticeAssignedOfficerHistory = new entDeathNoticeAssignedOfficerHistory();
         ilstentDeathNoticeAssignedOfficerHistory: any = [];
         ientDeathNoticeEmailHistory = new entDeathNoticeEmailHistory();
         ilstentDeathNoticeEmailHistory: any = [];
        
}

export class entDeathNoticeAssignedOfficerHistory {
  deathNoticeAssignedOfficerHistoryId = 0;
         deathNoticeId = 0;
         statusId = 0;
         statusValue = '';
         assignedTo = '';
         assignedDate = '';
         assignedBy = '';
         statusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entDeathNoticeDocument {
  deathNoticeDocumentId = 0;
         deathNoticeId = 0;
         documentTypeId = 0;
         documentTypeValue = '';
         fileId = 0;
         statusDescription = '';
         documentTypeDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         ientFile = new entFile();
         deathNoticeRefNo = '';
        
}

export class entDeathNoticeDocumentList {
  ientDeathNoticeDocument = new entDeathNoticeDocument();
         ilstentDeathNoticeDocument: any = [];
         msg = new entIEMessage();
        
}

export class entDeathNoticeEmailHistory {
  deathNoticeEmailHistoryId = 0;
         deathNoticeId = 0;
         communicationTrackingId = 0;
         statusId = 0;
         statusValue = '';
         sendBy = '';
         sendDate = '';
         statusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         ientCommunicationTracking = new entCommunicationTracking();
        
}

export class entDeathNoticeList {
  lstentDeathNotice: any = [];
         ientDeathNotice = new entDeathNotice();
         msg = new entIEMessage();
        
}

export class entDeathNoticeSearch {
  deathNoticeRefNo = '';
         personName = '';
         paperValue = '';
         dateOfDeath = '';
         noticeDate = '';
         statusValue = '';
         pageSize = 0;
         pageNumber = 0;
         orderByColumnName = '';
         ascending = false;
         sortColumn = '';
         sortOrder = false;
        
}

export class entDeathNoticeSearchResult {
  totalCount = 0;
         pageSize = 0;
         pageNumber = 0;
         result: any = [];
        
}

export class entDeathNoticeSearchResultSet {
  deathNoticeId = 0;
         deathNoticeRefNo = '';
         personName = '';
         paperDescription = '';
         dateOfDeath = '';
         noticeDate = '';
         statusDescription = '';
        
}

export class entDeathNoticeStatusHistory {
  daethNoticeStatusHistoryId = 0;
         deathNoticeId = 0;
         statusId = 0;
         statusValue = '';
         changedBy = '';
         changedDate = '';
         statusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entDeceasedPerson {
  deceasedPersonId = 0;
         estateApplicationId = 0;
         firstName = '';
         middleName = '';
         lastName = '';
         dob = '';
         genderId = 0;
         genderValue = '';
         maritalStatusId = 0;
         maritalStatusValue = '';
         fatherName = '';
         motherName = '';
         notifiedBy = '';
         brnNo = '';
         dateOfDeath = '';
         deathCertificateRefNo = '';
         deathCertificateDocId = 0;
         deathNoticeId = 0;
         fnpfNo = '';
         lastPlaceOfResidence = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         maritalStatusDescription = '';
         genderDescription = '';
        
}

export class entDeceasedPersonMarriageDetail {
  deceasedPersonMarriageDetailId = 0;
         deceasedPersonId = 0;
         estateApplicationId = 0;
         placeOfMarriage = '';
         marriedTo = '';
         maidenName = '';
         isSpouseLiving = '';
         placeOfDeath = '';
         dateOfDeath = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entDeceasedPersonMarriageDetailList {
  ilstentDeceasedPersonMarriageDetail: any = [];
         ientDeceasedPersonMarriageDetail = new entDeceasedPersonMarriageDetail();
         msg = new entIEMessage();
        
}

export class entDeceasedPersonSearch {
  deathNoticeRefNo = '';
         personName = '';
         paperValue = '';
         dateOfDeath = '';
         noticeDate = '';
         statusValue = '';
         pageSize = 0;
         pageNumber = 0;
         orderByColumnName = '';
         ascending = false;
         sortColumn = '';
         sortOrder = false;
        
}

export class entDeceasedPersonSearchResult {
  totalCount = 0;
         pageSize = 0;
         pageNumber = 0;
         result: any = [];
        
}

export class entDeceasedPersonSearchResultSet {
  deceasedPersonId = 0;
         deathCertificateRefNo = '';
         personName = '';
         dateOfDeath = '';
         noticeDate = '';
        
}

export class entDeceasedPersonWill {
  deceasedPersonWillId = 0;
         deceasedPersonId = 0;
         estateApplicationId = 0;
         willId = 0;
         testatorName = '';
         willDocumentId = 0;
         willFileNo = '';
         startDate = '';
         testatorMarriageDate = '';
         willHeldBy = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entDiary {
  diaryId = 0;
         staffUserId = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         stafFullname = '';
        
}

export class entDiaryEntry {
  diaryEntryId = 0;
         diaryId = 0;
         eventTypeId = 0;
         eventTypeValue = '';
         date = '';
         time = '';
         reminderDatetime = '';
         statusId = 0;
         statusValue = '';
         title = '';
         notes = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         statusDescription = '';
         eventTypeDescription = '';
        
}

export class entDiaryEntryList {
  lstentDiaryEntry: any = [];
         lentDiaryEntry = new entDiaryEntry();
         msg = new entIEMessage();
        
}

export class entDiaryEntrySearch {
  eventTypeValue = '';
         date = '';
         time = '';
         reminderDatetime = '';
         statusValue = '';
         title = '';
         notes = '';
         pageSize = 0;
         pageNumber = 0;
         orderByColumnName = '';
         ascending = false;
         istrSortColumn = '';
         istrSortOrder = false;
         staffUserId = '';
        
}

export class entDiaryEntrySearchResult {
  searchResult: any = [];
         totalCount = 0;
         pageSize = 0;
         pageNumber = 0;
        
}

export class entDiaryEntrySearchResultSet {
  diaryEntryId = 0;
         diaryId = 0;
         date = '';
         time = '';
         reminderDatetime = '';
         title = '';
         notes = '';
         statusDescription = '';
         eventDescription = '';
         staffUserId = '';
         fullname = '';
        
}

export class entEstateApplication {
  estateApplicationId = 0;
         estateApplicationRefNo = '';
         applicationDate = '';
         applicationStageId = 0;
         applicationStageValue = '';
         appliedBy = '';
         appliedDate = '';
         appliedBranchId = 0;
         appliedBranchValue = '';
         enteredBy = '';
         enteredDate = '';
         statusId = 0;
         statusValue = '';
         fileNo = '';
         actionStatusId = 0;
         actionStatusValue = '';
         estateRegNo = '';
         receiptNo = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         ientDeathNotice = new entDeathNotice();
         lstentDeathNotice: any = [];
         leadRefNo = '';
         branchId = '';
         branchValue = '';
         editableIdentificationNo = 0;
         applicationStageDescription = '';
         statusDescription = '';
         appliedBranchDescription = '';
         actionStatusDescription = '';
         branchDescription = '';
         leadId = 0;
        
}

export class entEstateApplicationBeneficiary {
  estateApplicationBeneficiaryId = 0;
         estateApplicationId = 0;
         firstName = '';
         middleName = '';
         lastName = '';
         isDeceased = '';
         dateOfDeath = '';
         placeOfDeath = '';
         occupation = '';
         isMentionedInWill = '';
         isMinor = '';
         residentId = 0;
         residentValue = '';
         relationshipId = 0;
         relationshipValue = '';
         genderId = 0;
         genderValue = '';
         maritalStatusId = 0;
         maritalStatusValue = '';
         dateOfBirth = '';
         ientestateApplicationBeneficiaryAddress = new entAddress();
         addressId = 0;
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         maritalStatusDescription = '';
         genderDescription = '';
         relationshipDescription = '';
         residentDescription = '';
        
}

export class entEstateApplicationBeneficiaryList {
  ilstentEstateApplicationBeneficiary: any = [];
         ientEstateApplicationBeneficiary = new entEstateApplicationBeneficiary();
         msg = new entIEMessage();
        
}

export class entEstateApplicationDocument {
  estateApplicationDocumentId = 0;
         estateApplicationId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         statusId = 0;
         statusValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         documentTypeId = 0;
         documentTypeValue = '';
         fileId = 0;
         isMandatory = '';
         identificationNo = 0;
         applicationStageDescription = '';
         statusDescription = '';
         actionStatusDescription = '';
         ientFile = new entFile();
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entEstateApplicationDocumentList {
  entEstateApplicationDocumentList: any = [];
         ientEstateApplicationDocument = new entEstateApplicationDocument();
         msg = new entIEMessage();
        
}

export class entEstateApplicationExecutor {
  estateApplicationExecutorId = 0;
         estateApplicationId = 0;
         firstName = '';
         middleName = '';
         lastName = '';
         isDeceased = '';
         dateOfDeath = '';
         placeOfDeath = '';
         occupation = '';
         relationshipId = 0;
         relationshipValue = '';
         genderId = 0;
         genderValue = '';
         maritalStatusId = 0;
         maritalStatusValue = '';
         dateOfBirth = '';
         ientestateApplicationExecutorAddress = new entAddress();
         addressId = 0;
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         maritalStatusDescription = '';
         genderDescription = '';
         relationshipDescription = '';
        
}

export class entEstateApplicationFinanceDetails {
  estateApplicationFinanceDetailId = 0;
         estateApplicationId = 0;
         institutionName = '';
         accountHolderName = '';
         accountNo = '';
         accountTypeId = 0;
         accountTypeValue = '';
         bsb = '';
         ientestateApplicationFinanceDetailsAddress = new entAddress();
         addressId = 0;
         accountTypeDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entEstateApplicationFinanceDetailsList {
  ilstentEstateApplicationFinanceDetails: any = [];
         ientEstateApplicationFinanceDetails = new entEstateApplicationFinanceDetails();
         msg = new entIEMessage();
        
}

export class entEstateApplicationInvestmentDetails {
  estateApplicationInvestmentDetailId = 0;
         estateApplicationId = 0;
         companyName = '';
         shareNo = '';
         isCertificateAvailable = '';
         shareTypeId = 0;
         shareTypeValue = '';
         ientestateApplicationInvestmentDetailsAddress = new entAddress();
         addressId = 0;
         shareTypeDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entEstateApplicationInvestmentDetailsList {
  ilstentEstateApplicationInvestmentDetails: any = [];
         ientEstateApplicationInvestmentDetails = new entEstateApplicationInvestmentDetails();
         msg = new entIEMessage();
        
}

export class entEstateApplicationNotes {
  estateApplicationNotesId = 0;
         estateApplicationId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         statusId = 0;
         statusValue = '';
         notes = '';
         identificationNo = 0;
         applicationStageDescription = '';
         statusDescription = '';
         actionStatusDescription = '';
         enteredByFullname = '';
         iActionStatusDDL = new entDDL();
         iStatusDDL = new entDDL();
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entEstateApplicationRealestate {
  estateApplicationRealestateId = 0;
         estateApplicationId = 0;
         titleNo = '';
         tenancyId = 0;
         tenancyValue = '';
         tenancyTypeId = 0;
         tenancyTypeValue = '';
         tenureId = 0;
         tenureValue = '';
         landlordName = '';
         titleCopyDocId = 0;
         ientestateApplicationRealestateAddress = new entAddress();
         addressId = 0;
         tenancyDescription = '';
         tenancyTypeDescription = '';
         tenureDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entEstateApplicationRealestateList {
  ilstentEstateApplicationRealestate: any = [];
         ientEstateApplicationRealestate = new entEstateApplicationRealestate();
         msg = new entIEMessage();
        
}

export class entEstateApplicationSearch {
  estateApplicationRefNo = '';
         applicationStageValue = '';
         appliedBranchValue = '';
         estateRegNo = '';
         actionStatusValue = '';
         statusValue = '';
         enteredDateFrom = '';
         enteredDateTo = '';
         enteredBy = '';
         appliedBy = '';
         appliedDateFrom = '';
         appliedDateTo = '';
         pageSize = 0;
         pageNumber = 0;
         orderByColumnName = '';
         ascending = false;
         sortColumn = '';
         sortOrder = false;
        
}

export class entEstateApplicationSearchResult {
  totalCount = 0;
         pageSize = 0;
         pageNumber = 0;
         result: any = [];
        
}

export class entEstateApplicationSearchResultSet {
  estateApplicationId = 0;
         estateApplicationRefNo = '';
         applicationStageDescription = '';
         appliedBranchDescription = '';
         appliedBranchValue = '';
         actionStatusValue = '';
         appliedDate = '';
         fileNo = '';
         statusDescription = '';
         statusValue = '';
         actionStatusDescription = '';
        
}

export class entEstateApplicationVehicleDetails {
  estateApplicationVehicleDetailId = 0;
         estateApplicationId = 0;
         vehicleRegNo = '';
         vehicleTypeId = 0;
         vehicleTypeValue = '';
         vehicleMake = '';
         model = '';
         insuranceAvailable = '';
         insuranceDocId = 0;
         permitDocId = 0;
         vehicleTypeDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entEstateApplicationVehicleDetailsList {
  ilstentEstateApplicationVehicleDetails: any = [];
         ientEstateApplicationVehicleDetails = new entEstateApplicationVehicleDetails();
         msg = new entIEMessage();
        
}

export class entEstateCreditor {
  estateCreditorId = 0;
         estateApplicationId = 0;
         firstName = '';
         middleName = '';
         lastName = '';
         identityId = 0;
         identityValue = '';
         identityNo = '';
         evidenceDocId = 0;
         identityDesccription = '';
         contactNo = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entEstateCreditorList {
  ilstentEstateCreditor: any = [];
         ientEstateCreditor = new entEstateCreditor();
         msg = new entIEMessage();
        
}

export class entFile {
  fileId = 0;
         fileName = '';
         fileExtension = '';
         fileType = '';
         fileSize = '';
         relativePath = '';
         content = '';
        
}

export class entFptclAccountNo {
  accountId = 0;
         accountNo = '';
         customerId = 0;
         fileId = 0;
         accountTypeId = 0;
         accountTypeValue = '';
         statusId = 0;
         statusValue = '';
         bankId = 0;
         bankValue = '';
         branchId = 0;
         branchValue = '';
         referenceNo = '';
         accountTypeDescription = '';
         statusDescription = '';
         bankDescription = '';
         branchDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         customerName = '';
        
}

export class entFptclAccountNoList {
  ientFptclAccountNo = new entFptclAccountNo();
         lstentFptclAccountNo: any = [];
         msg = new entIEMessage();
        
}

export class entFptclFile {
  fileId = 0;
         fileNo = '';
         fileName = '';
         customerId = 0;
         fileTypeId = 0;
         fileTypeValue = '';
         statusId = 0;
         statusValue = '';
         isPhysicalFile = '';
         referenceNo = '';
         fileTypeDescription = '';
         statusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         customerName = '';
         screenName = '';
        
}

export class entIEMessage {
  infoMessage = new entMsgDetail();
         errorMessage: any = [];
         hasError = false;
        
}

export class entIntStringData {
  data1 = 0;
         data2 = '';
         msg = new entIEMessage();
        
}

export class entLead {
  leadId = 0;
         leadRefNo = '';
         customerServiceId = 0;
         leadTypeId = 0;
         leadTypeValue = '';
         leadTypeDescription = '';
         description = '';
         productTypeId = 0;
         productTypeValue = '';
         productTypeDescription = '';
         assignedDepartmentId = 0;
         assignedDepartmentValue = '';
         assignedDepartmentDescription = '';
         leadDatetime = '';
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         branchValue = '';
         previousProductTypeValue = '';
         ientLeadAssignedOfficer = new entLeadAssignedOfficer();
         ientLeadNotes = new entLeadNotes();
         lstentLeadAssignedOfficer: any = [];
         lstentLeadNotes: any = [];
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         customerRefNo = '';
         customerName = '';
         customerContactNo = '';
         customerEmailId = '';
         customerDateOfBirth = '';
         customerGenderDescription = '';
         serviceNo = '';
         servicedByFullName = '';
         servicedDateTime = '';
         ientDDL = new entDDL();
         assignedOfficerFlag = '';
         reassignFlag = '';
         selfAssignFlag = '';
         createdDate = '';
         createdByFullname = '';
         serviceType = '';
         serviceStatus = '';
         serviceBranch = '';
         customerAlternateContactNo = '';
         customerNationality = '';
         customerFatherName = '';
         customerMotherName = '';
         customerGuardianName = '';
         customerStatus = '';
         serviceTypeDescription = '';
         serviceContactModeDescription = '';
         serviceBranchDescription = '';
         serviceStatusDescription = '';
         serviceCommunicationTypeDescription = '';
         descriptionFlag = '';
         leadCreatedByFullname = '';
         trustAppliRefNo = '';
         trustType = '';
         applicationStage = '';
         serviceStatusValue = '';
         customerStatusValue = '';
         iDepartmentDDL = new entDDL();
         ientLeadDocument = new entLeadDocument();
         lstentLeadDocument: any = [];
         previousStatusValue = '';
         workflowId = 0;
         customerId = 0;
        
}

export class entLeadAssignedOfficer {
  leadAssignedOfficerId = 0;
         leadId = 0;
         assignedTo = '';
         assignedDate = '';
         assignedToFullname = '';
         assignedByFullname = '';
         assignedBy = '';
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entLeadAssignedOfficerList {
  entLeadAssignedOfficerList: any = [];
         ientLeadAssignedOfficer = new entLeadAssignedOfficer();
        
}

export class entLeadCommunicationHistory {
  leadCommunicationHistoryId = 0;
         leadId = 0;
         emailCommunicationId = 0;
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         sendBy = '';
         sendByFullname = '';
         sendDate = '';
         ientCommunicationTracking = new entCommunicationTracking();
         msg = new entIEMessage();
         idoObjState = '';
         updateSeq = 0;
        
}

export class entLeadCommunicationHistoryList {
  entLeadCommunicationHistoryList: any = [];
         ientLeadCommunicationHistory = new entLeadCommunicationHistory();
         msg = new entIEMessage();
        
}

export class entLeadDocument {
  leadDocumentId = 0;
         leadId = 0;
         docTypeId = 0;
         docTypeValue = '';
         otherDocName = '';
         fileId = 0;
         enteredBy = '';
         enteredDate = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         ientFile = new entFile();
         createdByFullname = '';
         createdDate = '';
         isMandatory = '';
         docTypeDescription = '';
         leadRefNo = '';
         docRefNo = '';
         sourceId = 0;
         sourceValue = '';
         sourceDescription = '';
        
}

export class entLeadDocumentList {
  lstentLeadDocument: any = [];
         msg = new entIEMessage();
         ientLeadDocument = new entLeadDocument();
        
}

export class entLeadList {
  entLeadList: any = [];
         ientLead = new entLead();
         msg = new entIEMessage();
        
}

export class entLeadNotes {
  leadNoteId = 0;
         leadId = 0;
         notes = '';
         enteredBy = '';
         enteredByFullname = '';
         enteredDate = '';
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         ientDDL = new entDDL();
        
}

export class entLeadNotesList {
  entLeadNotesList: any = [];
         ientLeadNotes = new entLeadNotes();
         msg = new entIEMessage();
        
}

export class entLeadStatusHistory {
  leadStatusHistoryId = 0;
         leadId = 0;
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         changedBy = '';
         changedByFullname = '';
         changedDate = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entLeadStatusHistoryList {
  lstentLeadStatusHistory: any = [];
         msg = new entIEMessage();
        
}

export class entLegalApplication {
  legalApplicationId = 0;
         legalApplRefNo = '';
         leadId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         appliedBy = '';
         appliedDate = '';
         appliedBranchId = 0;
         appliedBranchValue = '';
         enteredBy = '';
         enteredDate = '';
         statusId = 0;
         statusValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         editableIdentificationNo = 0;
         ientLegalApplicationApplicant = new entLegalApplicationApplicant();
         lstentLegalApplicationApplicant: any = [];
         ientLegalApplicationDocument = new entLegalApplicationDocument();
         lstentLegalApplicationDocument: any = [];
         ientLegalApplicationStatusHistory = new entLegalApplicationStatusHistory();
         lstentLegalApplicationStatusHistory: any = [];
         ientLegalApplicationEmailHistory = new entLegalApplicationEmailHistory();
         lstentLegalApplicationEmailHistory: any = [];
         ientLegalApplicationNotes = new entLegalApplicationNotes();
         lstentLegalApplicationNotes: any = [];
         ientLegalApplicationAssignedOfficerHistory = new entLegalApplicationAssignedOfficerHistory();
         lstentLegalApplicationAssignedOfficerHistory: any = [];
         workflowId = 0;
         statusDescription = '';
         appliedBranchDescription = '';
         enteredByFullname = '';
         appliedByFullname = '';
         previousStatusValue = '';
         applicationStageDescription = '';
         assignedOfficerFlag = '';
         reAssignFlag = '';
         selfAssignFlag = '';
         actionStatusDescription = '';
         previousActionStatusValue = '';
         previousStageValue = '';
         workloadBasedOnflag = '';
         trustAssignedToFullname = '';
         leadAssignedDepartment = '';
         leadAssignedDepartmentValue = '';
         leadRefNo = '';
         isCompleted = '';
         identifierCount = 0;
         serviceTypeId = 0;
         serviceTypeValue = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         ientLegalApplicationRejectHistory = new entLegalApplicationRejectHistory();
         lstentLegalApplicationRejectHistory: any = [];
         ientFptclFile = new entFptclFile();
         lstentFptclFile: any = [];
        
}

export class entLegalApplicationApplicant {
  legalApplicationApplicantId = 0;
         legalApplicationId = 0;
         customerId = 0;
         ientCustomer = new entCustomer();
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         customerDdlFlage = '';
        
}

export class entLegalApplicationApplicantlist {
  lstentLegalApplicationApplicant: any = [];
         ientLegalApplicationApplicant = new entLegalApplicationApplicant();
         msg = new entIEMessage();
        
}

export class entLegalApplicationAssignedOfficerHistory {
  legalApplicationAssignedOfficerHistoryId = 0;
         legalApplicationId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         statusId = 0;
         statusValue = '';
         assignedTo = '';
         assignedBy = '';
         assignedDate = '';
         identificationNo = 0;
         assignedToFullname = '';
         assignedByFullname = '';
         designation = '';
         actionStatusDescription = '';
         applicationStageDescription = '';
         statusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entLegalApplicationAssignedOfficerHistoryList {
  lstentLegalApplicationAssignedOfficerHistory: any = [];
         ientLegalApplicationAssignedOfficerHistory = new entLegalApplicationAssignedOfficerHistory();
         msg = new entIEMessage();
        
}

export class entLegalApplicationDocument {
  legalApplicationDocumentId = 0;
         legalApplicationId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         applicationStatusId = 0;
         applicationStatusValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         documentTypeId = 0;
         documentTypeValue = '';
         fileId = 0;
         isMandatory = '';
         identificationNo = 0;
         enteredBy = '';
         enteredDate = '';
         ientFile = new entFile();
         documentTypeDescription = '';
         legalApplicationRefNo = '';
         enteredByFullname = '';
         applicationStageDescription = '';
         trustTypeDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entLegalApplicationDocumentList {
  lstentLegalApplicationDocument: any = [];
         ientLegalApplicationDocument = new entLegalApplicationDocument();
         msg = new entIEMessage();
        
}

export class entLegalApplicationEmailHistory {
  legalApplicationEmailHistoryId = 0;
         legalApplicationId = 0;
         communicationTrackingId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         statusId = 0;
         statusValue = '';
         sendBy = '';
         sendDate = '';
         identificationNo = 0;
         ientCommunicationTracking = new entCommunicationTracking();
         statusDescription = '';
         sendByFullname = '';
         applicationStageDescription = '';
         actionStatusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entLegalApplicationEmailHistoryList {
  lstentLegalApplicationEmailHistory: any = [];
         ientLegalApplicationEmailHistory = new entLegalApplicationEmailHistory();
         msg = new entIEMessage();
        
}

export class entLegalApplicationNotes {
  legalApplicationNotesId = 0;
         legalApplicationId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         applicationStatusId = 0;
         applicationStatusValue = '';
         notes = '';
         identificationNo = 0;
         enteredDate = '';
         enteredBy = '';
         iActionStatusDDL = new entDDL();
         iStatusDDL = new entDDL();
         applicationStatusDescription = '';
         enteredByFullname = '';
         isUpdateButtonShow = '';
         actionStatusDescription = '';
         applicationStageDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entLegalApplicationNotesList {
  lstentLegalApplicationNotes: any = [];
         ientLegalApplicationNotes = new entLegalApplicationNotes();
         msg = new entIEMessage();
        
}

export class entLegalApplicationRejectHistory {
  legalApplicationId = 0;
         legalApplicationStageValue = '';
         legalApplicationIdenityNo = 0;
         legalApplicationRejectHistoryId = 0;
         isEditable = '';
        
}

export class entLegalApplicationSearch {
  legalApplRefNo = '';
         serviceTypeValue = '';
         applicationStageValue = '';
         appliedBranchValue = '';
         statusValue = '';
         actionStatusValue = '';
         customerId = 0;
         applicantCrmNo = '';
         enteredDateFrom = '';
         enteredDateTo = '';
         enteredBy = '';
         appliedBy = '';
         appliedDateFrom = '';
         appliedDateTo = '';
         pageSize = 0;
         pageNumber = 0;
         orderByColumnName = '';
         ascending = '';
         istrSortColumn = '';
         istrSortOrder = false;
         applicantName = '';
        
}

export class entLegalApplicationSearchResult {
  totalCount = 0;
         pageSize = 0;
         pageNumber = 0;
         result: any = [];
        
}

export class entLegalApplicationSearchResultSet {
  legalApplicationId = 0;
         legalApplRefNo = '';
         serviceTypeDescription = '';
         serviceTypeValue = '';
         applicationStageDescription = '';
         applicationStageValue = '';
         appliedBranchValue = '';
         appliedBranchDescription = '';
         actionStatusValue = '';
         actionStatusDescription = '';
         appliedDate = '';
         applicantName = '';
         applicantCrmNo = '';
         statusDescription = '';
         statusValue = '';
        
}

export class entLegalApplicationStatusHistory {
  legalApplicationStatusHistoryId = 0;
         legalApplicationId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         statusId = 0;
         statusValue = '';
         changedBy = '';
         changedDate = '';
         identificationNo = 0;
         statusDescription = '';
         actionStatusDescription = '';
         applicationStageDescription = '';
         changedByFullname = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entLegalApplicationStatusHistoryList {
  lstentLegalApplicationStatusHistory: any = [];
         ientLegalApplicationStatusHistory = new entLegalApplicationStatusHistory();
         msg = new entIEMessage();
        
}

export class entListTrustApplicationApplicant {
  lstentTrustApplicationApplicant: any = [];
         ientTrustApplicationApplicant = new entTrustApplicationApplicant();
         msg = new entIEMessage();
        
}

export class entListTrustApplicationBenificiary {
  lstentTrustApplicationBenificiary: any = [];
         ientTrustApplicationBenificiary = new entTrustApplicationBenificiary();
         msg = new entIEMessage();
        
}

export class entListTrustApplicationCheckList {
  lstentTrustApplicationCheckList: any = [];
         ientTrustApplicationCheckList = new entTrustApplicationCheckList();
         msg = new entIEMessage();
        
}

export class entListTrustWithdrawalApplicationChecklist {
  lstentTrustWithdrawalApplicationChecklist: any = [];
         msg = new entIEMessage();
         ientTrustWithdrawalApplicationChecklist = new entTrustWithdrawalApplicationChecklist();
        
}

export class entLongData {
  data = 0;
         msg = new entIEMessage();
        
}

export class entLongData1 {
  data1 = 0;
         data2 = 0;
         msg = new entIEMessage();
        
}

export class entLongData2 {
  data1 = 0;
         data2 = 0;
         data3 = 0;
         data4 = '';
         msg = new entIEMessage();
        
}

export class entLongStringData {
  data = 0;
         data1 = '';
         msg = new entIEMessage();
        
}

export class entMsgDetail {
  msgID = 0;
         msgType = 0;
         msgDescription = '';
        
}

export class entOrganization {
  contactNo = '';
         effectiveDate = '';
         emailId = '';
         orgRefNo = '';
         organizationId = 0;
         organizationName = '';
         organizationTypeId = 0;
         organizationTypeValue = '';
         registeredAddressId = 0;
         statusId = 0;
         statusValue = '';
         website = '';
         idoObjState = '';
         updateSeq = 0;
         statusDescription = '';
         msg = new entIEMessage();
         lstentOrganizationBankDetail: any = [];
         lstentOrganizationContactPerson: any = [];
         lstentOrganizationDocument: any = [];
         ientOrganizationBankDetail = new entOrganizationBankDetail();
         ientOrganizationContactPerson = new entOrganizationContactPerson();
         ientOrganizationDocument = new entOrganizationDocument();
         ipermanentAddress = new entAddress();
         organizationTypeDescription = '';
         enteredBy = '';
         enteredDate = '';
         enterdedByFullName = '';
         appliedByFullName = '';
         branchId = 0;
        
}

export class entOrganizationApplicaitonSearchResult {
  totalCount = 0;
         pageSize = 0;
         pageNumber = 0;
         result: any = [];
        
}

export class entOrganizationApplication {
  applicationRefNo = '';
         applicationTypeId = 0;
         applicationTypeValue = '';
         contactNo = '';
         effectiveDate = '';
         emailId = '';
         oldValue = '';
         orgStatusId = 0;
         orgStatusValue = '';
         organizationApplicationId = 0;
         organizationId = 0;
         organizationName = '';
         organizationTypeId = 0;
         organizationTypeValue = '';
         registeredAddressId = 0;
         statusId = 0;
         statusValue = '';
         website = '';
         idoObjState = '';
         updateSeq = 0;
         statusDescription = '';
         applicationTypeDescription = '';
         ipermanentAddress = new entAddress();
         msg = new entIEMessage();
         organizationTypeDescription = '';
         orgStatusDescription = '';
         lstentOrganizationApplicationAssignedOfficerHistory: any = [];
         lstentOrganizationApplicationBankDetail: any = [];
         lstentOrganizationApplicationContactPerson: any = [];
         lstentOrganizationApplicationDocument: any = [];
         lstentOrganizationApplicationEmailHistory: any = [];
         lstentOrganizationApplicationNotes: any = [];
         lstentOrganizationApplicationStatusHistory: any = [];
         ientOrganizationApplicationAssignedOfficerHistory = new entOrganizationApplicationAssignedOfficerHistory();
         ientOrganizationApplicationBankDetail = new entOrganizationApplicationBankDetail();
         ientOrganizationApplicationContactPerson = new entOrganizationApplicationContactPerson();
         ientOrganizationApplicationDocument = new entOrganizationApplicationDocument();
         ientOrganizationApplicationEmailHistory = new entOrganizationApplicationEmailHistory();
         ientOrganizationApplicationNotes = new entOrganizationApplicationNotes();
         ientOrganizationApplicationStatusHistory = new entOrganizationApplicationStatusHistory();
         assignedOfficerFlag = '';
         selfAssignFlag = '';
         reAssignFlag = '';
         branchId = 0;
         workflowId = 0;
         previousStatusValue = '';
         ientOrganization = new entOrganization();
        
}

export class entOrganizationApplicationAssignedOfficerHistory {
  assignedBy = '';
         assignedDate = '';
         assignedTo = '';
         organizationAppplicationAssignedOfficerHistoryId = 0;
         organizationApplicationId = 0;
         statusId = 0;
         statusValue = '';
         idoObjState = '';
         updateSeq = 0;
         statusDescription = '';
         msg = new entIEMessage();
         assingnedByFullName = '';
         assingnedToFullName = '';
        
}

export class entOrganizationApplicationAssignedOfficerHistoryList {
  lstentOrganizationApplicationAssignedOfficerHistory: any = [];
         msg = new entIEMessage();
        
}

export class entOrganizationApplicationBankDetail {
  accountNo = '';
         bankId = 0;
         oldValue = '';
         organizationApplicationBankDetailId = 0;
         organizationApplicationId = 0;
         organizationBankDetailId = 0;
         statusId = 0;
         statusValue = '';
         idoObjState = '';
         updateSeq = 0;
         statusDescription = '';
         msg = new entIEMessage();
         ientBank = new entBank();
         lstentBank: any = [];
         editableFlag = '';
        
}

export class entOrganizationApplicationBankDetailList {
  lstentOrganizationApplicationBankDetail: any = [];
         lentOrganizationApplicationBankDetail = new entOrganizationApplicationBankDetail();
         msg = new entIEMessage();
        
}

export class entOrganizationApplicationContactPerson {
  contactNo = '';
         contactPersonName = '';
         dateOfBirth = '';
         designation = '';
         drivingLicense = '';
         emailId = '';
         genderId = 0;
         genderValue = '';
         nationalId = '';
         oldValue = '';
         organizationApplicationContactPersonId = 0;
         organizationApplicationId = 0;
         organizationContactPersonId = 0;
         pfNo = '';
         statusId = 0;
         statusValue = '';
         voterId = '';
         idoObjState = '';
         updateSeq = 0;
         statusDescription = '';
         genderDescription = '';
         msg = new entIEMessage();
        
}

export class entOrganizationApplicationContactPersonList {
  lstentOrganizationApplicationContactPerson: any = [];
         lentOrganizationApplicationContactPerson = new entOrganizationApplicationContactPerson();
         msg = new entIEMessage();
        
}

export class entOrganizationApplicationDocument {
  documentId = 0;
         documentTypeId = 0;
         documentTypeValue = '';
         isMandatory = '';
         organizationApplicationDocumentId = 0;
         organizationApplicationId = 0;
         idoObjState = '';
         updateSeq = 0;
         documentTypeDescription = '';
         msg = new entIEMessage();
         organizationDocumentId = 0;
         ientFile = new entFile();
         uploadedBy = '';
         uploadedDate = '';
         uploadedByFullName = '';
        
}

export class entOrganizationApplicationDocumentList {
  lstentOrganizationApplicationDocument: any = [];
         msg = new entIEMessage();
        
}

export class entOrganizationApplicationEmailHistory {
  communicationTrackingId = 0;
         organizationApplicationEmialHistoryId = 0;
         organizationApplicationId = 0;
         sendBy = '';
         sendDate = '';
         statusId = 0;
         statusValue = '';
         idoObjState = '';
         updateSeq = 0;
         statusDescription = '';
         msg = new entIEMessage();
         ientCommunicationTracking = new entCommunicationTracking();
         sendOfficerFullName = '';
        
}

export class entOrganizationApplicationEmailHistoryList {
  lstentOrganizationApplicationEmailHistory: any = [];
         msg = new entIEMessage();
        
}

export class entOrganizationApplicationNotes {
  content = '';
         enteredBy = '';
         enteredDate = '';
         organizationApplicationNoteId = 0;
         organizationApplicationId = 0;
         statusId = 0;
         statusValue = '';
         msg = new entIEMessage();
         idoObjState = '';
         updateSeq = 0;
         ientDDL = new entDDL();
         statusDescription = '';
         enteredByFullName = '';
        
}

export class entOrganizationApplicationNotesList {
  lstentOrganizationApplicationNotes: any = [];
         msg = new entIEMessage();
        
}

export class entOrganizationApplicationSearch {
  applicationRefNo = '';
         organizationName = '';
         organizationTypeValue = '';
         emailId = '';
         contactNo = '';
         website = '';
         effectiveDateFrom = '';
         statusValue = '';
         applicationTypeValue = '';
         pageSize = 0;
         pageNumber = 0;
         orderByColumnName = '';
         ascending = false;
         istrSortColumn = '';
         istrSortOrder = false;
         effectiveDateTo = '';
        
}

export class entOrganizationApplicationSearchResultSet {
  organizationName = '';
         applicationRefNo = '';
         organizationTypeDescription = '';
         effectiveDate = '';
         statusDescription = '';
         organizationApplicationId = 0;
        
}

export class entOrganizationApplicationStatusHistory {
  changedBy = '';
         changedDate = '';
         organizationApplicationId = 0;
         organizationApplicationStatusHistoryId = 0;
         statusId = 0;
         statusValue = '';
         idoObjState = '';
         updateSeq = 0;
         statusDescription = '';
         changedByFullName = '';
        
}

export class entOrganizationApplicationStatusHistoryList {
  lstentOrganizationApplicationStatusHistory: any = [];
         msg = new entIEMessage();
        
}

export class entOrganizationBankDetail {
  accountNo = '';
         bankId = 0;
         organizationBankDetailId = 0;
         organizationId = 0;
         statusId = 0;
         statusValue = '';
         idoObjState = '';
         updateSeq = 0;
         statusDescription = '';
         msg = new entIEMessage();
         ientBank = new entBank();
         lstentBank: any = [];
        
}

export class entOrganizationContactPerson {
  contactNo = '';
         contactPersonName = '';
         dateOfBirth = '';
         designation = '';
         drivingLicense = '';
         emailId = '';
         genderId = 0;
         genderValue = '';
         nationalId = '';
         organizationContactPersonId = 0;
         organizationId = 0;
         pfNo = '';
         statusId = 0;
         statusValue = '';
         voterId = '';
         idoObjState = '';
         updateSeq = 0;
         statusDescription = '';
         genderDescription = '';
         msg = new entIEMessage();
        
}

export class entOrganizationDocument {
  documentId = 0;
         documentTypeId = '';
         documentTypeValue = '';
         isMandatory = '';
         organizationDocumentId = 0;
         organizationId = 0;
         idoObjState = '';
         updateSeq = 0;
         documentTypeDescription = '';
         msg = new entIEMessage();
         ientFile = new entFile();
         uploadedBy = '';
         uploadedDate = '';
         uploadedByFullName = '';
        
}

export class entOrganizationSearch {
  organizationName = '';
         organizationTypeValue = '';
         emailId = '';
         contactNo = '';
         website = '';
         statusValue = '';
         pageSize = 0;
         pageNumber = 0;
         orderByColumnName = '';
         ascending = false;
         istrSortColumn = '';
         istrSortOrder = false;
         effectiveDateFrom = '';
         effectiveDateTo = '';
         orgRefNo = '';
        
}

export class entOrganizationSearchResult {
  totalCount = 0;
         pageSize = 0;
         pageNumber = 0;
         result: any = [];
        
}

export class entOrganizationSearchResultSet {
  organizationName = '';
         orgRefNo = '';
         organizationDescription = '';
         effectiveDate = '';
         statusDescription = '';
         organizationId = 0;
        
}

export class entPassingParam {
  intData1 = 0;
         intData2 = 0;
         intData3 = 0;
         strData1 = '';
         strData2 = '';
         strData3 = '';
         strData4 = '';
         strData5 = '';
         longData1 = 0;
         longData2 = 0;
         longData3 = 0;
         msg = new entIEMessage();
        
}

export class entProbateRegistry {
  probateRegistryId = 0;
         probateRegistryRefNo = '';
         deathNoticeId = 0;
         ientProbateRegistryStatus = new entProbateRegistryStatus();
         ilstentProbateRegistryStatus: any = [];
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entProbateRegistryStatus {
  probateRegistryStatusId = 0;
         probateRegistryId = 0;
         statusId = 0;
         statusValue = '';
         fileId = 0;
         statusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         ientFile = new entFile();
         deathNoticeId = 0;
        
}

export class entProbateRegistryStatusList {
  ientProbateRegistryStatus = new entProbateRegistryStatus();
         ilstentProbateRegistryStatus: any = [];
         msg = new entIEMessage();
        
}

export class entString2Int1 {
  data1 = 0;
         data2 = '';
         data3 = '';
         msg = new entIEMessage();
        
}

export class entStringData {
  data = '';
         msg = new entIEMessage();
        
}

export class entStringData1 {
  data = '';
         data1 = '';
         msg = new entIEMessage();
        
}

export class entStringData3 {
  data1 = '';
         data2 = '';
         data3 = '';
         msg = new entIEMessage();
        
}

export class entTrust {
  trustId = 0;
         trustRefNo = '';
         legacyRefNo = '';
         legacyFileNo = '';
         startDate = '';
         cashLedgerId = 0;
         nonCashLedgerId = 0;
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         fileNo = '';
         trustAccountNo = '';
         trustRegisterId = 0;
         ientTrustDocument = new entTrustDocument();
         ientTrustBenificiary = new entTrustBenificiary();
         lstentTrustBenificiary: any = [];
         lstentTrustDocument: any = [];
         idoObjState = '';
         updateSeq = 0;
         previuousStatusValue = '';
         trustApplicationId = 0;
        
}

export class entTrustApplicant {
  trustApplicantId = 0;
         trustId = 0;
         customerId = 0;
         isPrimaryApplicant = '';
         idoObjState = '';
         updateSeq = 0;
         ientCustomer = new entCustomer();
        
}

export class entTrustApplicantList {
  lstentTrustApplicant: any = [];
         ientTrustApplicant = new entTrustApplicant();
         msg = new entIEMessage();
        
}

export class entTrustApplication {
  trustApplicationId = 0;
         trustApplRefNo = '';
         trustTypeId = 0;
         trustTypeValue = '';
         trustTypeDescription = '';
         appliedBy = '';
         appliedByFullname = '';
         appliedDate = '';
         eneredBy = '';
         enteredByFullname = '';
         enteredDate = '';
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         ientTrustApplicationApplicant = new entTrustApplicationApplicant();
         ientTrustApplicationBenificiary = new entTrustApplicationBenificiary();
         entTrustApplicationApplicantList: any = [];
         entTrustApplicationBenificiaryList: any = [];
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         previousStatusValue = '';
         ientTrustApplicationCheckList = new entTrustApplicationCheckList();
         lstentTrustApplicationCheckList: any = [];
         ientTrustApplicationDocument = new entTrustApplicationDocument();
         lstentTrustApplicationDocument: any = [];
         ientTrustApplicationEmailHistory = new entTrustApplicationEmailHistory();
         lstentTrustApplicationEmailHistory: any = [];
         ientTrustApplicationNotes = new entTrustApplicationNotes();
         lstentTrustApplicationNotes: any = [];
         ientTrustApplicationStatusHistory = new entTrustApplicationStatusHistory();
         lstentTrustApplicationStatusHistory: any = [];
         applicationStageId = 0;
         applicationStageValue = '';
         applicationStageDescription = '';
         ientTrustApplicationAssignedOfficer = new entTrustApplicationAssignedOfficer();
         lstentTrustApplicationAssignedOfficer: any = [];
         fileNo = '';
         actionStatusId = 0;
         actionStatusValue = '';
         actionStatusDescription = '';
         assignedOfficerFlag = '';
         reAssignFlag = '';
         selfAssignFlag = '';
         trustRegNo = '';
         trustName = '';
         receiptNo = '';
         appliedBranchId = 0;
         appliedBranchValue = '';
         appliedBranchDescription = '';
         additionalNotes = '';
         trustOfficerAssigned = '';
         settledAmount = '';
         dateOfTrustDeed = '';
         trustAssignedToFullname = '';
         leadId = 0;
         leadRefNo = '';
         leadAssignedDepartment = '';
         leadAssignedDepartmentValue = '';
         ientTrustApplicationClient = new entTrustApplicationClient();
         lstentTrustApplicationClient: any = [];
         ientTrustApplicationTrustee = new entTrustApplicationTrustee();
         lstentTrustApplicationTrustee: any = [];
         ientTrustApplicationsettlor = new entTrustApplicationSettlor();
         lstentTrustApplicationsettlor: any = [];
         workflowId = 0;
         trustAccountNo = '';
         ientTrustApplicationCourtOrder = new entTrustApplicationCourtOrder();
         isCompleted = '';
         isCourtRequired = '';
         trustAccountStatus = '';
         ientTrustApplicationRejectHistory = new entTrustApplicationRejectHistory();
         lstentTrustApplicationRejectHistory: any = [];
         identifierCount = 0;
         clientDocumentCount = 0;
         courtOrderCount = 0;
         legalServiceOfficerId = '';
         previousStageValue = '';
         previousActionStatusValue = '';
         ientTrustRegister = new entTrustRegister();
         lstentTrustRegister: any = [];
         ientFptclAccountNo = new entFptclAccountNo();
         lstentFptclAccountNo: any = [];
         ientFptclFile = new entFptclFile();
         lstentFptclFile: any = [];
         modifiedDate = '';
         trustApplicationCompleted = '';
         createButtonHide = '';
        
}

export class entTrustApplicationApplicant {
  trustApplicationApplicantId = 0;
         trustApplicationId = 0;
         customerId = 0;
         isPrimaryApplicant = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         ientCustomer = new entCustomer();
         childrenName = '';
         contactNo = '';
         emailId = '';
         ientTrustApplicationParentAddtionalInfo = new entTrustApplicationParentAddtionalInfo();
         lstentTrustApplicationParentAddtionalInfo: any = [];
        
}

export class entTrustApplicationAssignedOfficer {
  trustApplicationAssignedOfficerHistoryId = 0;
         trustApplicationId = 0;
         assignedTo = '';
         assignedDate = '';
         assignedToFullname = '';
         assignedByFullname = '';
         assignedBy = '';
         actionStatusId = 0;
         actionStatusValue = '';
         actionStatusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         applicationStageId = 0;
         applicationStageValue = '';
         applicationStageDescription = '';
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         tatDays = 0;
         tatHrs = 0;
         tatMin = 0;
         tatSec = 0;
         verificationDate = '';
         designation = '';
         identityNo = 0;
        
}

export class entTrustApplicationAssignedOfficerList {
  entTrustApplicationAssignedOfficerList: any = [];
         ientTrustApplicationAssignedOfficer = new entTrustApplicationAssignedOfficer();
        
}

export class entTrustApplicationBenificiary {
  trustApplicationBeneficiaryId = 0;
         trustApplicationId = 0;
         beneficaryCustomerId = 0;
         isMinor = '';
         gaurdianCustomerId = 0;
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         benificiaryDateOfbirth = '';
         ientBeneficaryCustomer = new entCustomer();
         ientGaurdianCustomer = new entCustomer();
         relationshipId = 0;
         relationshipValue = '';
         gaurdianDateOfbirth = '';
         relationshipDescription = '';
         nomination = '';
         benificiaryAge = 0;
        
}

export class entTrustApplicationCheckList {
  trustApplicationChecklistId = 0;
         trustApplicationId = 0;
         checklistName = '';
         isMandatory = '';
         checkedBy = '';
         checkedDatetime = '';
         applicationStageId = 0;
         applicationStageValue = '';
         checkedByFullname = '';
         applicationStageDescription = '';
         isChecked = '';
         idoObjState = '';
         updateSeq = 0;
         currentTrustTypeValue = '';
         identityNo = 0;
        
}

export class entTrustApplicationClient {
  trustApplicationClientId = 0;
         trustApplicationId = 0;
         customerId = 0;
         isPrimaryClient = '';
         idoObjState = '';
         updateSeq = 0;
         ientCustomer = new entCustomer();
         ientTrustApplicationClientOrg = new entTrustApplicationClientOrg();
         lstentTrustApplicationClientOrg: any = [];
        
}

export class entTrustApplicationClientList {
  lstentTrustApplicationClient: any = [];
         ientTrustApplicationClient = new entTrustApplicationClient();
         msg = new entIEMessage();
        
}

export class entTrustApplicationClientOrg {
  trustApplicationClientOrgId = 0;
         trustApplictionClientId = 0;
         organizationName = '';
         settlementAmount = '';
         nomineeName = '';
         nomineeDob = '';
         idoObjState = '';
         updateSeq = 0;
         trustApplicationId = 0;
         msg = new entIEMessage();
        
}

export class entTrustApplicationClientOrgList {
  lstentTrustApplicationClientOrg: any = [];
         ientTrustApplicationClientOrg = new entTrustApplicationClientOrg();
         msg = new entIEMessage();
        
}

export class entTrustApplicationCourtOrder {
  trustApplicationCourtOrderId = 0;
         trustApplicationId = 0;
         tlOfficerId = 0;
         tlVerification = '';
         metOfficerId = 0;
         metVerification = '';
         mlOfficerId = 0;
         mlVerification = '';
         legalOfficerId = 0;
         courtOrderDocumentId = 0;
         courtOrderNotes = '';
         lstentTrustApplicationCourtOrder: any = [];
         tlDesignation = '';
         tlUserName = '';
         metDesignation = '';
         metUserName = '';
         mlDesignation = '';
         mlUserName = '';
         legalOfficerName = '';
        
}

export class entTrustApplicationDocument {
  trustApplicationDocumentId = 0;
         trustApplicationId = 0;
         documentTypeId = 0;
         documentTypeValue = '';
         documentTypeDescription = '';
         otherDocName = '';
         fileId = 0;
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         ientFile = new entFile();
         enteredDate = '';
         enteredBy = '';
         isMandatory = '';
         enteredByFullname = '';
         trustApplicationRefNo = '';
         trustTypeDescription = '';
         trustTypeId = 0;
         trustTypeValue = '';
         applicationStageId = 0;
         applicationStageValue = '';
         applicationStageDescription = '';
         identityNo = 0;
        
}

export class entTrustApplicationDocumentList {
  lstentTrustApplicationDocument: any = [];
         msg = new entIEMessage();
         ientTrustApplicationDocument = new entTrustApplicationDocument();
        
}

export class entTrustApplicationEmailHistory {
  trustApplicationEmailHistoryId = 0;
         trustApplicationId = 0;
         emialCommunicationId = 0;
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         sendBy = '';
         sendByFullname = '';
         sendDate = '';
         ientCommunicationTracking = new entCommunicationTracking();
         msg = new entIEMessage();
         idoObjState = '';
         updateSeq = 0;
         actionStatusId = 0;
         actionStatusValue = '';
         actionStatusDescription = '';
         applicationStageId = 0;
         applicationStageDescription = '';
         applicationStageValue = '';
         identityNo = 0;
        
}

export class entTrustApplicationEmailHistoryList {
  entTrustApplicationEmailHistoryList: any = [];
         ientTrustApplicationEmailHistory = new entTrustApplicationEmailHistory();
         msg = new entIEMessage();
        
}

export class entTrustApplicationNotes {
  trustApplicationNotesId = 0;
         trustApplicationId = 0;
         notes = '';
         enteredBy = '';
         enteredDate = '';
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         iActionStatusDDL = new entDDL();
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         iStatusDDL = new entDDL();
         actionStatusId = 0;
         actionStatusValue = '';
         enteredByFullname = '';
         actionStatusDescription = '';
         applicationStageId = 0;
         applicationStageValue = '';
         applicationStageDescription = '';
         identityNo = 0;
         isUpdateButtonShow = '';
        
}

export class entTrustApplicationNotesList {
  lstentTrustApplicationNotes: any = [];
         lentTrustApplicationNotes = new entTrustApplicationNotes();
         msg = new entIEMessage();
        
}

export class entTrustApplicationParentAddtionalInfo {
  trustApplicationParentAddtionalInfoId = 0;
         trustApplicationApplicantId = 0;
         childrenName = '';
         dateOfBirth = '';
         genderId = 0;
         genderValue = '';
         idoObjState = '';
         updateSeq = 0;
         genderDescription = '';
         msg = new entIEMessage();
        
}

export class entTrustApplicationParentAddtionalInfoList {
  lstentTrustApplicationParentAddtionalInfo: any = [];
         ientTrustApplicationParentAddtionalInfo = new entTrustApplicationParentAddtionalInfo();
         msg = new entIEMessage();
        
}

export class entTrustApplicationRejectHistory {
  trustApplicationId = 0;
         trustApplicationStageValue = '';
         trustApplicationIdenityNo = 0;
         trustApplicationRejectHistoryId = 0;
         isEditable = '';
        
}

export class entTrustApplicationSearch {
  trustApplRefNo = '';
         trustTypeValue = '';
         applicationStageValue = '';
         appliedBranchValue = '';
         statusValue = '';
         fileNo = '';
         actionStatusValue = '';
         enteredDateFrom = '';
         enteredDateTo = '';
         eneredBy = '';
         appliedBy = '';
         appliedDateFrom = '';
         appliedDateTo = '';
         pageSize = 0;
         pageNumber = 0;
         orderByColumnName = '';
         ascending = false;
         istrSortColumn = '';
         istrSortOrder = false;
         assignedOfficer = '';
         applicantName = '';
         applicantCrmNo = '';
         settledAmountFrom = '';
         settledAmountTo = '';
         trusDeedDateFrom = '';
         trusDeedDateTo = '';
         trustAccountNo = '';
         customerId = 0;
        
}

export class entTrustApplicationSearchResult {
  totalCount = 0;
         pageSize = 0;
         pageNumber = 0;
         result: any = [];
        
}

export class entTrustApplicationSearchResultSet {
  trustApplicationId = 0;
         trustApplRefNo = '';
         trustTypeDescription = '';
         stageDescription = '';
         branchDescription = '';
         actionStatusDescription = '';
         appliedDate = '';
         fileNo = '';
         trustAccountNo = '';
         applicantName = '';
         applicantCrmNo = '';
         settledAmount = '';
         trusDeedDate = '';
         statusDescription = '';
         assignedOfficer = '';
         trustType = '';
         stage = '';
         branch = '';
         actionStatus = '';
         status = '';
        
}

export class entTrustApplicationSettlor {
  trustApplicationSettlorId = 0;
         trustApplicationId = 0;
         settlorName = '';
         isFptcl = '';
         idoObjState = '';
         updateSeq = 0;
         createdByFullname = '';
         createdDate = '';
         customerId = 0;
         ientCustomer = new entCustomer();
        
}

export class entTrustApplicationSettlorList {
  lstentTrustApplicationSettlor: any = [];
         ientTrustApplicationSettlor = new entTrustApplicationSettlor();
         msg = new entIEMessage();
        
}

export class entTrustApplicationStatusHistory {
  trustApplicationStatusHistoryId = 0;
         trustApplicationId = 0;
         statusId = 0;
         statusValue = '';
         statusDescription = '';
         changedBy = '';
         changedDate = '';
         changedByFullname = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         actionStatusId = 0;
         actionStatusValue = '';
         actionStatusDescription = '';
         applicationStageId = 0;
         applicationStageValue = '';
         applicationStageDescription = '';
         identityNo = 0;
        
}

export class entTrustApplicationStatusHistoryList {
  listentTrustApplicationStatusHistory: any = [];
         msg = new entIEMessage();
        
}

export class entTrustApplicationTrustee {
  trustApplicationTrusteeId = 0;
         trustApplicationId = 0;
         trusteeName = '';
         isFptcl = '';
         idoObjState = '';
         updateSeq = 0;
         createdByFullname = '';
         createdDate = '';
         customerId = 0;
         ientCustomer = new entCustomer();
        
}

export class entTrustApplicationTrusteeList {
  lstentTrustApplicationTrustee: any = [];
         ientTrustApplicationTrustee = new entTrustApplicationTrustee();
         msg = new entIEMessage();
        
}

export class entTrustBenificiary {
  trustBeneficiaryId = 0;
         trustId = 0;
         beneficiaryCustomerId = 0;
         gaurdianCustomerId = 0;
         cashSharePercentage = '';
         nonCashSharePercentage = '';
         cashLedgerId = 0;
         idoObjState = '';
         updateSeq = 0;
         relationshipId = 0;
         relationshipDescription = '';
         relationshipValue = '';
         beneficiaryName = '';
         gurdianName = '';
        
}

export class entTrustDocument {
  trustDocumentId = 0;
         trustId = 0;
         documentTypeId = 0;
         documentTypeValue = '';
         documentTypeDescription = '';
         otherDocName = '';
         fileId = 0;
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         ientFile = new entFile();
         enteredDate = '';
         enteredBy = '';
         isMandatory = '';
         enteredByFullname = '';
        
}

export class entTrustDocumentList {
  lstentTrustDocument: any = [];
         msg = new entIEMessage();
         ientTrustDocument = new entTrustDocument();
        
}

export class entTrustRegister {
  trustRegisterId = 0;
         trustApplicationId = 0;
         registerRefNo = '';
         trustFolderName = '';
         fileNo = '';
         statusId = 0;
         statusValue = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         statusDescription = '';
        
}

export class entTrustSearch {
  trustApplRefNo = '';
         trustAccountNo = '';
         legacyRefNo = '';
         legacyFileNo = '';
         trustName = '';
         fileNo = '';
         statusValue = '';
         startDateFrom = '';
         startDateTo = '';
         pageSize = 0;
         pageNumber = 0;
         orderByColumnName = '';
         ascending = false;
         istrSortColumn = '';
         istrSortOrder = false;
        
}

export class entTrustSearchResult {
  totalCount = 0;
         pageSize = 0;
         pageNumber = 0;
         result: any = [];
        
}

export class entTrustSearchResultSet {
  trustId = 0;
         trustAccountNo = '';
         legacyRefNo = '';
         legacyFileNo = '';
         trustName = '';
         startDate = '';
         fileNo = '';
         statusDescription = '';
         trustApplRefNo = '';
        
}

export class entTrustSettlor {
  trustSettlorId = 0;
         trustId = 0;
         settlorName = '';
         isFptcl = '';
         idoObjState = '';
         updateSeq = 0;
         createdByFullname = '';
         createdDate = '';
        
}

export class entTrustSettlorList {
  lstentTrustSettlor: any = [];
         ientTrustSettlor = new entTrustSettlor();
         msg = new entIEMessage();
        
}

export class entTrustTrustee {
  trustTrusteeId = 0;
         trustId = 0;
         trusteeName = '';
         isFptcl = '';
         idoObjState = '';
         updateSeq = 0;
         createdByFullname = '';
         createdDate = '';
         customerId = 0;
         ientCustomer = new entCustomer();
        
}

export class entTrustTrusteeList {
  lstentTrustTrustee: any = [];
         ientTrustTrustee = new entTrustTrustee();
         msg = new entIEMessage();
        
}

export class entTrustWithdrawalApplication {
  trustWithdrawalApplicationId = 0;
         applicationRefNo = '';
         trustId = 0;
         trustAccountNo = '';
         withdrawalTypeId = 0;
         withdrawalTypeValue = '';
         appliedDate = '';
         appliedCustomerId = 0;
         requestedAmount = '';
         assignedOfficer = '';
         approvedAmount = '';
         availableAmount = '';
         eligibleAmount = '';
         leadId = 0;
         paymentModeId = 0;
         paymentModeValue = '';
         withdrawalTypeDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         previuousStatusValue = '';
         ientTrustWithdrawalApplicationDocument = new entTrustWithdrawalApplicationDocument();
         lstentTrustWithdrawalApplicationDocument: any = [];
         ientTrustWithdrawalApplicationEmailHistory = new entTrustWithdrawalApplicationEmailHistory();
         lstentTrustWithdrawalApplicationEmailHistory: any = [];
         ientTrustWithdrawalApplicationNotes = new entTrustWithdrawalApplicationNotes();
         lstentTrustWithdrawalApplicationNotes: any = [];
         ientTrustWithdrawalApplicationStatusHistory = new entTrustWithdrawalApplicationStatusHistory();
         lstentTrustWithdrawalApplicationStatusHistory: any = [];
         ientTrustWithdrawalApplicationAssignedOfficerHistory = new entTrustWithdrawalApplicationAssignedOfficerHistory();
         lstentTrustWithdrawalApplicationAssignedOfficerHistory: any = [];
         withdrawalModeId = 0;
         withdrawalModeValue = '';
         withdrawalSubTypeId = 0;
         withdrawalSubTypeValue = '';
         reasonForWithdrawal = '';
         withdrawlForOrganization = '';
         organizationId = 0;
         beneficiaryCustomerId = 0;
         relationshipTypeId = 0;
         relationshipTypeValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         actionStatusDescription = '';
         applicationStageId = 0;
         applicationStageValue = '';
         applicationStageDescription = '';
         applicationStatusId = 0;
         applicationStatusValue = '';
         applicationStatusDescription = '';
         appliedBranchId = 0;
         appliedBranchValue = '';
         appliedBranchDescription = '';
         modeOfApplicationId = 0;
         modeOfApplicationValue = '';
         modeOfApplicationDescription = '';
         enteredBy = '';
         enteredDate = '';
         editableIdentificationNo = 0;
         paymentModeDescription = '';
         relationshipTypeDescription = '';
         withdrawalModeDescription = '';
         withdrawalSubTypeDescription = '';
         inspectionDate = '';
         ientTrustWithdrawalApplicationChecklist = new entTrustWithdrawalApplicationChecklist();
         lstentTrustWithdrawalApplicationChecklist: any = [];
         leadRefNo = '';
         appliedByFullname = '';
         ientWithdrawalPayment = new entWithdrawalPayment();
         beneficiaryCustomerName = '';
         guardianName = '';
         organizationName = '';
         fileNo = '';
         accountName = '';
         aboveThereshold = '';
         ientTrustWithdrawalApplicationProcessHistory = new entTrustWithdrawalApplicationProcessHistory();
         lstentTrustWithdrawalApplicationProcessHistory: any = [];
         workflowId = 0;
         isCompleted = '';
         identifierCount = 0;
         assignedToFullname = '';
         enteredByFullname = '';
        
}

export class entTrustWithdrawalApplicationAssignedOfficerHistory {
  trustWithdrawalApplicationAssignedOfficerHistoryId = 0;
         trustWithdrawalApplicationId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         applicationStatusId = 0;
         applicationStatusValue = '';
         assignedTo = '';
         assignedDate = '';
         assignedBy = '';
         identificationNo = 0;
         verfiedDate = '';
         designation = '';
         assignedToFullname = '';
         assignedByFullname = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entTrustWithdrawalApplicationChecklist {
  trustWithdrawalApplicationChecklistId = 0;
         trustWithdrawalApplicationId = 0;
         checklistName = '';
         isMandatory = '';
         checkedBy = '';
         checkedDatetime = '';
         identificationNo = 0;
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entTrustWithdrawalApplicationDocument {
  trustWithdrawalApplicationDocumentId = 0;
         trustWithdrawalApplicationId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         applicationStatusId = 0;
         applicationStatusValue = '';
         documentTypeId = 0;
         documentTypeValue = '';
         fileId = 0;
         isMandatory = '';
         identificationNo = 0;
         enteredBy = '';
         enteredDate = '';
         ientFile = new entFile();
         documentTypeDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         applicationStatusDescription = '';
         applicationStageDescription = '';
         actionStatusDescription = '';
         trustApplicationRefNo = '';
        
}

export class entTrustWithdrawalApplicationDocumentList {
  lstentTrustWithdrawalApplicationDocument: any = [];
         msg = new entIEMessage();
         ientTrustWithdrawalApplicationDocument = new entTrustWithdrawalApplicationDocument();
        
}

export class entTrustWithdrawalApplicationEmailHistory {
  trustWithdrawalApplicationEmialHistoryId = 0;
         trustWithdrawalApplicationId = 0;
         communicationTrackingId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         applicationStatusId = 0;
         applicationStatusValue = '';
         identificationNo = 0;
         ientCommunicationTracking = new entCommunicationTracking();
         sendBy = '';
         sendDate = '';
         applicationStatusDescription = '';
         applicationStageDescription = '';
         actionStatusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entTrustWithdrawalApplicationNotes {
  trustWithdrawalApplicationNotesId = 0;
         trustWithdrawalApplicationId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         applicationStatusId = 0;
         applicationStatusValue = '';
         notes = '';
         enteredBy = '';
         enteredDate = '';
         identificationNo = 0;
         ientDDL = new entDDL();
         applicationStatusDescription = '';
         applicationStageDescription = '';
         actionStatusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         iStatusDDL = new entDDL();
         iActionStatusDDL = new entDDL();
        
}

export class entTrustWithdrawalApplicationProcessHistory {
  trustWithdrawalApplicationProcessHistoryId = 0;
         trustWithdrawalApplicationId = 0;
         trustWithdrawalApplicationStageId = 0;
         trustWithdrawalApplicationStageValue = '';
         identificationNo = 0;
         applicationStageDescription = '';
         isEditable = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entTrustWithdrawalApplicationStatusHistory {
  trustWithdrawalApplicationStatusHistoryId = 0;
         trustWithdrawalApplicationId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         applicationStatusId = 0;
         applicationStatusValue = '';
         identificationNo = 0;
         changedBy = '';
         changedDate = '';
         applicationStatusDescription = '';
         applicationStageDescription = '';
         actionStatusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entTrustWithdrawalSearch {
  applicationRefNo = '';
         trustAccountNo = '';
         leadRefNo = '';
         firstName = '';
         gaurdianName = '';
         withdrawalTypeValue = '';
         withdrawalSubTypeValue = '';
         appliedBranchValue = '';
         appliedDate = '';
         enteredBy = '';
         enteredDate = '';
         availableAmountFrom = '';
         availableAmountTo = '';
         applicationStageValue = '';
         actionStatusValue = '';
         applicationStatusValue = '';
         assignedOfficer = '';
         pageSize = 0;
         pageNumber = 0;
         orderByColumnName = '';
         ascending = false;
         sortColumn = '';
         sortOrder = false;
        
}

export class entTrustWithdrawalSearchResult {
  totalCount = 0;
         pageSize = 0;
         pageNumber = 0;
         result: any = [];
        
}

export class entTrustWithdrawalSearchResultSet {
  trustWithdrawalApplicationId = 0;
         applicationRefNo = '';
         trustAccountNo = '';
         leadRefNo = '';
         beneficiaryCustomerName = '';
         gaurdianName = '';
         enteredByFullname = '';
         appliedDate = '';
         enteredDate = '';
         withdrawalTypeDescription = '';
         withdrawalSubTypeDescription = '';
         appliedBranchDescription = '';
         applicationStageDescription = '';
         actionStatusDescription = '';
         assignedOfficer = '';
        
}

export class entWill {
  willId = 0;
         willApplicationId = 0;
         willApplRefNo = '';
         appliedBy = '';
         appliedDate = '';
         appliedBranchId = 0;
         appliedBranchValue = '';
         enteredBy = '';
         enteredDate = '';
         testatorId = 0;
         willDocId = 0;
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWillApplication {
  willApplicationId = 0;
         willApplRefNo = '';
         leadRefNo = '';
         applicationStageId = 0;
         applicationStageValue = '';
         applicationStageDescription = '';
         appliedBy = '';
         appliedDate = '';
         appliedBranchId = 0;
         appliedBranchValue = '';
         appliedBranchDescription = '';
         eneredBy = '';
         enteredDate = '';
         statusId = 0;
         statusValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         actionStatusDescription = '';
         testatorId = 0;
         willDocId = 0;
         ientWillApplicationNotes = new entWillApplicationNotes();
         lstentWillApplicationNotes: any = [];
         ientWillApplicationInvestmentDetails = new entWillApplicationInvestmentDetails();
         lstentWillApplicationInvestmentDetails: any = [];
         ientWillApplicationInsuranceDetails = new entWillApplicationInsuranceDetails();
         lstientWillApplicationInsuranceDetails: any = [];
         ientWillApplicationFinanceDetails = new entWillApplicationFinanceDetails();
         lstentWillApplicationFinanceDetails: any = [];
         ientWillApplicationEmailHistory = new entWillApplicationEmailHistory();
         lstentWillApplicationEmailHistory: any = [];
         ientWillApplicationDocument = new entWillApplicationDocument();
         lstentWillApplicationDocument: any = [];
         ientWillApplicationChildren = new entWillApplicationChildren();
         lstentWillApplicationChildren: any = [];
         ientWillApplicationAssignedOfficerHistory = new entWillApplicationAssignedOfficerHistory();
         lstentWillApplicationAssignedOfficerHistory: any = [];
         ientWillApplicationApplicant = new entWillApplicationApplicant();
         ientWillApplicationVehicleDetails = new entWillApplicationVehicleDetails();
         lstentWillApplicationVehicleDetails: any = [];
         ientWillApplicationTestatorStatus = new entWillApplicationTestatorStatus();
         ientWillApplicationTestator = new entWillApplicationTestator();
         ientWillApplicationStatusHistory = new entWillApplicationStatusHistory();
         lstentWillApplicationStatusHistory: any = [];
         ientWillApplicationSpouse = new entWillApplicationSpouse();
         lstentWillApplicationSpouse: any = [];
         ientWillApplicationSignature = new entWillApplicationSignature();
         lstentWillApplicationSignature: any = [];
         ientWillApplicationRealestateDetails = new entWillApplicationRealestateDetails();
         lstentWillApplicationRealestateDetails: any = [];
         willOfficerAssigned = '';
         willOfficerAssignedtoFullname = '';
         enteredByFullname = '';
         appliedByFullname = '';
         statusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         workflowId = 0;
         willApplicationCompleted = '';
         ientWillApplicationOtherAssetDetails = new entWillApplicationOtherAssetDetails();
         lstentWillApplicationOtherAssetDetails: any = [];
        
}

export class entWillApplicationApplicant {
  appWillApplicationApplicantId = 0;
         appWillApplicationId = 0;
         customerId = 0;
         maritalStatusId = 0;
         maritalStatusValue = '';
         occupation = '';
         maritalStatusDescription = '';
         ientCustomer = new entCustomer();
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWillApplicationAssignedOfficerHistory {
  willApplicationAssignedOfficerHistoryId = 0;
         willApplicationId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         statusId = 0;
         statusValue = '';
         assignedTo = '';
         assignedBy = '';
         assignedDate = '';
         identityNo = 0;
         verificationDate = '';
         assignedByFullname = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWillApplicationAssignedOfficerHistoryList {
  ientWillApplicationAssignedOfficerHistory: any = [];
         msg = new entIEMessage();
        
}

export class entWillApplicationChildren {
  willApplicationChildId = 0;
         willApplicationId = 0;
         customerId = 0;
         ientCustomer = new entCustomer();
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWillApplicationChildrenList {
  ientWillApplicationChildren: any = [];
         msg = new entIEMessage();
        
}

export class entWillApplicationDocument {
  willApplicationDocumentId = 0;
         willApplicationId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         applicationStatusId = 0;
         applicationStatusValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         documentTypeId = 0;
         documentTypeValue = '';
         fileId = 0;
         isMandatory = '';
         identityNo = 0;
         statusDescription = '';
         applicationStageDescription = '';
         actionStatusDescription = '';
         documentTypeDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         ientFile = new entFile();
        
}

export class entWillApplicationDocumentList {
  ientWillApplicationDocument: any = [];
         msg = new entIEMessage();
        
}

export class entWillApplicationEmailHistory {
  willApplicationEmailHistoryId = 0;
         willApplicationId = 0;
         communicationTrackingId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         statusId = 0;
         statusValue = '';
         changedBy = '';
         changedDate = '';
         identityNo = 0;
         sendBy = '';
         sendDate = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWillApplicationFinanceDetails {
  willApplicationFinanceDetailId = 0;
         willApplicationId = 0;
         institutionName = '';
         accountNo = '';
         accountTypeId = 0;
         accountTypeValue = '';
         bsb = '';
         addressId = 0;
         ientAddress = new entAddress();
         accountTypeDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWillApplicationFinanceDetailsList {
  ientWillApplicationFinanceDetails: any = [];
         msg = new entIEMessage();
        
}

export class entWillApplicationInsuranceDetails {
  willApplicationInsuranceDetailId = 0;
         willApplicationId = 0;
         companyName = '';
         policyNo = '';
         insuranceTypeId = 0;
         insuranceTypeValue = '';
         insuredAmount = '';
         lastPremiumAmount = '';
         lastPremiumPaidDate = '';
         addressId = 0;
         ientAddress = new entAddress();
         insuranceTypeDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWillApplicationInsuranceDetailsList {
  ientWillApplicationInsuranceDetails: any = [];
         msg = new entIEMessage();
        
}

export class entWillApplicationInvestmentDetails {
  willApplicationInvestmentDetailId = 0;
         willApplicationId = 0;
         companyName = '';
         shareNo = 0;
         isCertificateAvailable = '';
         shareTypeId = 0;
         shareTypeValue = '';
         addressId = 0;
         ientAddress = new entAddress();
         shareTypeDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWillApplicationInvestmentDetailsList {
  ientWillApplicationInvestmentDetails: any = [];
         msg = new entIEMessage();
        
}

export class entWillApplicationNotes {
  willApplicationNotesId = 0;
         willApplicationId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         applicationStatusId = 0;
         applicationStatusValue = '';
         notes = '';
         identityNo = 0;
         enteredByFullname = '';
         isUpdateButtonShow = '';
         applicationStageDescription = '';
         actionStatusDescription = '';
         applicationStatusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWillApplicationNotesList {
  ientWillApplicationNotes: any = [];
         msg = new entIEMessage();
        
}

export class entWillApplicationOtherAssetDetails {
  willApplicationAssetDetailId = 0;
         willApplicationId = 0;
         description = '';
         value = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWillApplicationOtherAssetDetailsList {
  ientWillApplicationOtherAssetDetails: any = [];
         msg = new entIEMessage();
        
}

export class entWillApplicationRealestateDetails {
  willApplicationRealestateDetailId = 0;
         willApplicationId = 0;
         titleNo = '';
         tenancyId = 0;
         tenancyValue = '';
         tenancyTypeId = 0;
         tenancyTypeValue = '';
         tenureId = 0;
         tenureValue = '';
         landlordName = '';
         addressId = 0;
         titleCopyDocId = 0;
         ientAddress = new entAddress();
         ientFile = new entFile();
         tenancyValueDescription = '';
         tenancyTypeDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWillApplicationRealestateDetailsList {
  ientWillApplicationRealestateDetails: any = [];
         msg = new entIEMessage();
        
}

export class entWillApplicationSearch {
  willApplRefNo = '';
         applicationStageValue = '';
         appliedBy = '';
         appliedDateFrom = '';
         appliedDateTo = '';
         enteredBy = '';
         appliedBranchValue = '';
         enteredDateFrom = '';
         enteredDateTo = '';
         statusValue = '';
         pageSize = 0;
         pageNumber = 0;
         orderByColumnName = '';
         ascending = false;
         istrSortColumn = '';
         istrSortOrder = false;
         actionStatusValue = '';
         willApplicationId = 0;
         applicantCrmNo = '';
        
}

export class entWillApplicationSearchResult {
  totalCount = 0;
         pageSize = 0;
         pageNumber = 0;
         result: any = [];
        
}

export class entWillApplicationSearchResultSet {
  willApplRefNo = '';
         applicationStageValue = '';
         appliedBy = '';
         appliedDate = '';
         applicantCrmNo = '';
         enteredBy = '';
         appliedBranchValue = '';
         enteredDate = '';
         testatorId = 0;
         statusValue = '';
         pageSize = 0;
         pageNumber = 0;
         orderByColumnName = '';
         ascending = false;
         istrSortColumn = '';
         istrSortOrder = false;
         actionStatusValue = '';
         statusDescription = '';
         applicationStageDescription = '';
         actionStatusDescription = '';
         willApplicationId = 0;
         branchDescription = '';
        
}

export class entWillApplicationSignature {
  willApplicationSignatureId = 0;
         willApplicationId = 0;
         witnessId = 0;
         identityNo = 0;
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWillApplicationSignatureList {
  ientWillApplicationSignature: any = [];
         msg = new entIEMessage();
        
}

export class entWillApplicationSpouse {
  willApplicationSpouseId = 0;
         willApplicationId = 0;
         customerId = 0;
         ientCustomer = new entCustomer();
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWillApplicationSpouseList {
  ientWillApplicationSpouse: any = [];
         msg = new entIEMessage();
        
}

export class entWillApplicationStatusHistory {
  willApplicationStatusHistoryId = 0;
         willApplicationId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         statusId = 0;
         statusValue = '';
         changedBy = '';
         changedDate = '';
         identityNo = 0;
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWillApplicationTestator {
  willApplicationTestatorId = 0;
         willApplicationId = 0;
         customerId = 0;
         maritalStatusId = 0;
         maritalStatusValue = '';
         occupation = '';
         maritalStatusDescription = '';
         ientCustomer = new entCustomer();
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWillApplicationTestatorStatus {
  willApplicationTestatorId = 0;
         willApplicationId = 0;
         isDeathBed = '';
         isUnderstandable = '';
         isMentalAbility = '';
         isOldAge = '';
         isIllness = '';
         isDifficultyInCommunication = '';
         isDoctorOpenionRequired = '';
         doctorOpenionDocId = 0;
         isInfluencedByOthers = '';
         isRequireAssistance = '';
         assistanceName = '';
         isAssistanceFromFamily = '';
         identityNo = 0;
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWillApplicationTestatorStatusList {
  ientWillApplicationTestatorStatus: any = [];
         msg = new entIEMessage();
        
}

export class entWillApplicationVehicleDetails {
  willApplicationVehicleDetailId = 0;
         willApplicationId = 0;
         vehicleRegNo = '';
         vehicleTypeId = 0;
         vehicleTypeValue = '';
         vehicleMake = '';
         model = '';
         vehicleTypeDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWillApplicationVehicleDetailsList {
  ientWillApplicationVehicleDetails: any = [];
         msg = new entIEMessage();
        
}

export class entWillApplicationWitness {
  willApplicationWitnessId = 0;
         willApplicationSignatureId = 0;
         witnessName = '';
         witnessDob = '';
         isFptcl = '';
         isBeneficiarySpouse = '';
         addressLine1 = '';
         addressLine2 = '';
         addressLine3 = '';
         occupation = '';
         identityNo = 0;
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWillApplicationWitnessList {
  ientWillApplicationWitness: any = [];
         msg = new entIEMessage();
        
}

export class entWillList {
  ientWill: any = [];
         msg = new entIEMessage();
        
}

export class entWithdrawalPayment {
  withdrawalPaymentId = 0;
         trustWithdrawalApplicationId = 0;
         trustId = 0;
         beneficaryCustomerId = 0;
         processedDate = '';
         paidDate = '';
         paymentAmount = '';
         paymentModeId = 0;
         paymentModeValue = '';
         paymentStatusId = 0;
         paymentStatusValue = '';
         collectBy = '';
         collectedDate = '';
         collectedAtBranchId = 0;
         collectedAtBranchValue = '';
         givenBy = '';
         bankId = 0;
         batchNo = '';
         isAutoIncrementCheque = '';
         chequeNo = 0;
         chequeDate = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
         ientWithdrawalPaymentStatusHistory = new entWithdrawalPaymentStatusHistory();
         lstentWithdrawalPaymentStatusHistory: any = [];
         ientWithdrawalPaymentDocument = new entWithdrawalPaymentDocument();
         lstentWithdrawalPaymentDocument: any = [];
         ientWithdrawalPaymentChecklist = new entWithdrawalPaymentChecklist();
         lstentWithdrawalPaymentChecklist: any = [];
         ientWithdrawalPaymentAssignedOfficerHistory = new entWithdrawalPaymentAssignedOfficerHistory();
         lstentWithdrawalPaymentAssignedOfficerHistory: any = [];
         ientWithdrawalPaymentEmailHistory = new entWithdrawalPaymentEmailHistory();
         lstentWithdrawalPaymentEmailHistory: any = [];
         ientWithdrawalPaymentApplicationNotes = new entWithdrawalPaymentApplicationNotes();
         lstentWithdrawalPaymentApplicationNotes: any = [];
         ientWithdrawalPaymentHistory = new entWithdrawalPaymentHistory();
         lstentWithdrawalPaymentHistory: any = [];
         bankName = '';
         collectedAtBranchDescription = '';
         paymentModeDescription = '';
         guardianName = '';
        
}

export class entWithdrawalPaymentApplicationNotes {
  trustWithdrawlPaymentNotesId = 0;
         trustWithdrawalPaymentId = 0;
         statusId = 0;
         statusValue = '';
         notes = '';
         identificationNo = 0;
         statusDescription = '';
         iStatusDDL = new entDDL();
         iActionStatusDDL = new entDDL();
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWithdrawalPaymentAssignedOfficerHistory {
  withdrawlPaymentAssignedOfficerHistoryId = 0;
         trustWithdrawalPaymentId = 0;
         statusId = 0;
         statusValue = '';
         assignedTo = '';
         assignedBy = '';
         assignedDate = '';
         identificationNo = 0;
         statusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWithdrawalPaymentChecklist {
  appWithdrawalPaymentChecklistId = 0;
         trustWithdrawalPaymentId = 0;
         checklistName = '';
         isMandatory = '';
         checkedBy = '';
         checkedDatetime = '';
         identificationNo = 0;
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWithdrawalPaymentDocument {
  appWithdrawalPaymentDocumentId = 0;
         trustWithdrawalPaymentId = 0;
         applicationStageId = 0;
         applicationStageValue = '';
         applicationStatusId = 0;
         applicationStatusValue = '';
         actionStatusId = 0;
         actionStatusValue = '';
         documentTypeId = 0;
         documentTypeValue = '';
         fileId = 0;
         isMandatory = '';
         identificationNo = 0;
         ientFile = new entFile();
         applicationStatusDescription = '';
         applicationStageDescription = '';
         actionStatusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWithdrawalPaymentDocumentList {
  lstentWithdrawalPaymentDocument: any = [];
         msg = new entIEMessage();
         ientWithdrawalPaymentDocument = new entWithdrawalPaymentDocument();
        
}

export class entWithdrawalPaymentEmailHistory {
  trustWithdrawalPaymentEmailHistoryId = 0;
         trustWithdrawalPaymentId = 0;
         communicationTrackingId = 0;
         statusId = 0;
         statusValue = '';
         changedBy = '';
         changedDate = '';
         identificationNo = 0;
         ientCommunicationTracking = new entCommunicationTracking();
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWithdrawalPaymentHistory {
  withdrawalPaymentHistoryId = 0;
         withdrawalPaymentId = 0;
         trustWithdrawalApplicationId = 0;
         trustId = 0;
         beneficaryCustomerId = 0;
         processedDate = '';
         paidDate = '';
         paymentAmount = '';
         paymentModeId = 0;
         paymentModeValue = '';
         paymentStatusId = 0;
         paymentStatusValue = '';
         collectBy = '';
         collectedDate = '';
         collectedAtBranchId = 0;
         collectedAtBranchValue = '';
         bankId = 0;
         givenBy = '';
         batchNo = '';
         isAutoIncrementCheque = '';
         chequeNo = 0;
         chequeDate = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWithdrawalPaymentStatusHistory {
  trustWithdrawalPaymentStatusHistoryId = 0;
         trustWithdrawalPaymentId = 0;
         statusId = 0;
         statusValue = '';
         changedBy = '';
         changedDate = '';
         identificationNo = 0;
         statusDescription = '';
         idoObjState = '';
         updateSeq = 0;
         msg = new entIEMessage();
        
}

export class entWorkflowSearch {
  workflowName = '';
         statusValue = '';
         sourceRefValue = '';
         sourceRefNo = '';
         stepName = '';
         stepStatusValue = '';
         assignedTo = '';
         totalCount = 0;
         pageSize = 0;
         pageNumber = 0;
         orderByColumnName = '';
         ascending = false;
         istrSortColumn = '';
         istrSortOrder = false;
        
}

export class entWorkflowSearchResult {
  searchResult: any = [];
         totalCount = 0;
         pageSize = 0;
         pageNumber = 0;
        
}

export class entWorkflowSearchResultSet {
  workflowId = 0;
         workflowTemplateId = 0;
         workflowRefNo = '';
         workflowName = '';
         sourceName = '';
         sourceRefValue = '';
         sourceRefNo = '';
         sourcePrimaryKey = 0;
         workflowElementStepId = 0;
         stepName = '';
         stepStatusDescription = '';
         workflowTemplateElementId = 0;
         actualTatInMinutes = '';
         assignedTo = '';
         assignedDateTime = '';
         slaDay = 0;
         slaHour = 0;
         slaMin = 0;
         escalationLevel = 0;
         remainingTatInMinutes = '';
         totalTatInMinutes = '';
         completedTatInMinutes = '';
         tatCompletedPercentage = '';
         assignedToFullName = '';
         workflowStatusDescription = '';
         totalTatInWords = '';
         completedTatInWords = '';
         remainingTatInWords = '';
         expectedCompletionDateTime = '';
        
}




