import { AppDatePipe } from './app-date.pipe';

describe('AppDatePipe', () => {
  it('create an instance', () => {
    const pipe = new AppDatePipe();
    expect(pipe).toBeTruthy();
  });
});
