import { SplicePipe } from './splice.pipe';

describe('SplicePipe', () => {
  it('create an instance', () => {
    const pipe = new SplicePipe();
    expect(pipe).toBeTruthy();
  });
});
