import { Pipe, PipeTransform } from '@angular/core';
import { add, format, parse, sub } from 'date-fns';
import { AppSettingsService } from '../../services/app-settings/app-settings.service';

@Pipe({
  name: 'getDate',
  standalone: true,
})
export class GetDatePipe implements PipeTransform {
  constructor(
    public appSetting: AppSettingsService
  ) {

  }
  transform(value: string, num: any, type?: any, xFormat?: any): string {
    if (!value) {
      return "";
    }
    if (!num) {
      return value;
    }
    if (num === 0) {
      return "";
    }
    let xType = "add";
    if (type) {
      xType = type;
    }

    let serverTimeFormat = this.appSetting.environment.serverDateFormatWithTime;
    if (xFormat) {
      serverTimeFormat = xFormat;
    }
    let returnDate = "";

    let parseNewDate = parse(value, serverTimeFormat, new Date());

    if (xType === 'add') {
      let newAddedDate = add(parseNewDate, { days: parseFloat(num) });
      return format(newAddedDate, serverTimeFormat);
    }
    if (xType === 'minus') {
      let newMinusDate = sub(parseNewDate, { days: parseFloat(num) });
      return format(newMinusDate, serverTimeFormat);
    }
    return "";
  }

}
