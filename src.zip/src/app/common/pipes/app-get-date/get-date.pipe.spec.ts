import { GetDatePipe } from './get-date.pipe';

describe('GetDatePipe', () => {
  it('create an instance', () => {
    const pipe = new GetDatePipe();
    expect(pipe).toBeTruthy();
  });
});
