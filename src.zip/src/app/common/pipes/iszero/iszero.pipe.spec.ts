import { IszeroPipe } from './iszero.pipe';

describe('IszeroPipe', () => {
  it('create an instance', () => {
    const pipe = new IszeroPipe();
    expect(pipe).toBeTruthy();
  });
});
