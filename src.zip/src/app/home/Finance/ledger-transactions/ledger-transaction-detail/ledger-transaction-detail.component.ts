import { Component } from '@angular/core';

@Component({
  selector: 'app-ledger-transaction-detail',
  standalone: true,
  imports: [],
  templateUrl: './ledger-transaction-detail.component.html',
  styleUrl: './ledger-transaction-detail.component.scss'
})
export class LedgerTransactionDetailComponent {

}
