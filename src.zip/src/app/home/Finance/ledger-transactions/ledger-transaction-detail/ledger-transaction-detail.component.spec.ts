import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LedgerTransactionDetailComponent } from './ledger-transaction-detail.component';

describe('LedgerTransactionDetailComponent', () => {
  let component: LedgerTransactionDetailComponent;
  let fixture: ComponentFixture<LedgerTransactionDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LedgerTransactionDetailComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(LedgerTransactionDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
