import { CUSTOM_ELEMENTS_SCHEMA, Component, TemplateRef, ViewChild } from '@angular/core';
import { IconButtonComponent } from '../../../../app-core/template/icon-button/icon-button.component';
import { AppTableComponent, CellDefDirective, CellHeaderDefDirective } from '../../../../app-core/template/app-table/app-table.component';
import { SearchComponent } from '../../../../app-core/template/search/search.component';
import { TableStatusSortComponent } from '../../../../app-core/table-status-sort/table-status-sort.component';
import { InputControlComponent } from '../../../../app-core/form-input/input-control/input-control.component';
import { InnerScroll, Row } from '../../../../app-core/core-component/core-component.component';
import { CoreService } from '../../../../app-core/service/core.service';
import { Router } from '@angular/router';
import { AppService } from '../../../../app.service';
import { DataService } from '../../../../common/services/data/data.service';
import { InitialDataService } from '../../../../common/services/initial-data/initial-data.service';
import { AccountsApiService } from '../../../../common/api-services/accounts-api/accounts-api.service';
import { entActLedgerTransactionsSearch, entLedgerTransaction } from '../../../../common/api-services/accounts-api/accounts-api.classes';
import { UrlService } from '../../../../common/services/url/url.service';
import { FormsModule } from '@angular/forms';
import { AppDatePipe } from '../../../../common/pipes/app-date/app-date.pipe';
import { SearchDebitComponent } from '../../../search/search-debit/search-debit.component';
import { AccoutsStatusTableComponent } from '../../../../app-core/template/accouts-status-table/accouts-status-table.component';
import { AppAccessDirective } from '../../../../common/permission/app-access.directive';
import { ButtonAccessDirective } from '../../../../common/permission/button-access.directive';

@Component({
  selector: 'app-ledger-transaction-search',
  standalone: true,
  imports: [IconButtonComponent, AppTableComponent, SearchComponent, TableStatusSortComponent, InputControlComponent, InnerScroll, Row, CellDefDirective, CellHeaderDefDirective, FormsModule, AppDatePipe, SearchDebitComponent,AccoutsStatusTableComponent,AppAccessDirective,
    ButtonAccessDirective,],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './ledger-transaction-search.component.html',
  styleUrl: './ledger-transaction-search.component.scss'
})
export class LedgerTransactionSearchComponent {
  pageId = 'LDTRS';
  __selectedItems: any;
  @ViewChild('breadCrumb') breadCrumb!: TemplateRef<any>;
  columns: any = ["documentNumber", "voucherName", "ledgerName", "ledgerTypeValue", "effectiveDate", "postedDate", "debitAmount", "creditAmount", "statusValue", "narration", "action"];
  columnsName: any = ["Document Number", "Document Name", "Ledger Name", "Ledger Type", "Document Date", "Posted Date", "Debit(INR)", "Credit(INR)", "Status", "Narration", ""];
  options = {
    hideFullSpinner: true
  }
  searchParams = new entActLedgerTransactionsSearch()
  searchParamsRAW = new entActLedgerTransactionsSearch()

  constructor(public dialog: CoreService,
    public router: Router,
    public appService: AppService,
    public accountsService: AccountsApiService,
    public data: DataService,
    public urlService: UrlService,
    public initialData: InitialDataService,
  ) { }
  tableData: any = [];

  pagination = {
    pageNumber: 1,
    pageSize: 25,
    totalCount: 0
  }

  async ngOnInit(): Promise<void> {
    this.init();
  }

  async init() {
    await this.data.checkToken();
    await this.initialData.getAcccountsDDL('getLedgerTransactionInitialData', this.options);
    this.createLedgerTransactionSearch();

  }
  doClear() {
    this.searchParams = JSON.parse(JSON.stringify(this.searchParamsRAW));
    this.data.successMessage("Data Cleared Successfully");
  }
  createLedgerTransactionSearch() {
    debugger
    this.accountsService.createNewLedgerTransactionSearch().subscribe((success) => {
      // success.pageNumber = this.pagination.pageNumber;
      // success.pageSize = this.pagination.pageSize
      this.searchParams = success;
      this.searchParams.pageNumber = this.pagination.pageNumber;
      this.searchParams.pageSize = this.pagination.pageSize;
      this.searchLedgerTransaction();
    })
  }

  searchLedgerTransaction() {
    this.accountsService.searchLedgerTransaction(this.searchParams).subscribe((success) => {
      this.tableData = success.aActLedgerTransactionsSearchSet;
      this.pagination.pageNumber = success.pageNumber;
      this.pagination.pageSize = success.pageSize;
      this.pagination.totalCount = success.totalCount;
      this.dialog.closeAll()
      // this.data.successMessage(success?.msg?.infoMessage?.msgDescription);
    })
  }

  clear(){
    this.createLedgerTransactionSearch();
    this.data.successMessage('Data Cleared Successfully')
  }

  onSearch() {
    this.searchParams.pageNumber = 1;
    this.searchLedgerTransaction();
  }


  pageChanged(event: any) {
    this.searchParams.pageNumber = event.pageNumber;
    this.searchParams.pageSize = event.pageSize;
    this.searchLedgerTransaction();
  }
  onSelect(event: any) {
    this.__selectedItems = event;
    console.log(this.__selectedItems);
  }
  async navigateToDetail(val: any, id: any) {
    console.log(val, id);

    let obj = {
      data: id
    }
    console.log(obj);

    let encodeId = await this.urlService.encode(obj);
    if (val === 'PYNTE') {
      this.router.navigateByUrl('/home/purchase/payment-note/detail/' + encodeId)
    }
    if (val === 'ADVRN') {
      this.router.navigateByUrl('/home/sales/advance-receipt-note/detail/' + encodeId)
    }
    if (val === 'APYNT') {
      this.router.navigateByUrl('/home/finance/advance-payment-note/detail/' + encodeId)
    }
    if (val === 'FTNTE') {
      this.router.navigateByUrl('/home/finance/fund-transfer-note/detail/' + encodeId)
    }
    if (val === 'RTNTE') {
      this.router.navigateByUrl('/home/sales/advance-receipt-note/detail/' + encodeId)
    }
    if (val === 'JNLVC') {
      this.router.navigateByUrl('/home/finance/journal-voucher/detail/' + encodeId)
    }
    if (val === 'REVJN') {
      this.router.navigateByUrl('/home/finance/reversing-journal/detail/' + encodeId)
    }
    if (val === 'SAODR') {
      this.router.navigateByUrl('/home/sales/sales-order/detail/' + encodeId)
    }
    if (val === 'SAICE') {
      this.router.navigateByUrl('/home/sales/sales-invoice/detail/' + encodeId)
    }
    if (val === 'PYNTE') {
      this.router.navigateByUrl('/home/finance/advance-payment-note/detail/' + encodeId)
    }
    if (val === 'PRODR') {
      this.router.navigateByUrl('/home/purchase/purchase-order/detail/' + encodeId)
    }
    if (val === 'PRINV') {
      this.router.navigateByUrl('/home/purchase/purchase-invoice/detail/' + encodeId)
    }
    if (val === 'NTOUT') {
      this.router.navigateByUrl('/home/finance/net-out-voucher/detail/' + encodeId)
    }
    if (val === 'DBNTE') {
      this.router.navigateByUrl('/home/purchase/debit-note/detail/' + encodeId)
    }
    if (val === 'CRNTE') {
      this.router.navigateByUrl('/home/sales/credit-note/detail/' + encodeId)
    }

  }
  ngAfterViewInit(): void {
    this.appService.setBreadCrumb(this.breadCrumb);
  }
  onLedgerSelect(event: any) {
    console.log(event);
    this.searchParams.ledgerName = event.aliasName

  }
}
