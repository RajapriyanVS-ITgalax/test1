import { NgClass} from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, Component, TemplateRef, ViewChild } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { MatMenuModule } from '@angular/material/menu';
import { Row, ViewLabel, InnerScroll, AppToolTipComponent } from '../../../../app-core/core-component/core-component.component';
import { FooterToggleDirective } from '../../../../app-core/directives/toggle-directive/footer-toggle.directive';
import { InputControlComponent } from '../../../../app-core/form-input/input-control/input-control.component';
import { ErrorMessageComponent } from '../../../../app-core/message/error-message/error-message.component';
import { AppTableComponent} from '../../../../app-core/template/app-table/app-table.component';
import { DropZoneComponent } from '../../../../app-core/template/drop-zone/drop-zone.component';
import { IconButtonComponent } from '../../../../app-core/template/icon-button/icon-button.component';
import { AppAccessDirective } from '../../../../common/permission/app-access.directive';
import { ButtonAccessDirective } from '../../../../common/permission/button-access.directive';
import { AppDatePipe } from '../../../../common/pipes/app-date/app-date.pipe';
import { ActivatedRoute, Router } from '@angular/router';
import { CoreService } from '../../../../app-core/service/core.service';
import { AppService } from '../../../../app.service';
import { ApplicationApiService } from '../../../../common/api-services/application-api/application-api.service';
import { DataService } from '../../../../common/services/data/data.service';
import { InitialDataService } from '../../../../common/services/initial-data/initial-data.service';
import { UrlService } from '../../../../common/services/url/url.service';
import { MatRadioModule } from '@angular/material/radio';
import { AccountsApiService } from '../../../../common/api-services/accounts-api/accounts-api.service';
import { entActAttachments, entActNetoutVoucher, entActNotes, entActVoucherConfig } from '../../../../common/api-services/accounts-api/accounts-api.classes';
import { ViewPdfComponent } from '../../../../app-core/template/view-pdf/view-pdf.component';
import { AppSettingsService } from '../../../../common/services/app-settings/app-settings.service';
import { ItemTableComponent } from '../../../../app-core/template/item-table/item-table.component';
import { ItemTbodyComponent } from '../../../../app-core/template/item-table/item-tbody/item-tbody.component';
import { SearchCustomerComponent } from '../../../search/search-customer/search-customer.component';
import { VendorSearchComponent } from '../../../purchase/voucher/vendor/vendor-search/vendor-search.component';
import { FilterAndSortPipe } from '../../../../app-core/form-input/pipes/filter-and-sort/filter-and-sort.pipe';

@Component({
  selector: 'app-net-out-voucher-detail',
  standalone: true,
  imports: [
    NgClass,
    Row,
    ViewLabel,
    AppTableComponent,
    IconButtonComponent,
    InnerScroll,
    FormsModule,
    InputControlComponent,
    AppDatePipe,
    ErrorMessageComponent,
    AppAccessDirective,
    ButtonAccessDirective,
    AppToolTipComponent,
    FooterToggleDirective,
    MatMenuModule,
    DropZoneComponent,
    MatRadioModule,
    ViewPdfComponent,
    ItemTableComponent,
    ItemTbodyComponent,
    SearchCustomerComponent,
    VendorSearchComponent,
    FilterAndSortPipe
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './net-out-voucher-detail.component.html',
  styleUrl: './net-out-voucher-detail.component.scss'
})
export class NetOutVoucherDetailComponent {

  accountsOptions = {
    type: 'accountsPath',
  };

  errorTrue = false;
  selectedTab = 0;
  netOutVoucherId = 0;
  voucherConfigId = 0;
  regionValue = "";
  filterFileName = "";
  netOutVoucherOption = 'SALES';
  dateNotEffective = '';
  customerIdRAW = 0;
  voucherConfigIdN = 0;
  voucherId = 0;
  regionValueDDL = [];
  statusLst:any = [];
  totalCredit = 0;
  totalDebit = 0;
  totalDifference = 0;
  customerFlag = false;
  ilstentActNetoutVoucherDetailRAW:any = [];


  @ViewChild('l') lform!: NgForm;
  @ViewChild('a') aform!: NgForm;

  netOutVoucher = new entActNetoutVoucher();
  netOutVoucherforNotes = new entActNotes();
  netOutVoucherAttachment = new entActAttachments();
  voucherConfig = new entActVoucherConfig();
  
  tableNoteData = [
    {
      sNo: '',
      notes: 'Pending Submission',
      createdBy: 'Chief Finance Officer',
      dateTime: '10/07/2002 10:56 AM',
    },
    {
      sNo: '',
      notes: 'Pending Submission',
      createdBy: 'Chief Finance Officer',
      dateTime: '10/07/2002 10:56 AM',
    },
  ];

  tableAttachmentData = [
    {
      sNo: '',
      fileName: 'image_2024_05_25T0_00_29Z',
      createdBy: 'Chief Finance Officer',
      date: '20/09/2022',
      time: '08:05 PM',
      fileFormat: 'img',
      size: '2.00kb',
    },
    {
      sNo: '',
      fileName: 'image_2024_05_25T0_00_29Z',
      createdBy: 'Chief Finance Officer',
      date: '19/09/2022',
      time: '08:05 PM',
      fileFormat: 'img',
      size: '3.00kb',
    },
  ];

  tableItemData = [
    {
      docName: '',
      docNo: '',
      docCurrny: '',
      exRate:'1.00000000',
      repCurrny:'',
    },
    {
      docName: '',
      docNo: '',
      docCurrny: '',
      exRate:'1.00000000',
      repCurrny:'',
    },
  ];

  pageId = 'AJVSC';

  items:any = ['sno', 'docName', 'docNo', 'docCurrny', 'exRate', 'repCurrny'];
  itemsName: any = ['', 'Document Name', 'Document No', 'Doc Currency', 'Ex-Rate', 'Rep-Currency'];


  notes: any = ['sno', 'notes', 'createdBy', 'dateTime', 'add'];
  notesName: any = ['', 'Notes', 'Created By', 'Date | Time', ''];

  attachment: any = ['sno', 'fileName', 'fileFormat', 'size', 'action'];
  attachmentsName: any = ['', 'File Name', 'File Format', 'Size', ''];



  @ViewChild('breadCrumb') breadCrumb!: TemplateRef<any>;

  @ViewChild('attachmentDialog') attachmentDialog!: TemplateRef<any>;

  @ViewChild('notesDialog', { static: false })
  notesDialog!: TemplateRef<any>;

  fileType = 'jpg, jpeg, png, tiff, gif, tif ,pdf, xls, doc, pdf, DOCX, ppt, PPTX, sql, txt, csv'

  accept = '.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel, application/pdf, application/msword, image/png, image/jpg, image/jpeg , image/webp, image/tiff, image/gif, image/tif, image/';

  constructor(
    public route: ActivatedRoute,
    public data: DataService,
    public accountsService: AccountsApiService,
    public initialData: InitialDataService,
    public dialog: CoreService,
    public url: UrlService,
    public router: Router,
    public appService: AppService,
    public appSetting: AppSettingsService,
  ) {
    this.route.paramMap.subscribe((params: any) => {
      this.init();
    });
  }

  ngAfterViewInit(): void {
    this.appService.setBreadCrumb(this.breadCrumb);
  }

  async init() {
    await this.data.checkToken();
    let id = this.route.snapshot.paramMap.get('id');
    let params: any = await this.url.decode(id);
    this.netOutVoucherId = params.data;
    this.voucherConfigId = params.data1;
    this.regionValue = params.data2
    await this.data.checkToken();
    if (this.netOutVoucherId === 0) {
      this.createNewnetOutVoucher(this.voucherConfigId, this.regionValue);
    } else {
      this.openNetoutVoucher(this.netOutVoucherId);
    }
    this.initialData.getAcccountsDDL('getNetoutVoucherInitialData', this.accountsOptions);
  }

  createNewnetOutVoucher(voucherConfigId:any, regionValue:any){
    const obj = {
      data: voucherConfigId,
      data1: regionValue
    };
    this.accountsService
      .createNewNetoutVoucher(obj, this.accountsOptions)
      .subscribe((success) => {
        this.netOutVoucher = success;
        this.voucherId = success.actVoucherConfigId;
        this.customerIdRAW = success.pentActCustomerDetails.actCustomerId;
        this.dateNotEffective = success.documentDate;
        this.netOutVoucher.docCurrencyValue = success.strBaseCurrencyValue;
        this.netOutVoucher.netoutVoucherTypeValue = this.netOutVoucherOption;
        this.errorTrue = false;
      });
  }

  openNetoutVoucher(val: any) {
    const obj = {
      data: val,
    };
    this.accountsService
      .openNetoutVoucher(obj, this.accountsOptions)
      .subscribe((success) => {
        this.netOutVoucher = success;
        this.getVoucherDetail(this.netOutVoucher.actVoucherConfigId !== 0 ? this.netOutVoucher.actVoucherConfigId : this.voucherConfigId);
        this.netOutVoucherOption = success.netoutVoucherTypeValue;
        this.customerIdRAW = success.pentActCustomerDetails.actCustomerId;
        this.dateNotEffective = success.documentDate;
        this.voucherId = success.actVoucherConfigId;
        this.statusLst = success.ilstentActNetoutVoucherStatusHistory
      });
  }

  async savenetOutVoucher() {
    let netOutVoucherValid:any
    // = await this.netOutVoucherChild.saveTable();
    if (this.lform.valid) {
      if (netOutVoucherValid) {
        this.accountsService
          .saveNetoutVoucher(this.netOutVoucher, this.accountsOptions)
          .subscribe(async (success) => {
            this.netOutVoucher = success;
            this.statusLst = success.ilstentActNetoutVoucherStatusHistory;
            const obj = {
              data: success.actNetoutVoucherId,
              data1: 0,
            };
            let urlJson = await this.url.encode(obj);
            this.router.navigateByUrl(
              '/home/finance/net-out-voucher/detail/' + urlJson
            );
            this.data.successMessage(success.msg.infoMessage.msgDescription);
          });
      }
    } else {
      this.errorTrue = true;
      this.data.errorInfoMessage('Please fill all mandatory fields');
    }
  }

  doClear() {
    this.errorTrue = false;
    this.createNewnetOutVoucher(this.voucherConfigId, this.regionValue);
  }

  async openDialogNotes() {
    this.createNewNotesFornetOutVoucher();
    let dialogResponse: any = await this.dialog.openDialog(this.notesDialog, {
      disableClose: true,
      height: 'auto',
      width: '900px',
      maxWidth: '1170px',
    });
  }
  
  createNewNotesFornetOutVoucher() {
    this.errorTrue = false;
    const obj = {
      data: this.voucherConfigId === 0 ?this.voucherId:this.voucherConfigId,
      data1: this.netOutVoucher.statusValue,
    };
    this.accountsService
      .createNewAccountsNotes(obj, this.accountsOptions)
      .subscribe((success) => {
        this.netOutVoucherforNotes = success;
        this.netOutVoucherforNotes.temporaryDocumentDate =
          this.netOutVoucher.documentDate;
        this.initialData.DDLValues.NoVoucherStatus =
          success.lddlData;
      });
  }

  async savenetOutVoucherNotes(n: any) {
    let netOutVoucherValid:any
    // = await this.netOutVoucherChild.saveTable();
    if (this.lform.valid && n.valid) {
      if (netOutVoucherValid) {
        this.errorTrue = false;
        this.netOutVoucherforNotes.referenceId = this.netOutVoucherId;
        this.netOutVoucherforNotes.lddlData = [];
        this.netOutVoucher.ientActNotes = this.netOutVoucherforNotes;
        this.accountsService
          .saveNetoutVoucherNotes(this.netOutVoucher, this.accountsOptions)
          .subscribe((success) => {
            this.netOutVoucher = success;
            this.statusLst = success.ilstentActNetoutVoucherStatusHistory;
            // this.openLoadAllVoucherConfigId();
            if (success.msg.infoMessage.msgDescription) {
              this.data.successMessage(success.msg.infoMessage.msgDescription);
            }
            if (this.netOutVoucher.statusValue === 'APROV') {
              this.onSelectTab(3);
            }
          this.dialog.closeDialog();
          });
      }
    } else {
      this.errorTrue = true;
      this.data.errorInfoMessage('Please fill all mandatory fields');
    }
  }

  doNotesClear() {
    this.createNewNotesFornetOutVoucher();
  }

  async createNewAttachment() {
    let dialogResponse: any = await this.dialog.openDialog(this.attachmentDialog, {
      disableClose: true,
      height: 'atuo',
      width: '100%',
      maxWidth: '1170px',
    })
  }

  async uploadAttachemnt(event: any) {
    this.netOutVoucherAttachment.referenceId = this.netOutVoucherId;
    let attachmentList: any = [];
    attachmentList = event;
    for (let i = 0; i < attachmentList.length; i++) {
      if (attachmentList.length !== 0) {
        this.netOutVoucherAttachment.attachmentSize =
          attachmentList[i].fileSize;
        this.netOutVoucherAttachment.attachmentFileName =
          attachmentList[i].fileName;
        this.netOutVoucherAttachment.istringFileContent =
          attachmentList[i].content;
        this.netOutVoucherAttachment.attachmentType =
          attachmentList[i].fileType;
        let uploadDocument = await this.uploadDocument();
      }
    }
  }

  uploadDocument(){
    return new Promise((resolve: any) => {
      this.accountsService
        .uploadJournalVoucherAttachment(
          this.netOutVoucherAttachment,
          this.accountsOptions 
        )
        .subscribe((success) => {
          this.netOutVoucher.ilstActAttachments = success.plstentActAttachments;
          this.dialog.closeDialog();
          resolve(true);
        });
    });
  }

  viewFile(element:any) {
    let base64Data = element.ientFile.content.split(';base64,').pop();
    const byteCharacters = atob(base64Data);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: element.ientFile.fileType });

    const url = URL.createObjectURL(blob);
    if (element.ientFile.fileType === 'application/pdf') {
      this.openPDFViewer(url);
    } else if (element.ientFile.fileType.includes('image')) {
      // this.imageView(url, element.ientFile.fileName);
    }
  }

  openPDFViewer(xurl: any) {
    const dialogRef = this.dialog.openDialog(ViewPdfComponent, {
      width: "100%",
      height: "85%",
      data: {
        url: xurl,
      },
    });
  }

  getVoucherDetail(element: any) {
    const obj = {
      data: element,
    };
    this.accountsService
      .getVoucherAccess(obj, this.accountsOptions)
      .subscribe((success) => {
        this.voucherConfigId = success.actVoucherConfigId;
        this.voucherConfig = success;
        this.regionValueDDL = success.plstentDDLClass
      });
  }

  getAllItems(event: any) {
    setTimeout(() => {
      this.calculateAmount();
    }, 200);

  }

  validCheckbox(val: any) {
    // this.isZero = this.floatPipe.transform(val);
  }

  calculateAmount() {
    let netOutVoucherGain = 0;
    let netOutVoucherLoss = 0;
    this.totalCredit = 0;
    let totalRepCredit = 0;
    let totalRepDebit = 0;
    this.totalDebit = 0;
    this.totalDifference = 0;

    for (let i = 0; i < this.netOutVoucher.ilstentActNetoutVoucherDetail.length; i++) {
      this.totalDebit = parseFloat(this.netOutVoucher.ilstentActNetoutVoucherDetail[i].  
                        bitAmountDocCurrency) + this.totalDebit;
      this.totalCredit = parseFloat(this.netOutVoucher.ilstentActNetoutVoucherDetail[i].                   
                         reditAmountDocCurrency) + this.totalCredit;
      totalRepCredit =  parseFloat(this.netOutVoucher.ilstentActNetoutVoucherDetail[i].  
                        creditAmountRepCurrency) + totalRepCredit;     
      totalRepDebit =   parseFloat(this.netOutVoucher.ilstentActNetoutVoucherDetail[i].  
                        debitAmountRepCurrency) + totalRepDebit;
      netOutVoucherGain += parseFloat(this.netOutVoucher.ilstentActNetoutVoucherDetail[i].gain);
      netOutVoucherLoss += parseFloat(this.netOutVoucher.ilstentActNetoutVoucherDetail[i].loss);
    }
    this.netOutVoucher.exchangeLoss = '0.00';
    this.netOutVoucher.exchangeGain = '0.00';
    let gainValue: any = 0;
    let lossValue: any = 0;
    totalRepDebit > totalRepCredit ? (gainValue = (totalRepDebit - totalRepCredit).toString()) : 
    (lossValue = (totalRepCredit - totalRepDebit).toString());
    this.totalDifference = this.totalDebit - this.totalCredit;
 
    this.netOutVoucher.exchangeGain = (parseFloat(gainValue) + netOutVoucherGain).toString();
    this.netOutVoucher.exchangeLoss = (parseFloat(lossValue) + netOutVoucherLoss).toString();
  }

  async doSelectCustomer(event: any) {
    debugger
    this.netOutVoucher.pentActCustomerDetails.customerName = event.customerName;
    this.netOutVoucher.partyId = event.actCustomerId;
    this.customerFlag = true;
    if (
      this.customerIdRAW !== 0 &&
      this.customerIdRAW !== this.netOutVoucher.partyId
    ) {
      let isCustomerChange = await this.dialog.confirmDialog(
        'Do you want to change customer, If you change customer then entire data will be clear'
      );
      if (isCustomerChange) {
        let currentDate: any = await this.appService.getCurrentDate();
        this.netOutVoucher.documentDate = currentDate;
        this.netOutVoucher.ilstentActNetoutVoucherDetail
          = [];
        this.netOutVoucher.partyId = event.actCustomerId;
      } else {
        this.netOutVoucher.partyId = this.customerIdRAW;
        event.actCustomerId = this.customerIdRAW;
      }
    }
    this.customerIdRAW = this.netOutVoucher.partyId;
    // this.openCustomer(event);
    this.loadAllVouchersByVoucherConfigAndId();
  }

  doSelectVendor(event: any) {
    this.netOutVoucher.pentActCustomerDetails.customerName = event.vendorName;
    this.netOutVoucher.partyId = event.actVendorId;
    this.loadAllVouchersByVoucherConfigAndId();
  }

  loadAllVouchersByVoucherConfigAndId() {
    this.ilstentActNetoutVoucherDetailRAW = [];
    this.accountsService
      .loadAllVouchersByVoucherConfigAndId(this.netOutVoucher, this.accountsOptions)
      .subscribe((success) => {
        this.netOutVoucher = success;
        if (this.netOutVoucher.netoutVoucherTypeValue === 'PUR') {
          this.netOutVoucher.docCurrencyValue = success.pentActVendor.currencyValue;
          this.netOutVoucher.docCurrencyDescription = success.pentActVendor.currencyDescription;
        } else {
          this.netOutVoucher.docCurrencyValue = success.pentActCustomerDetails.currencyCodeValue;
          this.netOutVoucher.docCurrencyDescription = success.pentActCustomerDetails.currencyCodeDescription;
        }
        let ientActNetoutVoucherDetail = JSON.parse(
          JSON.stringify(this.netOutVoucher.ientActNetoutVoucherDetail)
        );
        ientActNetoutVoucherDetail.actVoucherConfigId =
          this.netOutVoucher.ientAdvanceActVoucherConfig.actVoucherConfigId;
        if (this.netOutVoucher.partyId !== 0) {
          this.ilstentActNetoutVoucherDetailRAW.push(
            ientActNetoutVoucherDetail
          );
          this.netOutVoucher.ilstentActNetoutVoucherDetail =
            this.ilstentActNetoutVoucherDetailRAW;
        }
      });
  }

  openLoadAllVoucherConfigId() {
    this.accountsService.loadAllVouchersByVoucherConfigAndId(this.netOutVoucher, this.accountsOptions).subscribe((success) => {
      this.netOutVoucher = success;
    })
  }

  screenDisabled() {
    let screenDisabled = false;
    if (
      this.netOutVoucher.statusValue === 'APROV' ||
      this.netOutVoucher.statusValue === 'CANCL' ||
      this.netOutVoucher.statusValue === 'PENAP'
    ) {
      screenDisabled = true;
    } else {
      screenDisabled = false;
    }

    return screenDisabled;
  }

  async directApproved() {
    let netOutVoucherValid:any
    // await this.netOutVoucherChild.saveTable();
    if (netOutVoucherValid) {
      this.netOutVoucher.ientActVoucherConfig.isDirectApproval === 'Y'
        ? (this.netOutVoucherforNotes.statusValue = 'APROV')
        : this.netOutVoucher.statusValue === 'PENAP'
          ? (this.netOutVoucherforNotes.statusValue = 'APROV')
          : (this.netOutVoucherforNotes.statusValue = 'PENAP');
      if (this.lform.valid) {
        if (
          this.netOutVoucher.ilstentActNetoutVoucherDetail.length !== 0
        ) {
          this.netOutVoucherforNotes.referenceId = this.netOutVoucherId;
          this.netOutVoucherforNotes.lddlData = [];
          this.netOutVoucher.ientActNotes = this.netOutVoucherforNotes;
          this.accountsService
            .saveNetoutVoucherNotes(this.netOutVoucher, this.accountsOptions)
            .subscribe((success) => {
              this.netOutVoucher = success;
              this.statusLst = success.ilstentActNetoutVoucherStatusHistory;
              this.data.successMessage(success.msg.infoMessage.msgDescription);
              if (this.netOutVoucher.statusValue === 'APROV') {
                this.onSelectTab(3);
              }
            });
        } else {
          this.errorTrue = true;
          this.data.errorInfoMessage('Please add any items');
        }
      } else {
        this.errorTrue = true;
        this.data.errorInfoMessage('Please fill all mandatory fields');
      }
    }
  }
  
  hideBtnBasedonStatus() {
    let hideButton = false;
    if (
      this.netOutVoucher.statusValue === 'APROV' ||
      this.netOutVoucher.statusValue === 'CANCL' ||
      this.netOutVoucher.statusValue === 'PENAP'
    ) {
      hideButton = true;
    } else {
      hideButton = false;
    }

    return hideButton;
  }

  async changeReversal(valid: any) {
    if (this.netOutVoucherforNotes.temporaryDocumentDate !== '') {
      let isReversal = await this.dialog.confirmDialog(
        this.netOutVoucher.statusDescription
      );
      if (isReversal) {
        this.savenetOutVoucherNotes(valid);
      }
    }
  }

  async onSelectTab(val: any) {
    this.selectedTab = val;
    if (val === 3) {
      await this.viewNetOutVoucherReceipt();
    }
  }

  viewNetOutVoucherReceipt(){

  }

  async doTypeChange(event: any) {
    let alert = await this.dialog.confirmDialog(
      'Changing this option will clear all the value enetered. Are you sure?'
    );
    if (alert) {
      this.netOutVoucherOption = event.value;
      this.createNewnetOutVoucher(this.voucherConfigId, this.regionValue);
    } else {
      this.netOutVoucherOption = this.netOutVoucher.netoutVoucherTypeValue;
    }
  }

  loadVoucherDetailForSales() {
    this.accountsService
      .loadVoucherDetailForSales(this.netOutVoucher, this.accountsOptions)
      .subscribe((success) => {
        this.netOutVoucher.ilstentActNetoutVoucherDetail.push(
          JSON.parse(JSON.stringify(success))
        );
        this.LoadVoucherDetailsForNetoutVoucher(
          this.netOutVoucher.netoutVoucherTypeValue
        );
      });
  }

  loadVoucherDetailForPurchase() {
    this.accountsService
      .loadVoucherDetailForPurchase(this.netOutVoucher, this.accountsOptions)
      .subscribe((success) => {
        this.netOutVoucher.ilstentActNetoutVoucherDetail.push(
          JSON.parse(JSON.stringify(success))
        );
        this.LoadVoucherDetailsForNetoutVoucher(
          this.netOutVoucher.netoutVoucherTypeValue
        );
      });
  }

  LoadVoucherDetailsForNetoutVoucher(val: any) {
    const obj = {
      data: val,
    };
    this.accountsService
      .loadVoucherDetailsForNetoutVoucher(obj, this.accountsOptions)
      .subscribe((success) => {
        this.initialData.DDLValues.DDLVouchers =
          success.data[0].value;
      });
  }

  async navigateDetail(l: any) {
    if (l.valid) {
      if (this.voucherConfigId !== 0) {
        const obj = {
          data: 0,
          data1: this.voucherConfigId,
          data2: this.regionValue
        };
        let urlJson = await this.url.encode(obj);
        this.router.navigateByUrl(
          '/home/finance/net-out-voucher/detail/' + urlJson
        );
      } else {
        this.data.errorInfoMessage('Please Select Document Name');
      }
    }else{
      this.errorTrue = true
    }
  }
  
  navigateToList() {
    this.router.navigateByUrl('/home/finance/net-out-voucher/search');
  }

  dialogClose() {
    this.dialog.closeAll();
  }
}
