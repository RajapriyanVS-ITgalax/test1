import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { UrlService } from './../../../../common/services/url/url.service';

@Injectable({
  providedIn: 'root'
})
export class LedgerRouteService {

  constructor(
    public urlService: UrlService,
    public router: Router
  ) {  }

  async navigatePageBasedonLedgerEntries(val: any) {
    let voucherType = val.voucherTypeValue;
    const obj = {
      data: val.voucherId,
      data1: 0,
    }
    let urlJson = await this.urlService.encode(obj)
    if (voucherType === 'ADVRN') {
      this.router.navigateByUrl(
        '/home/sales/advance-receipt-note/detail/' + urlJson
      );
    } else if (voucherType === 'APYNT') {
      this.router.navigateByUrl(
        '/home/purchase/advance-payment-note/detail/' + urlJson
      );
    } else if (voucherType === 'FTNTE') {
      this.router.navigateByUrl(
        '/home/accounts/fund-transfer/detail/' + urlJson
      );
    } else if (voucherType === 'RTNTE') {
      this.router.navigateByUrl('/home/sales/receipt-note/detail/' + urlJson);
    } else if (voucherType === 'JNLVC') {
      this.router.navigateByUrl(
        '/home/accounts/journal-voucher/detail/' + urlJson
      );
    } else if (voucherType === 'REVJN') {
      this.router.navigateByUrl(
        '/home/accounts/reversing-journal/detail/' + urlJson
      );
    } else if (voucherType === 'SAODR') {
      this.router.navigateByUrl(
        '/home/sales/order-list/detail/' + urlJson
      );
    }else if (voucherType === 'SAICE') {
      this.router.navigateByUrl(
        '/home/sales/invoice-list/detail/' + urlJson
      );
    }else if (voucherType === 'PYNTE') {
      this.router.navigateByUrl(
        '/home/purchase/payment-note/detail/' + urlJson
      );
    }else if (voucherType === 'PRODR') {
      this.router.navigateByUrl(
        '/home/purchase/order/detail/' + urlJson
      );
    }else if (voucherType === 'PRINV') {
      this.router.navigateByUrl(
        '/home/purchase/invoice-list/detail/' + urlJson
      );
    }else if (voucherType === 'NTOUT') {
      this.router.navigateByUrl(
        '/home/accounts/net-out-voucher/detail/' + urlJson
      );
    }else if (voucherType === 'DBNTE') {
      this.router.navigateByUrl(
        '/home/purchase/debit-note/detail/' + urlJson
      );
    }else if (voucherType === 'CRNTE') {
      this.router.navigateByUrl(
        '/home/sales/credit-note/detail/' + urlJson
      );
    }
  }
}
