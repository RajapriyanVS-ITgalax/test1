import { Component } from '@angular/core';

@Component({
  selector: 'app-user-request-detail',
  standalone: true,
  imports: [],
  templateUrl: './user-request-detail.component.html',
  styleUrl: './user-request-detail.component.scss'
})
export class UserRequestDetailComponent {

}
