import { Component } from '@angular/core';

@Component({
  selector: 'app-user-request-search',
  standalone: true,
  imports: [],
  templateUrl: './user-request-search.component.html',
  styleUrl: './user-request-search.component.scss'
})
export class UserRequestSearchComponent {

}
