import { CUSTOM_ELEMENTS_SCHEMA, Component, Input, TemplateRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CoreService } from '../../../../../app-core/service/core.service';
import { SearchComponent } from '../../../../../app-core/template/search/search.component';
import { AppService } from '../../../../../app.service';
import { entCustomerServiceLeadSearch } from '../../../../../common/api-services/application-api/application-api.classes';
import { ApplicationApiService } from '../../../../../common/api-services/application-api/application-api.service';
import { AppStorageService } from '../../../../../common/services/app-storage/app-storage.service';
import { DataService } from '../../../../../common/services/data/data.service';
import { InitialDataService } from '../../../../../common/services/initial-data/initial-data.service';
import { UrlService } from '../../../../../common/services/url/url.service';
import { CategoryFormComponent } from '../../category/category-form/category-form.component';
import { FormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { InnerScroll, Row } from '../../../../../app-core/core-component/core-component.component';
import { InputControlComponent } from '../../../../../app-core/form-input/input-control/input-control.component';
import { AppTableComponent, CellDefDirective, CellHeaderDefDirective } from '../../../../../app-core/template/app-table/app-table.component';
import { IconButtonComponent } from '../../../../../app-core/template/icon-button/icon-button.component';
import { AppAccessDirective } from '../../../../../common/permission/app-access.directive';
import { ButtonAccessDirective } from '../../../../../common/permission/button-access.directive';
import { AppDatePipe } from '../../../../../common/pipes/app-date/app-date.pipe';
import { TableStatusSortComponent } from '../../../../../app-core/table-status-sort/table-status-sort.component';
import { AccountsApiService } from '../../../../../common/api-services/accounts-api/accounts-api.service';
import { entInvItemSearch } from '../../../../../common/api-services/accounts-api/accounts-api.classes';
import { AccoutsStatusTableComponent } from '../../../../../app-core/template/accouts-status-table/accouts-status-table.component';

@Component({
  selector: 'app-items-search',
  standalone: true,
  imports: [
    AppTableComponent,
    CellDefDirective,
    IconButtonComponent,
    InnerScroll,
    InputControlComponent,
    SearchComponent,
    Row,
    FormsModule,
    CellHeaderDefDirective,
    AppDatePipe,
    AppAccessDirective,
    ButtonAccessDirective,
    MatTooltipModule,
    TableStatusSortComponent,
    AccoutsStatusTableComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './items-search.component.html',
  styleUrl: './items-search.component.scss',
})
export class ItemsSearchComponent {

  totalActiveCount: any = '';
  totalInactiveCount: any = '';
  errorTrue = false;
  initialLoad = true;
  dataSource: any = [];
  searchParams = new entInvItemSearch();
  searchParamsRAW = new entInvItemSearch();


  options = {
    type: 'accountsPath',
  };
  idList: any = [];

  __selectedItems: any = {
    currentIndex: 0,
    array: [],
  };
  @ViewChild('appSearch') appSearch!: SearchComponent;
  @ViewChild('breadCrumb') breadCrumb!: TemplateRef<any>;
  @Input() public accessInBtns: any = '';
  @Input() public accessInApp: any = '';
  @Input() public type: any = '';
  @Input() public inventoryGoods: any = '';
  @Input() public hideStatus = false;
  columns: any = [
    'itemCode',
    'effectiveDate',
    'invItemTypeName',
    'invItemSubtypeName',
    'categoryName',
    'status',
    'action',
  ];
  columnsName: any = [
    'Item Code',
    'Created Date',
    'Item Type ',
    'Item Sub Type	',
    'Category',
    'Status',
    'Action',
  ];

  tableData: any = [
    {
      itemCode: 'SI--ST-SI--0009',
      docName: 'Payment Note',
      createdDate: '06 May 2024 11:15 AM',
      createdBy: 'Chief Finance Officer',
      itemType: 'Service Type',
      itemSubType: 'Service Income',
      category: 'Service Item',
      status: 'Active',
    },
  ];
  pagination = {
    pageNumber: 1,
    pageSize: 25,
    totalCount: 0,
  };
  constructor(
    public router: Router,
    public apiService: ApplicationApiService,
    public accountsService: AccountsApiService,
    public data: DataService,
    public appStorage: AppStorageService,
    public appService: AppService,
    public route: ActivatedRoute,
    public initialData: InitialDataService,
    public dialog: CoreService,
    public url: UrlService
  ) {}
  ngOnInit(): void {
    this.init();
  }

  async init() {
    await this.data.checkToken();
    await this.initialData.getAcccountsDDL('getitemInitialData', this.options);
    this.totalInprogressandApprovedCounts();
    this.getitemSearchObject();
  }
  getitemSearchObject() {
    this.accountsService.getitemSearchObject(this.searchParams,this.options).subscribe((success) => {
      this.searchParams = success;
      // if (this.searchParams.regionValue === '') {
      //   this.searchParams.regionValue = this.initialData.DDLValues.DDLRegion[0].constant;
      // }
      this.searchParams.pageNumber = this.pagination.pageNumber;
      this.searchParams.pageSize = this.pagination.pageSize;
      this.searchParamsRAW = JSON.parse(JSON.stringify(this.searchParams));
        if (this.inventoryGoods !== '') {
          this.searchParams.isInventoryGoods = this.inventoryGoods;
        }
        if (this.hideStatus) {
          this.searchParams.strStatusValue = 'ACTIV';
        }
        this.searchItem();
    });
  }
  totalInprogressandApprovedCounts() {
    if (this.initialData.DDLValues.DDLItemInActiveCount.length !== 0) {
      for (
        let i = 0;
        i < this.initialData.DDLValues.DDLItemInActiveCount.length;
        i++
      ) {
        this.totalInactiveCount =
          this.initialData.DDLValues.DDLItemInActiveCount[i].constant;
      }
    }
    if (this.initialData.DDLValues.DDLItemActiveCount.length !== 0) {
      for (
        let i = 0;
        i < this.initialData.DDLValues.DDLItemActiveCount.length;
        i++
      ) {
        this.totalActiveCount =
          this.initialData.DDLValues.DDLItemActiveCount[i].constant;
      }
    }
  }

  onSearch() {
    this.searchParams.pageNumber = 1;
    this.searchItem();
    this.appSearch.close();
  }
  clear() {
    this.getitemSearchObject();
    this.data.successMessage('Data Cleared Successfully');
  }
  onSelect(event: any) {
    this.__selectedItems = event;
  }

  pageChanged(event: any) {
    this.searchParams.pageNumber = event.pageNumber;
    this.searchParams.pageSize = event.pageSize;
    this.searchItem();
  }

  ngAfterViewInit(): void {
    this.appService.setBreadCrumb(this.breadCrumb);
  }

  searchItem() {
    this.searchParams.regionValue = '';
    this.accountsService
      .searchItem(this.searchParams, this.options)
      .subscribe((success: any) => {
        setTimeout(() => {
          this.initialLoad = false;
        }, 400);
        this.pagination = success;
        this.dataSource = success.searchResultInvItem;
      });
  }
  clearAllSearch() {
    this.searchParams = JSON.parse(JSON.stringify(this.searchParamsRAW));
    if (this.inventoryGoods !== '') {
      this.searchParams.isInventoryGoods = this.inventoryGoods;
    }
    if (this.hideStatus) {
      this.searchParams.strStatusValue = 'ACTIV';
    }
    this.searchItem();
  }
  async navigateToDetail(id: any) {
    let obj = {
      id: id
    };
    let encodeId = await this.url.encode(obj);
    this.router.navigateByUrl(
      '/home/inventory/configuration/item/detail/' + encodeId
    );
  }
  getsubtypeBytype(typeId: any) {
    const obj = {
      data: typeId,
    };
    this.accountsService
      .getsubtypeBytype(obj, this.options)
      .subscribe((success) => {
        success.data.forEach((element: any) => {
          this.initialData.DDLValues[element.key = 'SubTypeList'] = element.value;
        });
      });
  }

  statusSortSearch(val: any) {
    this.searchParams.strStatusValue = val;
    this.searchItem()
  }
}
