import { AfterViewInit, CUSTOM_ELEMENTS_SCHEMA, Component, OnDestroy, OnInit, TemplateRef } from '@angular/core';
import { CdkMenuModule } from '@angular/cdk/menu';
import { NavigationEnd, NavigationStart, Router, RouterModule } from '@angular/router';
import { AppSettingsService } from '../common/services/app-settings/app-settings.service';
import { AppService } from '../app.service';
import { AppStorageService } from '../common/services/app-storage/app-storage.service';
import { ErrorMessageComponent } from '../app-core/message/error-message/error-message.component';
import { DataService } from '../common/services/data/data.service';
import { NgTemplateOutlet } from '@angular/common';

import { NgClass } from '@angular/common';
import { CoreService } from '../app-core/service/core.service';
import { MenuAccessDirective } from '../common/permission/menu-access.directive';
import { AppAccessDirective } from '../common/permission/app-access.directive';
import { ButtonAccessDirective } from '../common/permission/button-access.directive';
import { MenuAccessPipe } from '../common/permission/menu-access.pipe';
import { InnerScroll } from '../app-core/core-component/core-component.component';

export class autoSearchItems {
  autoSearchItemId = 0;
  autoSearchText = '';
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CdkMenuModule, RouterModule, MenuAccessPipe, ErrorMessageComponent, NgTemplateOutlet, NgClass, MenuAccessDirective, AppAccessDirective, ButtonAccessDirective, InnerScroll],
  providers: [],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent implements OnInit, OnDestroy {
  pageId = 'PRTDV'

  breadCrumbTemplate!: TemplateRef<any> | null;
  breadCrumbSubscribe: any;
  menuName = '';
  activeClass: any
  sidePosition = [
    {
      originX: 'end',
      originY: 'top',
      overlayX: 'start',
      overlayY: 'top',
    }
  ]
  menus: any = [
    {
      name: "My Task",
      value: 'task',
      icon: 'assets/icons/my-task.svg',
      menuAccess: 'CRMDiv',
      subMenus: [
        {
          name: 'Workflow List',
          url: '/home/my-task/workflow',
          menuAccess: 'CustServSubDiv'

        }
      ]
    },
    {
      name: "Organization",
      value: 'organization',
      icon: 'assets/icons/organization.svg',
      menuAccess: 'CRMDiv',
      subMenus: [
        {
          name: 'New Organization Application',
          url: '/home/organization/organization-application/search',
          menuAccess: 'CustServSubDiv'

        },
        {
          name: 'Organization Change in Detail ',
          url: '/home/organization/organization-change/search',
          menuAccess: 'CustServSubDiv'

        },
        {
          name: 'Registered Organization',
          url: '/home/organization/registered-organization/search',
          menuAccess: 'CustServSubDiv'

        }
      ]
    },
    {
      name: "CRM",
      value: 'crm',
      icon: 'assets/icons/crm.svg',
      menuAccess: 'CRMDiv',
      subMenus: [

        {
          name: 'Customer',
          url: '/home/crm/customer',
          menuAccess: 'CustAppSubDiv'
        },
        {
          name: 'Customer Service',
          url: '/home/crm/customer-service',
          menuAccess: 'CustServSubDiv'
        },
        {
          name: 'Lead',
          url: '/home/crm/lead',
          menuAccess: 'CustLeadSubDiv'
        },
        {
          name: 'Customer Update',
          url: '/home/crm/customer-update',
          menuAccess: 'CustUPAppSubDiv'
        },
        {
          name: 'Report',
          url: '',
          menuAccess: '1'
        },
        {
          name: 'Dashboard',
          url: '',
          menuAccess: '1'
        }
      ]
    },
    {
      name: "Trust",
      value: 'trust',
      icon: 'assets/icons/trust.svg',
      menuAccess: 'CRMDiv',
      subMenus: [

        {
          name: 'Trust Application',
          url: '/home/trust/trust-application',
          menuAccess: 'CustLeadSubDiv'
        },
        {
          name: 'Trust Account',
          url: '',
          menuAccess: '1'
        },
        {
          name: 'Trust Withdrawal',
          url: '/home/trust/trust-withdrawal',
          menuAccess: 'CustLeadSubDiv'
        },

        {
          name: 'Trust Report',
          url: '',
          menuAccess: '1'
        },
        {
          name: 'Trust Settlement',
          url: '/home/trust/trust-settlement',
          menuAccess: '1'
        }
      ]
    },
    {
      name: "Will",
      value: 'will',
      icon: 'assets/icons/will.svg',
      menuAccess: 'CRMDiv',
      subMenus: [

        {
          name: 'Will Application',
          url: '/home/will/will-application/search',
          menuAccess: '1'
        },
        // {
        //   name: 'Will Account',
        //   url: '',
        //   menuAccess: '1'
        // },
        {
          name: 'Will Report',
          url: '',
          menuAccess: '1'
        }
      ]
    },
    {
      name: "Estate",
      value: 'estate',
      icon: 'assets/icons/trust.svg',
      menuAccess: 'CRMDiv',
      subMenus: [
        {
          name: 'Death Notice',
          url: '/home/estate/death-notice-search',
          menuAccess: '1'
        },

        {
          name: 'Estate Application',
          url: '/home/estate/estate-application/search',
          menuAccess: 'CustLeadSubDiv'
        },

        {
          name: 'Estate Account',
          url: '',
          menuAccess: '1'
        },
        {
          name: 'Estate Disbursement',
          url: '',
          menuAccess: '1'
        },
        {
          name: 'Estate Report',
          url: '',
          menuAccess: '1'
        },

      ]
    },
    {
      name: "Legal",
      value: 'legal',
      icon: 'assets/icons/legal.svg',
      menuAccess: 'CRMDiv',
      subMenus: [

        {
          name: 'Legal Service',
          url: 'legal/legal-other-service-search',
          menuAccess: 'CustLeadSubDiv'
        },
        {
          name: 'Other Service',
          url: '',
          menuAccess: '1'
        },
        {
          name: 'Case Management',
          url: '',
          menuAccess: '1'
        }
      ]
    },
    {
      name: "Sales",
      value: 'sales',
      icon: 'assets/icons/sales.svg',
      menuAccess: '1',
      subMenus: [

        {
          name: 'Sales Quotation',
          url: '/home/sales/sales-quotation/search',
          menuAccess: '1'
        },
        {
          name: 'Sales Order',
          url: '/home/sales/sales-order/search',
          menuAccess: '1'
        },
        {
          name: 'Sales Invoice',
          url: '/home/sales/sales-invoice/search',
          menuAccess: '1'
        },
        {
          name: 'Advance Receipt Note',
          url: '/home/sales/advance-receipt-note/search',
          menuAccess: '1'
        },
        {
          name: 'Receipt Note',
          url: '/home/sales/receipt-note/search',
          menuAccess: '1'
        },
        {
          name: 'Credit Note',
          url: '/home/sales/credit-note/search',
          menuAccess: '1'
        },
        {
          name: 'Customer',
          url: '/home/sales/customer/search',
          menuAccess: '1'
        }
      ]
    },
    {
      name: "Purchase",
      value: 'purchase',
      icon: 'assets/icons/purchase.svg',
      menuAccess: '1',
      subMenus: [

        // {
        //   name: 'Purchase Quotation',
        //   url: '/home/purchase/purchase-quotation/search',
        //   menuAccess: '1'
        // },
        {
          name: 'Purchase Order',
          url: '/home/purchase/purchase-order/search',
          menuAccess: '1'
        },
        {
          name: 'Purchase Invoice',
          url: '/home/purchase/purchase-invoice/search',
          menuAccess: '1'
        },
        {
          name: 'Advance Payment Note',
          url: '/home/purchase/advance-payment-note/search',
          menuAccess: '1'
        },
        {
          name: 'Payment Note',
          url: '/home/purchase/payment-note/search',
          menuAccess: '1'
        },
        {
          name: 'Debit Note',
          url: '/home/purchase/debit-note/search',
          menuAccess: '1'
        },
        {
          name: 'Vendor',
          url: '/home/purchase/vendor/search',
          menuAccess: '1'
        },
        {
          name: 'Purchase Order Outstanding',
          url: '/home/purchase/report/purchase-order-outstanding',
          menuAccess: '1'
        },
        {
          name: 'Item Wise Purchase Report',
          url: '/home/purchase/report/item-wise-purchase-report-search',
          menuAccess: '1'
        },
        {
          name: 'Vendor Wise Purchase Report',
          url: '/home/purchase/report/vendor-wise-purchase-report-search',
          menuAccess: '1'
        },
        {
          name: 'Credit Summary Report',
          url: '/home/purchase/report/credit-summary-report/search',
          menuAccess: '1'
        },
        {
          name: 'Creditors Detail Report',
          url: '/home/purchase/report/creditors-detail-report/search',
          menuAccess: '1'
        },
        {
          name: 'Purchase Quotation',
          url: '/home/purchase/purchase-quotation/search',
          menuAccess: '1'
        }
      ]
    },
    {
      name: "Inventory",
      value: 'inventory',
      icon: 'assets/icons/inventory.svg',
      menuAccess: '1',
      subMenus: [
        {
          name: 'Category',
          url: '/home/inventory/configuration/category/search',
          menuAccess: '1'
        },
        {
          name: 'Item',
          url: '/home/inventory/configuration/item/search',
          menuAccess: '1'
        },
        {
          name: 'Item Type & Sub Type',
          url: '/home/inventory/configuration/items/item-type-sub-type',
          menuAccess: '1'
        },
        {
          name: 'Production Note',
          url: '/home/inventory/stock/production-note/search',
          menuAccess: '1'
        },
        {
          name: 'Transfer Note',
          url: '/home/inventory/stock/stock-transfer-note/search',
          menuAccess: '1'
        }
        ,
        // {
        //   name: 'Stock-register-report',
        //   url: '/home/inventory/report/stock-register-report/search',
        //   menuAccess: '1'
        // }
      ]
    },
    {
      name: "Finance",
      value: 'finance',
      icon: 'assets/icons/finance.svg',
      menuAccess: 'FINDiv',
      subMenus: [
        {
          name: 'My Company',
          url: '/home/finance/company/detail',
          menuAccess: 'MYCOM'
        },
        {
          name: 'Group',
          url: '/home/finance/group/list',
          menuAccess: 'AGRPS'
        },
        {
          name: 'Ledger',
          url: '/home/finance/ledger/list',
          menuAccess: 'LEDGR'
        },
        {
          name: 'Voucher',
          url: '/home/finance/voucher/search',
          menuAccess: 'VOCHR'
        },
        {
          name: 'Voucher Account',
          url: '/home/finance/voucher-account/search',
          menuAccess: 'VOCAC'
        },
        // {
        //   name: 'Payment Note',
        //   url: '/home/finance/payment-note/search',
        //   menuAccess: '1'
        // },
        {
          name: 'Fund-transfer',
          url: '/home/finance/fund-transfer-note/search',
          menuAccess: 'FUDTN'
        },
        // {
        //   name: 'Advance Payment Note',
        //   url: '/home/finance/advance-payment-note/search',
        //   menuAccess: '1'
        // },
        {
          name: 'Journal Voucher',
          url: '/home/finance/journal-voucher/search',
          menuAccess: 'JUNVC'
        },
        {
          name: 'Reversing Journal',
          url: '/home/finance/reversing-journal/search',
          menuAccess: 'RJVUH'
        },
        {
          name: 'Tax',
          url: '/home/finance/tax/search',
          menuAccess: 'TAX'
        },
        {
          name: 'Exchange Rate',
          url: '/home/finance/exchange-rate/search',
          menuAccess: 'EXCRT'
        },
        // {
        //   name: 'Net Out Voucher',
        //   url: '/home/finance/net-out-voucher/search',
        //   menuAccess: '1'
        // },
        {
          name: 'Ledger Transactions',
          url: '/home/finance/ledger-transaction/search',
          menuAccess: 'LDTRS'
        },



      ]
    },
  ]
  constructor(public appSettings: AppSettingsService,
    public appService: AppService,
    public storage: AppStorageService,
    public data: DataService,
    public coreService: CoreService,
    private router: Router
  ) {
    this.router.events.subscribe((val) => {
      if (val instanceof NavigationStart) {
        this.appService.setBreadCrumb(null);
      }
    });
    this.breadCrumbSubscribe = this.appService.watchBreadCrumbChanged().subscribe((val) => {
      if (val) {
        setTimeout(() => {
          this.breadCrumbTemplate = this.appService.getBreadCrumb();

        }, 100);
      }
    });

  }

  ngOnInit(): void {


    this.storage.get('userData').then((val) => {
      this.appService.userData = val;
    });
    this.storage.get('companyCurrencyValue').then((val) => {
      this.appService.currencyValue = val;
    });
    this.storage.get('companyId').then((val) => {
      this.appService.companyId = val;
    });
    this.storage.get('branchDDL').then((val) => {
      this.appService.branchDDL = val;
    })
    this.storage.get('branchValue').then((val) => {
      this.appService.branchId = val;
    })
    this.storage.get('branchId').then((val) => {
      this.appService.branchValue = val;
    })
    this.setActiveUrl(this.router.url);
  }

  ngOnDestroy() {
    if (this.breadCrumbSubscribe) {
      this.breadCrumbSubscribe.unsubscribe();
      // this.storage.set('sourcePrimaryKey', 0);
    }
  }

  async doLogout() {
    await this.coreService.logout();
    await this.coreService.closeDialog()
  }

  navigateToHome() {
    this.router.navigateByUrl('/home')
  }
  menuValue(val: any) {
    this.storage.set('sourcePrimaryKey', 0);
    this.menuName = val
  }

  setActiveUrl(val: any) {
    let urlParts = val.split('/');
    this.menuName = urlParts[2];
  }

}
