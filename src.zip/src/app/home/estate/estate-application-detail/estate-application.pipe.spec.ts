import { EstateApplicationPipe } from './estate-application.pipe';

describe('EstateApplicationPipe', () => {
  it('create an instance', () => {
    const pipe = new EstateApplicationPipe();
    expect(pipe).toBeTruthy();
  });
});
