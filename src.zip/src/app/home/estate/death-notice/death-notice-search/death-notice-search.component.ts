import { CUSTOM_ELEMENTS_SCHEMA, Component, TemplateRef, ViewChild } from '@angular/core';
import { AppTableComponent, CellDefDirective, CellHeaderDefDirective } from '../../../../app-core/template/app-table/app-table.component';
import { IconButtonComponent } from '../../../../app-core/template/icon-button/icon-button.component';
import { FormsModule, NgForm } from '@angular/forms';
import { InnerScroll, Row } from '../../../../app-core/core-component/core-component.component';
import { InputControlComponent } from '../../../../app-core/form-input/input-control/input-control.component';
import { SearchComponent } from '../../../../app-core/template/search/search.component';
import { AppDatePipe } from '../../../../common/pipes/app-date/app-date.pipe';
import { CoreService } from '../../../../app-core/service/core.service';
import { AppService } from '../../../../app.service';
import { DataService } from '../../../../common/services/data/data.service';
import { InitialDataService } from '../../../../common/services/initial-data/initial-data.service';
import { ApplicationApiService } from '../../../../common/api-services/application-api/application-api.service';
import { entDeathNotice, entDeathNoticeSearch } from '../../../../common/api-services/application-api/application-api.classes';
import { UrlService } from '../../../../common/services/url/url.service';
import { Router } from '@angular/router';
import { ErrorMessageComponent } from '../../../../app-core/message/error-message/error-message.component';

@Component({
  selector: 'app-death-notice-search',
  standalone: true,
  imports: [AppTableComponent, CellDefDirective, CellHeaderDefDirective, IconButtonComponent, InnerScroll, InputControlComponent, SearchComponent, Row, FormsModule, AppDatePipe, ErrorMessageComponent],
  templateUrl: './death-notice-search.component.html',
  styleUrl: './death-notice-search.component.scss',
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class DeathNoticeSearchComponent {
  errorTrue = false
  pagination = {
    pageNumber: 1,
    pageSize: 25,
    totalCount: 0
  }
  __selectedItems: any = {
    currentIndex: 0,
    array: []
  };
  columns: any = ['deathNoticeRefNo', 'personName', 'dateOfDeath', 'paperDescription', 'noticeDate', 'statusDescription', 'action'];
  columnsName: any = ["Notice Ref No", "Person Name", "Date Of Death", "Paper", "Notice Date", "Status", "Action"];
  @ViewChild('breadCrumb') breadCrumb!: TemplateRef<any>;
  tableData: any = [];
  @ViewChild('addDialog', { static: false })
  addDialog!: TemplateRef<any>;
  options = {
    hideFullSpinner: true
  }
  @ViewChild('x') xform!: NgForm
  searchParams = new entDeathNoticeSearch();
  searchParamsRAW = new entDeathNoticeSearch();
  deathNoticeData = new entDeathNotice();
  currentDate = '';
  constructor(
    public dialog: CoreService,
    public data: DataService,
    public appService: AppService,
    public initialData: InitialDataService,
    public apiService: ApplicationApiService,
    public url: UrlService,
    public router: Router
  ) {

  }
  ngAfterViewInit(): void {
    this.appService.setBreadCrumb(this.breadCrumb);
  }
  ngOnInit(): void {
    this.init()
  }
  async init() {
    await this.data.checkToken();
    this.currentDate = this.appService.getCurrentDate();
    this.initialData.getDDL('getInitialDataForDeathNotice', this.options);
    this.createDeathNoticeSearch();
  }
  createDeathNoticeSearch(type?: any) {
    this.apiService.createNewDeathNoticeSearch().subscribe((success) => {
      this.searchParams = success;
      this.searchParams.pageNumber = this.pagination.pageNumber;
      this.searchParams.pageSize = this.pagination.pageSize;
      if (type === 'clear') {
        this.data.successMessage('Data Cleared Successfuly')
      }
      else {

        this.searchDeathNotice()
      }
    })
  }
  searchDeathNotice() {
    this.apiService.searchDeathNotice(this.searchParams).subscribe((success) => {
      this.pagination = success
      this.tableData = success.result;
      this.dialog.closeDialog();
    })
  }
  pageChanged(event: any) {
    this.searchParams.pageNumber = event.pageNumber;
    this.searchParams.pageSize = event.pageSize;
    this.searchDeathNotice();

  }
  onSelect(event: any) {
    this.__selectedItems = event;
  }
  createDeathNotice(val?: any) {
    this.apiService.createDeathNotice().subscribe((success) => {
      this.deathNoticeData = success;
    })
    if (val === '') { }
    else {
      this.data.successMessage('Data Cleared Successfully')
    }
  }
  async createDeathNoticeDialog() {
    this.createDeathNotice()
    let dialogResponse: any = await this.dialog.openDialog(this.addDialog, {
      disableClose: true,
      height: '300px',
      width: '750px',
      maxWidth: '1170px',
    });
  }
  async selectAllNavigate() {

    if (this.__selectedItems.array.length === 0) {
      return;
    }
    let encodeId = await this.url.encode(this.__selectedItems);
    this.router.navigateByUrl('/home/estate/death-notice-detail/' + encodeId);
  }
  async navigateToDetail(id: any) {
    let obj = {
      currentIndex: 0,
      array: [id]
    }
    let encodeId = await this.url.encode(obj);
    this.router.navigateByUrl('/home/estate/death-notice-detail/' + encodeId);

  }
  saveDeathNotice() {
    if (this.xform.valid) {
      this.apiService.saveDeathNotice(this.deathNoticeData).subscribe((success) => {
        this.data.successMessage(success.msg.infoMessage.msgDescription);
        this.navigateToDetail(success.deathNoticeId);
        this.dialog.closeDialog()
        this.data.showErrorMessage = false;
      })
    }
    else {
      this.errorTrue = true
    }
  }
  closeDialog() {
    this.data.showErrorMessage = false;
    this.dialog.closeAll()
  }
}
