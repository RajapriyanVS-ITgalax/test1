import { CUSTOM_ELEMENTS_SCHEMA, Component, TemplateRef, ViewChild } from '@angular/core';
import { Row, ViewLabel } from '../../../../app-core/core-component/core-component.component';
import { IconButtonComponent } from '../../../../app-core/template/icon-button/icon-button.component';
import { FormsModule, NgForm } from '@angular/forms';
import { InputControlComponent } from '../../../../app-core/form-input/input-control/input-control.component';
import { AccordionModule } from '../../../../app-core/template/accordion/accordion.module';
import { AppDatePipe } from "../../../../common/pipes/app-date/app-date.pipe";
import { CoreService } from '../../../../app-core/service/core.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AppService } from '../../../../app.service';
import { ApplicationApiService } from '../../../../common/api-services/application-api/application-api.service';
import { DataService } from '../../../../common/services/data/data.service';
import { InitialDataService } from '../../../../common/services/initial-data/initial-data.service';
import { UrlService } from '../../../../common/services/url/url.service';
import { entDeathNotice } from '../../../../common/api-services/application-api/application-api.classes';
import { MultiPageUrlComponent } from '../../../../app-core/template/multi-page-url/multi-page-url.component';

@Component({
  selector: 'app-death-notice-detail',
  standalone: true,
  templateUrl: './death-notice-detail.component.html',
  styleUrl: './death-notice-detail.component.scss',
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  imports: [Row, ViewLabel, IconButtonComponent, FormsModule, InputControlComponent, AccordionModule, AppDatePipe, MultiPageUrlComponent]
})
export class DeathNoticeDetailComponent {
  applicationEdit = false;
  deathNoticeData = new entDeathNotice();
  commentEdit = false;
  currentDate: any = ''
  @ViewChild('addDialog', { static: false })
  addDialog!: TemplateRef<any>;
  @ViewChild('x') xform!: NgForm;
  options = {
    hideFullSpinner: true
  }
  id = {
    currentIndex: 0,
    array: []
  };
  deathNoticeId = 0
  __selectedItems: any = {
    currentIndex: 0,
    array: []
  };
  errorTrue = false
  @ViewChild('breadCrumb') breadCrumb!: TemplateRef<any>;

  constructor(public route: ActivatedRoute,
    public data: DataService,
    public apiService: ApplicationApiService,
    public initialData: InitialDataService,
    public dialog: CoreService,
    public url: UrlService,
    public router: Router,
    public appService: AppService) {
    this.route.paramMap.subscribe((params: any) => {
      this.init();
    });
  }

  ngOnInit(): void {
    // this.init()
  }

  async init() {
    let id = this.route.snapshot.paramMap.get('id');
    let params: any = await this.url.decode(id);
    this.id = params;
    this.deathNoticeId = this.id.array[this.id.currentIndex];
    await this.data.checkToken();
    this.appService.setBreadCrumb(this.breadCrumb);
    this.currentDate = this.appService.getCurrentDate();
    this.openDeathNoticeDetail(this.deathNoticeId);
    this.initialData.getDDL('getInitialDataForDeathNotice', this.options);
  }
  ngAfterViewInit(): void {
    this.appService.setBreadCrumb(this.breadCrumb);
  }

  openDeathNoticeDetail(val: any, type?: any) {
    const obj = {
      data: val
    }
    this.apiService.openDeathNotice(obj).subscribe((success) => {
      this.deathNoticeData = success;
      this.data.successMessage(success.msg.infoMessage.msgDescription);
    })
    if (type === 'refresh') {
      this.data.successMessage('Data Refreshed Successfully')
    }
  }



  editApplication() {
    this.applicationEdit = true;
  }
  saveApplication() {
    if (this.xform.valid) {
      this.apiService.saveDeathNotice(this.deathNoticeData).subscribe((success) => {
        this.deathNoticeData = success;
        this.data.showErrorMessage = false;
        this.applicationEdit = false;
        this.data.successMessage(success.msg.infoMessage.msgDescription);
      })
    }
    else {
      this.errorTrue = true
    }
  }
  createNotes() { }

  navigateToList() {
    this.router.navigateByUrl('/home/estate/death-notice-search')
  }
}
