import { CUSTOM_ELEMENTS_SCHEMA, Component, TemplateRef, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { InnerScroll, Row } from '../../../app-core/core-component/core-component.component';
import { InputControlComponent } from '../../../app-core/form-input/input-control/input-control.component';
import { AppTableComponent, CellDefDirective, CellHeaderDefDirective } from '../../../app-core/template/app-table/app-table.component';
import { IconButtonComponent } from '../../../app-core/template/icon-button/icon-button.component';
import { SearchComponent } from '../../../app-core/template/search/search.component';
import { AppDatePipe } from '../../../common/pipes/app-date/app-date.pipe';
import { CoreService } from '../../../app-core/service/core.service';
import { EstateApplicationFormComponent } from '../estate-application-form/estate-application-form.component';
import { AppService } from '../../../app.service';
import { Router } from '@angular/router';
import { InitialDataService } from '../../../common/services/initial-data/initial-data.service';
import { DataService } from '../../../common/services/data/data.service';
import { ApplicationApiService } from '../../../common/api-services/application-api/application-api.service';
import { entEstateApplicationSearch } from '../../../common/api-services/application-api/application-api.classes';
import { UrlService } from '../../../common/services/url/url.service';

@Component({
  selector: 'app-estate-application-search',
  standalone: true,
  imports: [AppTableComponent, CellDefDirective, CellHeaderDefDirective, IconButtonComponent, InnerScroll, InputControlComponent, SearchComponent, Row, FormsModule, AppDatePipe],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './estate-application-search.component.html',
  styleUrl: './estate-application-search.component.scss'
})
export class EstateApplicationSearchComponent {
createEstateApp() {
throw new Error('Method not implemented.');
}
onSelect($event: any) {
throw new Error('Method not implemented.');
}

navigateToDetail() {
throw new Error('Method not implemented.');
}


  @ViewChild('breadCrumb') breadCrumb!: TemplateRef<any>;
  pagination = {
    pageNumber: 1,
    pageSize: 25,
    totalCount: 0
  }

  searchParams = new entEstateApplicationSearch();
  searchParamsRAW = new entEstateApplicationSearch();
  __selectedItems: any = {
    currentIndex: 0,
    array: []
  };
  columns: any = ['estateApplicationRefNo', 'fileNo', 'applicantName', 'appliedBranch', 'applicantStatus', 'actionStatus', 'assignedOfficer', 'action'];
  columnsName: any = ["Estate App Ref No", "File No", "Applicant Name", "Applied Branch",  "Applicant Status", "Action Status", "Assigned Officer", "Action"];

  tableData: any = [{
    'estateApplicationRefNo': 'EST2407160001', 'fileNo': 'FIL6677782', 'applicantName': 'Segilala Wiliame', 'appliedBranch': 'Fjd', 'applicantStatus' : 'Active', 'actionStatus': 'Approved', 'assignedOfficer': 'Port Suva', 'action': '',
  }];

  errorTrue = false

  constructor(
    public dialog: CoreService,
    public appService: AppService,
    public router: Router,
    public initialData: InitialDataService,
    public data: DataService,
    public apiService: ApplicationApiService,
    public url: UrlService
  ) {

  }
  ngOnInit(): void {
    this.init();
  }

  ngAfterViewInit(): void {
    this.appService.setBreadCrumb(this.breadCrumb);
  }
  async init() {
   await this.data.checkToken();
    // this.initialData = this.getInitialDataForEstateApplication()
  }

  createEstateAppSearch(arg0: string) {
    throw new Error('Method not implemented.');
    }
    searchEstateapp() {
    throw new Error('Method not implemented.');
    }


    pageChanged(event: any) {
      this.searchParams.pageNumber = event.pageNumber;
      this.searchParams.pageSize = event.pageSize;
      this.searchEstateapp();
      }

}
