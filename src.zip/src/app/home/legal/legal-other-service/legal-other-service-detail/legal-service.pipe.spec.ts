import { LegalServicePipe } from './legal-service.pipe';

describe('LegalServicePipe', () => {
  it('create an instance', () => {
    const pipe = new LegalServicePipe();
    expect(pipe).toBeTruthy();
  });
});
