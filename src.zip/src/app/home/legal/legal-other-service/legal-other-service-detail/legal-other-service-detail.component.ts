import { Component, CUSTOM_ELEMENTS_SCHEMA, TemplateRef, ViewChild } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { InputControlComponent } from '../../../../app-core/form-input/input-control/input-control.component';
import { InnerScroll, Row, ViewLabel } from '../../../../app-core/core-component/core-component.component';
import { IconButtonComponent } from '../../../../app-core/template/icon-button/icon-button.component';
import { TabComponent, TabGroupComponent } from '../../../../app-core/template/tab/tab';
import { TabSubComponent, TabSubGroupComponent } from '../../../../app-core/template/tab/tab1';
import { AccordionModule } from '../../../../app-core/template/accordion/accordion.module';
import { CoreService } from '../../../../app-core/service/core.service';
import { InitialDataService } from '../../../../common/services/initial-data/initial-data.service';
import { DropZoneComponent } from '../../../../app-core/template/drop-zone/drop-zone.component';
import { FileSizePipe } from '../../../../app-core/template/drop-zone/file-size.pipe';
import { AppTableComponent } from '../../../../app-core/template/app-table/app-table.component';
import { CheckboxComponent } from '../../../../app-core/template/checkbox/checkbox.component';
import { AppService } from '../../../../app.service';
import { entLegalApplication, entLegalApplicationApplicant, entTrustApplicationApplicant } from '../../../../common/api-services/application-api/application-api.classes';
import { AddressEditComponent } from '../../../../app-core/template/address-edit/address-edit.component';
import { KycEditComponent } from '../../../../app-core/template/kyc-edit/kyc-edit.component';
import { AppDatePipe } from '../../../../common/pipes/app-date/app-date.pipe';
import { StatusHistoryComponent } from '../../../../app-core/template/status-history/status-history.component';
import { ApplicationApiService } from '../../../../common/api-services/application-api/application-api.service';
import { ActivatedRoute, Router } from '@angular/router';
import { UrlService } from '../../../../common/services/url/url.service';
import { DataService } from '../../../../common/services/data/data.service';
import { CreationApplicationComponent } from './creation-application/creation-application.component';
import { DocumentCollectionComponent } from './document-collection/document-collection.component';
import { OpenFileComponent } from '../../../trust/trust-application/trust-application-dummy/open-file/open-file.component';
import { ServiceInProcessComponent } from './service-in-process/service-in-process.component';
import { ServiceInProcess1Component } from './service-in-process1/service-in-process1.component';
import { PrepareDocumentationComponent } from './prepare-documentation/prepare-documentation.component';
import { PrepareSoaComponent } from './prepare-soa/prepare-soa.component';
import { ScanDocComponent } from './scan-doc/scan-doc.component';
import { VerificationOfFeeComponent } from './verification-of-fee/verification-of-fee.component';
import { HandoverDocComponent } from './handover-doc/handover-doc.component';

@Component({
  selector: 'app-legal-other-service-detail',
  standalone: true,
  imports: [FormsModule, InputControlComponent, ViewLabel, IconButtonComponent, TabGroupComponent, TabComponent, TabSubGroupComponent, AccordionModule, Row, InnerScroll, DropZoneComponent, FileSizePipe, AppTableComponent, CheckboxComponent, AddressEditComponent, KycEditComponent, AppDatePipe, TabSubGroupComponent, TabSubComponent, StatusHistoryComponent, CreationApplicationComponent, DocumentCollectionComponent, OpenFileComponent, ServiceInProcessComponent, ServiceInProcess1Component, PrepareDocumentationComponent, PrepareSoaComponent, ScanDocComponent, VerificationOfFeeComponent, PrepareSoaComponent, HandoverDocComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './legal-other-service-detail.component.html',
  styleUrl: './legal-other-service-detail.component.scss'
})
export class LegalOtherServiceDetailComponent {
  @ViewChild('breadCrumb') breadCrumb!: TemplateRef<any>;
  legalApplication = new entLegalApplication()
  //clientDoc
  clientDocumentColumns: any = ['documentTypeDescription', 'fileName', 'fileSize', 'action']
  clientDocumentColumnsName: any = ['Document Name', 'File Name', 'Size', 'Action']
  docNameType: any
  errorTrue = false;
  legalServiceAppliant = new entLegalApplicationApplicant();
  legalServiceAppliantRAW = new entLegalApplicationApplicant();
  //receipt
  receiptFundColumns: any = ['1', '2', '3', '4', '5'];
  receiptFundColumnsName: any = ["Date", "Check No / Tr. No", "Organization", "Receipt No", "Amount"];
  receiptFundTableData: any = [];
  constructor(
    public apiService: ApplicationApiService,
    public initialData: InitialDataService,
    public dialog: CoreService,
    public router: Router,
    public route: ActivatedRoute,
    public data: DataService,
    public url: UrlService,
    public appService: AppService) {
    this.route.paramMap.subscribe((params: any) => {
      this.init();
    });
  }
  editData = false;
  currentDate = '';
  //history
  assignOfficerColumns: any = ["assignedToFullname", "assignedDate", "assignedByFullname", "statusDescription"];
  assignOfficerColumnsName: any = ["Assigned Officer", "Assigned Date", "Assigned By", "Status",];
  tableAssignOffice = [];
  statusHistoryDataSource: any = [];
  accept: any
  emailColumns: any = ["toEmailId", "sentDate", "sentStatusDescription", "action"];
  emailColumnsName: any = ["To", " Date | Time", "Status", "Action"];
  emailHistoryTableData: any = [];
  linkedColumns: any = ['description', 'action'];
  linkedColumnsName: any = ['Document Name', ' Actions'];
  tableLinkedData: any = []
  @ViewChild('applicant', { static: false })
  applicant!: TemplateRef<any>;


  ngAfterViewInit(): void {
    this.appService.setBreadCrumb(this.breadCrumb);
  }
  id = {
    currentIndex: 0,
    array: []
  };
  pagination = {
    pageNumber: 1,
    pageSize: 25,
    totalCount: 0
  }
  legalServiceId = 0;
  @ViewChild('p') pForm!: NgForm;
  async init() {
    this.appService.setBreadCrumb(this.breadCrumb);
    let id = this.route.snapshot.paramMap.get('id');
    let params: any = await this.url.decode(id);
    console.log(params);
    this.id = params;
    this.legalServiceId = this.id.array[this.id.currentIndex];
    await this.data.checkToken();
    this.initialData.getDDL('getInitialDataForCommonAddress');
    this.currentDate = this.appService.getCurrentDate();
    await this.initialData.getDDL('getInitialDataForLegalApplication');
    this.openLegalService()

  }

  openLegalService() {
    const obj = {
      data: this.legalServiceId
    }
    this.apiService.openLegalApplication(obj).subscribe((success) => {
      this.legalApplication = success;
      this.legalServiceAppliant = success.ientLegalApplicationApplicant
      this.data.successMessage(success.msg?.infoMessage?.msgDescription)
    })
  }

  onTabChange(event: any) {
    switch (event.tabTitle) {
      case 'History':
        this.getNotesList();
        this.getAssignedOfficerList();
        this.getStatusHistoryList();
        this.getEmailHistoryList();
    }
  }
  async editLegal(val: any) {
    let response: any = await this.dialog.openDialog(this.applicant, {
      height: '600px',
      width: '100%',
      maxWidth: '1100px',
      data: {
        type: val,
      }
    });
  }
  downloadLinkedFile(val: any) {

  }
  completeApplicationStage() { }
  downloadFile(val: any) { }
  checkDocumentDelete(val: any) { }
  viewFile(val: any) { }
  saveApplicant() {
    if (this.pForm.valid) {
      this.legalServiceAppliant.legalApplicationId = this.legalApplication.legalApplicationId;
      this.legalServiceAppliant.customerDdlFlage = 'N'
      this.apiService.saveLegalApplicationApplicant(this.legalServiceAppliant).subscribe((success) => {
        this.legalServiceAppliant = success;
        this.editData = false
        this.dialog.closeAll();
        this.errorTrue = false
      })
    }
    else {
      this.errorTrue = true
    }
  }
  editApplicant() {
    this.editData = true
  }
  createNotes() {

  }
  reAssignTrust() { }
  selfAssignTrust() { }
  uploadClientDocumentAttachment(event: any) {

  }
  onChange(event: any) {

  }
  openCustomerForApplicant(val: any) {
    const obj = {
      data: val
    }
    this.apiService.openCustomer(obj).subscribe((success) => {
      this.legalServiceAppliant.ientCustomer = success;
      this.editData = true

    })
  }
  refreshCustomerForApplicant(val: any) {
    const obj = {
      data: val
    }
    this.apiService.openCustomer(obj).subscribe((success) => {
      this.legalServiceAppliant.ientCustomer = success;
      this.editData = false

    })
  }
  clearApplicant() {
    this.legalServiceAppliant = JSON.parse(JSON.stringify(this.legalServiceAppliantRAW))
  }
  notesList: any
  getNotesList() {
    const obj = {
      data: this.legalServiceId,
      data1: this.legalApplication.applicationStageValue
    }
    this.apiService.getListOfNotesByLegalApplicationId(obj).subscribe((success) => {
      this.notesList = success.lstentLegalApplicationNotes;
    })
  }
  getAssignedOfficerList() {
    const obj = {
      data: this.legalServiceId,
      data1: this.legalApplication.applicationStageValue
    }
    this.apiService.getListOfAssignedOfficerHistoryByLegalApplicationId(obj).subscribe((success) => {
      this.tableAssignOffice = success.lstentLegalApplicationAssignedOfficerHistory
    })
  }
  getStatusHistoryList() {
    const obj = {
      data: this.legalServiceId,
      data1: this.legalApplication.applicationStageValue
    }
    this.apiService.getListOfStatusHistoryByLegalApplicationId(obj).subscribe((success) => {
      this.statusHistoryDataSource = success.lstentLegalApplicationStatusHistory
    })
  }
  getEmailHistoryList() {
    const obj = {
      data: this.legalServiceId,
      data1: this.legalApplication.applicationStageValue
    }
    this.apiService.getListOfCommunicationHistoryByLegalApplicationId(obj).subscribe((success) => {
      this.emailHistoryTableData = success.lstentLegalApplicationEmailHistory
    })
  }

}
