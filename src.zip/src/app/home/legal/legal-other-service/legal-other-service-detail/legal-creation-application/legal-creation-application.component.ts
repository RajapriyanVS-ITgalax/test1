import { Component } from '@angular/core';

@Component({
  selector: 'app-legal-creation-application',
  standalone: true,
  imports: [],
  templateUrl: './legal-creation-application.component.html',
  styleUrl: './legal-creation-application.component.scss'
})
export class LegalCreationApplicationComponent {

}
