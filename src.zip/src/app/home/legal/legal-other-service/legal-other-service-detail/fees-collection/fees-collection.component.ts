import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Row, ViewLabel } from '../../../../../app-core/core-component/core-component.component';
import { FormsModule } from '@angular/forms';
import { InputControlComponent } from '../../../../../app-core/form-input/input-control/input-control.component';
import { IconButtonComponent } from '../../../../../app-core/template/icon-button/icon-button.component';
import { AccordionModule } from '../../../../../app-core/template/accordion/accordion.module';
import { AppDatePipe } from '../../../../../common/pipes/app-date/app-date.pipe';

@Component({
  selector: 'app-fees-collection',
  standalone: true,
  imports: [AccordionModule, ViewLabel, InputControlComponent, FormsModule, IconButtonComponent, Row, AppDatePipe],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './fees-collection.component.html',
  styleUrl: './fees-collection.component.scss'
})
export class FeesCollectionComponent {
  //receipt
  receiptFundColumns: any = ['1', '2', '3', '4', '5'];
  receiptFundColumnsName: any = ["Date", "Check No / Tr. No", "Organization", "Receipt No", "Amount"];
  receiptFundTableData: any = [];
}
